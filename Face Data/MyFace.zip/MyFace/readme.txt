brightness = 10
contrast = 10 
thresh = 75
