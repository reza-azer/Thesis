#ifndef protoset_H
#define protoset_H
#include <Arduino.h>

class dataset
{
public:
    byte wajah [70][40];
    int baris, kolom;
    Netral0 ();    
    Netral1 ();
    Netral2 ();
    Netral3 ();
    Netral4 ();
    Netral5 ();
    Netral6 ();
    Netral7 ();
    Netral8 ();
    Netral9 ();

    Senang0 ();
    Senang1 ();
    Senang2 ();
    Senang3 ();
    Senang4 ();
    Senang5 ();
    Senang6 ();
    Senang7 ();
    Senang8 ();
    Senang9 ();
    
    Antusias0 ();
    Antusias1 ();
    Antusias2 ();
    Antusias3 ();
    Antusias4 ();
    Antusias5 ();
    Antusias6 ();
    Antusias7 ();
    Antusias8 ();
    Antusias9 ();

};

#endif
