#include "Arduino.h"
#include "dataset_mata.h"


dataset::wajahkanan1()
{
  baris = 23;
  kolom = 101;
//Baris1
for (byte i=0;i<=2;i++) {
datawajah[0][i]=0; }
for (byte i=3;i<=3;i++) {
datawajah[0][i]=1; }
for (byte i=4;i<=20;i++) {
datawajah[0][i]=0; }
for (byte i=21;i<=24;i++) {
datawajah[0][i]=1; }
for (byte i=25;i<=41;i++) {
datawajah[0][i]=0; }
for (byte i=42;i<=58;i++) {
datawajah[0][i]=1; }
for (byte i=59;i<=60;i++) {
datawajah[0][i]=0; }
for (byte i=61;i<=62;i++) {
datawajah[0][i]=1; }
for (byte i=63;i<=74;i++) {
datawajah[0][i]=0; }
for (byte i=75;i<=75;i++) {
datawajah[0][i]=1; }
for (byte i=76;i<=80;i++) {
datawajah[0][i]=0; }
for (byte i=81;i<=100;i++) {
datawajah[0][i]=1; }


 //Baris2
for (byte i=0;i<=41;i++) {
datawajah[1][i]=0; }
for (byte i=42;i<=58;i++) {
datawajah[1][i]=1; }
for (byte i=59;i<=60;i++) {
datawajah[1][i]=0; }
for (byte i=61;i<=61;i++) {
datawajah[1][i]=1; }
for (byte i=62;i<=79;i++) {
datawajah[1][i]=0; }
for (byte i=80;i<=100;i++) {
datawajah[1][i]=1; }


 //Baris3

for (byte i=0;i<=41;i++) {
datawajah[2][i]=0; }
for (byte i=42;i<=58;i++) {
datawajah[2][i]=1; }
for (byte i=59;i<=77;i++) {
datawajah[2][i]=0; }
for (byte i=78;i<=100;i++) {
datawajah[2][i]=1; }


//Baris4
for (byte i=0;i<=8;i++) {
datawajah[3][i]=0; }
for (byte i=9;i<=13;i++) {
datawajah[3][i]=1; }
for (byte i=14;i<=42;i++) {
datawajah[3][i]=0; }
for (byte i=43;i<=57;i++) {
datawajah[3][i]=1; }
for (byte i=58;i<=77;i++) {
datawajah[3][i]=0; }
for (byte i=78;i<=100;i++) {
datawajah[3][i]=1; }


//Baris5

for (byte i=0;i<=43;i++) {
datawajah[4][i]=0; }
for (byte i=44;i<=59;i++) {
datawajah[4][i]=1; }
for (byte i=60;i<=77;i++) {
datawajah[4][i]=0; }
for (byte i=78;i<=79;i++) {
datawajah[4][i]=1; }
for (byte i=80;i<=81;i++) {
datawajah[4][i]=0; }
for (byte i=82;i<=100;i++) {
datawajah[4][i]=1; }



//Baris6
for (byte i=0;i<=44;i++) {
datawajah[5][i]=0; }
for (byte i=45;i<=60;i++) {
datawajah[5][i]=1; }
for (byte i=61;i<=83;i++) {
datawajah[5][i]=0; }
for (byte i=84;i<=84;i++) {
datawajah[5][i]=1; }
for (byte i=85;i<=95;i++) {
datawajah[5][i]=0; }
for (byte i=96;i<=97;i++) {
datawajah[5][i]=1; }
for (byte i=98;i<=100;i++) {
datawajah[5][i]=0; }


//Baris7
for (byte i=0;i<=43;i++) {
datawajah[6][i]=0; }
for (byte i=44;i<=60;i++) {
datawajah[6][i]=1; }
for (byte i=61;i<=83;i++) {
datawajah[6][i]=0; }
for (byte i=84;i<=85;i++) {
datawajah[6][i]=1; }
for (byte i=86;i<=100;i++) {
datawajah[6][i]=0; }


//Baris8
for (byte i=0;i<=42;i++) {
datawajah[7][i]=0; }
for (byte i=43;i<=60;i++) {
datawajah[7][i]=1; }
for (byte i=61;i<=100;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=18;i++) {
datawajah[8][i]=0; }
for (byte i=19;i<=20;i++) {
datawajah[8][i]=1; }
for (byte i=21;i<=43;i++) {
datawajah[8][i]=0; }
for (byte i=44;i<=61;i++) {
datawajah[8][i]=1; }
for (byte i=62;i<=100;i++) {
datawajah[8][i]=0; }


//Baris10
for (byte i=0;i<=18;i++) {
datawajah[9][i]=0; }
for (byte i=19;i<=21;i++) {
datawajah[9][i]=1; }
for (byte i=22;i<=42;i++) {
datawajah[9][i]=0; }
for (byte i=43;i<=61;i++) {
datawajah[9][i]=1; }
for (byte i=62;i<=65;i++) {
datawajah[9][i]=0; }
for (byte i=66;i<=68;i++) {
datawajah[9][i]=1; }
for (byte i=69;i<=100;i++) {
datawajah[9][i]=0; }


//Baris11
for (byte i=0;i<=17;i++) {
datawajah[10][i]=0; }
for (byte i=18;i<=21;i++) {
datawajah[10][i]=1; }
for (byte i=22;i<=41;i++) {
datawajah[10][i]=0; }
for (byte i=42;i<=61;i++) {
datawajah[10][i]=1; }
for (byte i=62;i<=66;i++) {
datawajah[10][i]=0; }
for (byte i=67;i<=68;i++) {
datawajah[10][i]=1; }
for (byte i=69;i<=100;i++) {
datawajah[10][i]=0; }


//Baris12
for (byte i=0;i<=40;i++) {
datawajah[11][i]=0; }
for (byte i=41;i<=62;i++) {
datawajah[11][i]=1; }
for (byte i=63;i<=75;i++) {
datawajah[11][i]=0; }
for (byte i=76;i<=77;i++) {
datawajah[11][i]=1; }
for (byte i=78;i<=100;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=40;i++) {
datawajah[12][i]=0; }
for (byte i=41;i<=62;i++) {
datawajah[12][i]=1; }
for (byte i=63;i<=100;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=39;i++) {
datawajah[13][i]=0; }
for (byte i=40;i<=62;i++) {
datawajah[13][i]=1; }
for (byte i=63;i<=100;i++) {
datawajah[13][i]=0; }


//Baris15
for (byte i=0;i<=37;i++) {
datawajah[14][i]=0; }
for (byte i=38;i<=62;i++) {
datawajah[14][i]=1; }
for (byte i=63;i<=100;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=36;i++) {
datawajah[15][i]=0; }
for (byte i=37;i<=63;i++) {
datawajah[15][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=0;i<=35;i++) {
datawajah[16][i]=0; }
for (byte i=36;i<=63;i++) {
datawajah[16][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[16][i]=0; }


//Baris18
for (byte i=0;i<=18;i++) {
datawajah[17][i]=0; }
for (byte i=19;i<=19;i++) {
datawajah[17][i]=1; }
for (byte i=20;i<=21;i++) {
datawajah[17][i]=0; }
for (byte i=22;i<=26;i++) {
datawajah[17][i]=1; }
for (byte i=27;i<=28;i++) {
datawajah[17][i]=0; }
for (byte i=29;i<=32;i++) {
datawajah[17][i]=1; }
for (byte i=33;i<=34;i++) {
datawajah[17][i]=0; }
for (byte i=35;i<=63;i++) {
datawajah[17][i]=1; }
for (byte i=64;i<=69;i++) {
datawajah[17][i]=0; }
for (byte i=70;i<=71;i++) {
datawajah[17][i]=1; }
for (byte i=72;i<=100;i++) {
datawajah[17][i]=0; }


//Baris19
for (byte i=0;i<=3;i++) {
datawajah[18][i]=1; }
for (byte i=4;i<=14;i++) {
datawajah[18][i]=0; }
for (byte i=15;i<=26;i++) {
datawajah[18][i]=1; }
for (byte i=27;i<=28;i++) {
datawajah[18][i]=0; }
for (byte i=29;i<=32;i++) {
datawajah[18][i]=1; }
for (byte i=33;i<=33;i++) {
datawajah[18][i]=0; }
for (byte i=34;i<=64;i++) {
datawajah[18][i]=1; }
for (byte i=65;i<=69;i++) {
datawajah[18][i]=0; }
for (byte i=70;i<=75;i++) {
datawajah[18][i]=1; }
for (byte i=76;i<=100;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=26;i++) {
datawajah[19][i]=1; }
for (byte i=27;i<=27;i++) {
datawajah[19][i]=0; }
for (byte i=28;i<=28;i++) {
datawajah[19][i]=1; }
for (byte i=29;i<=29;i++) {
datawajah[19][i]=0; }
for (byte i=30;i<=65;i++) {
datawajah[19][i]=1; }
for (byte i=66;i<=70;i++) {
datawajah[19][i]=0; }
for (byte i=71;i<=75;i++) {
datawajah[19][i]=1; }
for (byte i=76;i<=78;i++) {
datawajah[19][i]=0; }
for (byte i=79;i<=79;i++) {
datawajah[19][i]=1; }
for (byte i=80;i<=100;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=66;i++) {
datawajah[20][i]=1; }
for (byte i=67;i<=70;i++) {
datawajah[20][i]=0; }
for (byte i=71;i<=81;i++) {
datawajah[20][i]=1; }
for (byte i=82;i<=100;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=67;i++) {
datawajah[21][i]=1; }
for (byte i=68;i<=71;i++) {
datawajah[21][i]=0; }
for (byte i=72;i<=83;i++) {
datawajah[21][i]=1; }
for (byte i=84;i<=100;i++) {
datawajah[21][i]=0; }


//Baris23
for (byte i=0;i<=68;i++) {
datawajah[22][i]=1; }
for (byte i=69;i<=72;i++) {
datawajah[22][i]=0; }
for (byte i=73;i<=86;i++) {
datawajah[22][i]=1; }
for (byte i=87;i<=100;i++) {
datawajah[22][i]=0; }

}

dataset:: wajahkanan2()
{
  baris = 24;
  kolom = 107;
//Baris1
for (byte i=0;i<=10;i++) {
datawajah[0][i]=0; }
for (byte i=11;i<=16;i++) {
datawajah[0][i]=1; }
for (byte i=17;i<=45;i++) {
datawajah[0][i]=0; }
for (byte i=46;i<=64;i++) {
datawajah[0][i]=1; }
for (byte i=65;i<=80;i++) {
datawajah[0][i]=0; }
for (byte i=81;i<=101;i++) {
datawajah[0][i]=1; }
for (byte i=102;i<=106;i++) {
datawajah[0][i]=0; }

//Baris2
for (byte i=0;i<=44;i++) {
datawajah[1][i]=0; }
for (byte i=45;i<=62;i++) {
datawajah[1][i]=1; }
for (byte i=63;i<=80;i++) {
datawajah[1][i]=0; }
for (byte i=81;i<=102;i++) {
datawajah[1][i]=1; }
for (byte i=103;i<=106;i++) {
datawajah[1][i]=0; }


//Baris3
for (byte i=0;i<=44;i++) {
datawajah[2][i]=0; }
for (byte i=45;i<=62;i++) {
datawajah[2][i]=1; }
for (byte i=63;i<=81;i++) {
datawajah[2][i]=0; }
for (byte i=82;i<=104;i++) {
datawajah[2][i]=1; }
for (byte i=105;i<=106;i++) {
datawajah[2][i]=0; }


//Baris4
for (byte i=0;i<=37;i++) {
datawajah[3][i]=0; }
for (byte i=38;i<=38;i++) {
datawajah[3][i]=1; }
for (byte i=39;i<=44;i++) {
datawajah[3][i]=0; }
for (byte i=45;i<=62;i++) {
datawajah[3][i]=1; }
for (byte i=63;i<=92;i++) {
datawajah[3][i]=0; }
for (byte i=93;i<=99;i++) {
datawajah[3][i]=1; }
for (byte i=100;i<=106;i++) {
datawajah[3][i]=0; }


//Baris5
for (byte i=0;i<=44;i++) {
datawajah[4][i]=0; }
for (byte i=45;i<=62;i++) {
datawajah[4][i]=1; }
for (byte i=63;i<=95;i++) {
datawajah[4][i]=0; }
for (byte i=96;i<=96;i++) {
datawajah[4][i]=1; }
for (byte i=97;i<=106;i++) {
datawajah[4][i]=0; }


//Baris6
for (byte i=0;i<=21;i++) {
datawajah[5][i]=0; }
for (byte i=22;i<=23;i++) {
datawajah[5][i]=1; }
for (byte i=24;i<=44;i++) {
datawajah[5][i]=0; }
for (byte i=45;i<=63;i++) {
datawajah[5][i]=1; }
for (byte i=64;i<=85;i++) {
datawajah[5][i]=0; }
for (byte i=86;i<=87;i++) {
datawajah[5][i]=1; }
for (byte i=88;i<=106;i++) {
datawajah[5][i]=0; }

//Baris7
for (byte i=0;i<=20;i++) {
datawajah[6][i]=0; }
for (byte i=21;i<=23;i++) {
datawajah[6][i]=1; }
for (byte i=24;i<=43;i++) {
datawajah[6][i]=0; }
for (byte i=44;i<=63;i++) {
datawajah[6][i]=1; }
for (byte i=64;i<=106;i++) {
datawajah[6][i]=0; }


//Baris8
for (byte i=0;i<=20;i++) {
datawajah[7][i]=0; }
for (byte i=21;i<=21;i++) {
datawajah[7][i]=1; }
for (byte i=22;i<=42;i++) {
datawajah[7][i]=0; }
for (byte i=43;i<=63;i++) {
datawajah[7][i]=1; }
for (byte i=64;i<=106;i++) {
datawajah[7][i]=0; }


//Baris9
for (byte i=0;i<=42;i++) {
datawajah[8][i]=0; }
for (byte i=43;i<=63;i++) {
datawajah[8][i]=1; }
for (byte i=64;i<=106;i++) {
datawajah[8][i]=0; }


//Baris10
for (byte i=0;i<=41;i++) {
datawajah[9][i]=0; }
for (byte i=42;i<=63;i++) {
datawajah[9][i]=1; }
for (byte i=64;i<=77;i++) {
datawajah[9][i]=0; }
for (byte i=78;i<=78;i++) {
datawajah[9][i]=1; }
for (byte i=79;i<=85;i++) {
datawajah[9][i]=0; }
for (byte i=86;i<=86;i++) {
datawajah[9][i]=1; }
for (byte i=87;i<=106;i++) {
datawajah[9][i]=0; }


//Baris11
for (byte i=0;i<=39;i++) {
datawajah[10][i]=0; }
for (byte i=40;i<=64;i++) {
datawajah[10][i]=1; }
for (byte i=65;i<=106;i++) {
datawajah[10][i]=0; }


//Baris12
for (byte i=0;i<=36;i++) {
datawajah[11][i]=0; }
for (byte i=37;i<=64;i++) {
datawajah[11][i]=1; }
for (byte i=65;i<=106;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=27;i++) {
datawajah[12][i]=0; }
for (byte i=28;i<=29;i++) {
datawajah[12][i]=1; }
for (byte i=30;i<=31;i++) {
datawajah[12][i]=0; }
for (byte i=32;i<=33;i++) {
datawajah[12][i]=1; }
for (byte i=34;i<=35;i++) {
datawajah[12][i]=0; }
for (byte i=36;i<=64;i++) {
datawajah[12][i]=1; }
for (byte i=65;i<=106;i++) {
datawajah[12][i]=0; }


//Baris14
for (byte i=0;i<=3;i++) {
datawajah[13][i]=1; }
for (byte i=4;i<=18;i++) {
datawajah[13][i]=0; }
for (byte i=19;i<=29;i++) {
datawajah[13][i]=1; }
for (byte i=30;i<=31;i++) {
datawajah[13][i]=0; }
for (byte i=32;i<=65;i++) {
datawajah[13][i]=1; }
for (byte i=66;i<=106;i++) {
datawajah[13][i]=0; }


//Baris15
for (byte i=0;i<=6;i++) {
datawajah[14][i]=1; }
for (byte i=7;i<=16;i++) {
datawajah[14][i]=0; }
for (byte i=17;i<=65;i++) {
datawajah[14][i]=1; }
for (byte i=66;i<=106;i++) {
datawajah[14][i]=0; }


//Baris16
for (byte i=0;i<=65;i++) {
datawajah[15][i]=1; }
for (byte i=66;i<=106;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=0;i<=66;i++) {
datawajah[16][i]=1; }
for (byte i=67;i<=106;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=67;i++) {
datawajah[17][i]=1; }
for (byte i=68;i<=75;i++) {
datawajah[17][i]=0; }
for (byte i=76;i<=81;i++) {
datawajah[17][i]=1; }
for (byte i=82;i<=106;i++) {
datawajah[17][i]=0; }


//Baris19
for (byte i=0;i<=69;i++) {
datawajah[18][i]=1; }
for (byte i=70;i<=74;i++) {
datawajah[18][i]=0; }
for (byte i=75;i<=83;i++) {
datawajah[18][i]=1; }
for (byte i=84;i<=106;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=70;i++) {
datawajah[19][i]=1; }
for (byte i=71;i<=72;i++) {
datawajah[19][i]=0; }
for (byte i=73;i<=86;i++) {
datawajah[19][i]=1; }
for (byte i=87;i<=106;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=88;i++) {
datawajah[20][i]=1; }
for (byte i=89;i<=106;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=90;i++) {
datawajah[21][i]=1; }
for (byte i=91;i<=106;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=92;i++) {
datawajah[22][i]=1; }
for (byte i=93;i<=106;i++) {
datawajah[22][i]=0; }

//Baris24
for (byte i=0;i<=93;i++) {
datawajah[23][i]=1; }
for (byte i=94;i<=94;i++) {
datawajah[23][i]=0; }
for (byte i=95;i<=95;i++) {
datawajah[23][i]=1; }
for (byte i=96;i<=106;i++) {
datawajah[23][i]=0; }


}

dataset:: wajahkanan3()
{
  baris = 21;
  kolom = 95;
  
//Baris1
for (byte i=0;i<=4;i++) {
datawajah[0][i]=0; }
for (byte i=5;i<=8;i++) {
datawajah[0][i]=1; }
for (byte i=9;i<=37;i++) {
datawajah[0][i]=0; }
for (byte i=38;i<=52;i++) {
datawajah[0][i]=1; }
for (byte i=53;i<=73;i++) {
datawajah[0][i]=0; }
for (byte i=74;i<=93;i++) {
datawajah[0][i]=1; }

//Baris2
for (byte i=0;i<=38;i++) {
datawajah[1][i]=0; }
for (byte i=39;i<=53;i++) {
datawajah[1][i]=1; }
for (byte i=54;i<=72;i++) {
datawajah[1][i]=0; }
for (byte i=73;i<=93;i++) {
datawajah[1][i]=1; }

//Baris3
for (byte i=0;i<=39;i++) {
datawajah[2][i]=0; }
for (byte i=40;i<=54;i++) {
datawajah[2][i]=1; }
for (byte i=55;i<=72;i++) {
datawajah[2][i]=0; }
for (byte i=73;i<=75;i++) {
datawajah[2][i]=1; }
for (byte i=76;i<=78;i++) {
datawajah[2][i]=0; }
for (byte i=79;i<=81;i++) {
datawajah[2][i]=1; }
for (byte i=82;i<=82;i++) {
datawajah[2][i]=0; }
for (byte i=83;i<=93;i++) {
datawajah[2][i]=1; }

//Baris4
for (byte i=0;i<=38;i++) {
datawajah[3][i]=0; }
for (byte i=39;i<=55;i++) {
datawajah[3][i]=1; }
for (byte i=56;i<=86;i++) {
datawajah[3][i]=0; }
for (byte i=87;i<=93;i++) {
datawajah[3][i]=1; }


//Baris5
for (byte i=0;i<=39;i++) {
datawajah[4][i]=0; }
for (byte i=40;i<=55;i++) {
datawajah[4][i]=1; }
for (byte i=56;i<=77;i++) {
datawajah[4][i]=0; }
for (byte i=78;i<=79;i++) {
datawajah[4][i]=1; }
for (byte i=80;i<=93;i++) {
datawajah[4][i]=0; }

//Baris6
for (byte i=0;i<=39;i++) {
datawajah[5][i]=0; }
for (byte i=40;i<=55;i++) {
datawajah[5][i]=1; }
for (byte i=56;i<=93;i++) {
datawajah[5][i]=0; }

//Baris7
for (byte i=0;i<=12;i++) {
datawajah[6][i]=0; }
for (byte i=13;i<=16;i++) {
datawajah[6][i]=1; }
for (byte i=17;i<=38;i++) {
datawajah[6][i]=0; }
for (byte i=39;i<=55;i++) {
datawajah[6][i]=1; }
for (byte i=56;i<=93;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=12;i++) {
datawajah[7][i]=0; }
for (byte i=13;i<=16;i++) {
datawajah[7][i]=1; }
for (byte i=17;i<=38;i++) {
datawajah[7][i]=0; }
for (byte i=39;i<=55;i++) {
datawajah[7][i]=1; }
for (byte i=56;i<=93;i++) {
datawajah[7][i]=0; }


//Baris9
for (byte i=0;i<=11;i++) {
datawajah[8][i]=0; }
for (byte i=12;i<=15;i++) {
datawajah[8][i]=1; }
for (byte i=16;i<=37;i++) {
datawajah[8][i]=0; }
for (byte i=38;i<=56;i++) {
datawajah[8][i]=1; }
for (byte i=57;i<=93;i++) {
datawajah[8][i]=0; }


//Baris10
for (byte i=0;i<=37;i++) {
datawajah[9][i]=0; }
for (byte i=38;i<=56;i++) {
datawajah[9][i]=1; }
for (byte i=57;i<=69;i++) {
datawajah[9][i]=0; }
for (byte i=70;i<=70;i++) {
datawajah[9][i]=1; }
for (byte i=71;i<=93;i++) {
datawajah[9][i]=0; }


//Baris11
for (byte i=0;i<=36;i++) {
datawajah[10][i]=0; }
for (byte i=37;i<=57;i++) {
datawajah[10][i]=1; }
for (byte i=58;i<=93;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=36;i++) {
datawajah[11][i]=0; }
for (byte i=37;i<=57;i++) {
datawajah[11][i]=1; }
for (byte i=58;i<=93;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=34;i++) {
datawajah[12][i]=0; }
for (byte i=35;i<=57;i++) {
datawajah[12][i]=1; }
for (byte i=58;i<=93;i++) {
datawajah[12][i]=0; }


//Baris14
for (byte i=0;i<=33;i++) {
datawajah[13][i]=0; }
for (byte i=34;i<=57;i++) {
datawajah[13][i]=1; }
for (byte i=58;i<=93;i++) {
datawajah[13][i]=0; }


//Baris15
for (byte i=0;i<=31;i++) {
datawajah[14][i]=0; }
for (byte i=32;i<=57;i++) {
datawajah[14][i]=1; }
for (byte i=58;i<=64;i++) {
datawajah[14][i]=0; }
for (byte i=65;i<=65;i++) {
datawajah[14][i]=1; }
for (byte i=66;i<=93;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=12;i++) {
datawajah[15][i]=0; }
for (byte i=13;i<=14;i++) {
datawajah[15][i]=1; }
for (byte i=15;i<=31;i++) {
datawajah[15][i]=0; }
for (byte i=32;i<=58;i++) {
datawajah[15][i]=1; }
for (byte i=59;i<=63;i++) {
datawajah[15][i]=0; }
for (byte i=64;i<=66;i++) {
datawajah[15][i]=1; }
for (byte i=67;i<=93;i++) {
datawajah[15][i]=0; }

//Baris17
for (byte i=0;i<=1;i++) {
datawajah[16][i]=1; }
for (byte i=2;i<=3;i++) {
datawajah[16][i]=0; }
for (byte i=4;i<=15;i++) {
datawajah[16][i]=1; }
for (byte i=16;i<=25;i++) {
datawajah[16][i]=0; }
for (byte i=26;i<=27;i++) {
datawajah[16][i]=1; }
for (byte i=28;i<=30;i++) {
datawajah[16][i]=0; }
for (byte i=31;i<=58;i++) {
datawajah[16][i]=1; }
for (byte i=59;i<=63;i++) {
datawajah[16][i]=0; }
for (byte i=64;i<=67;i++) {
datawajah[16][i]=1; }
for (byte i=68;i<=93;i++) {
datawajah[16][i]=0; }


//Baris18
for (byte i=0;i<=17;i++) {
datawajah[17][i]=1; }
for (byte i=18;i<=24;i++) {
datawajah[17][i]=0; }
for (byte i=25;i<=59;i++) {
datawajah[17][i]=1; }
for (byte i=60;i<=64;i++) {
datawajah[17][i]=0; }
for (byte i=65;i<=72;i++) {
datawajah[17][i]=1; }
for (byte i=73;i<=73;i++) {
datawajah[17][i]=0; }
for (byte i=74;i<=74;i++) {
datawajah[17][i]=1; }
for (byte i=75;i<=93;i++) {
datawajah[17][i]=0; }


//Baris19
for (byte i=0;i<=22;i++) {
datawajah[18][i]=1; }
for (byte i=23;i<=23;i++) {
datawajah[18][i]=0; }
for (byte i=24;i<=59;i++) {
datawajah[18][i]=1; }
for (byte i=60;i<=65;i++) {
datawajah[18][i]=0; }
for (byte i=66;i<=76;i++) {
datawajah[18][i]=1; }
for (byte i=77;i<=93;i++) {
datawajah[18][i]=0; }


//Baris20
for (byte i=0;i<=60;i++) {
datawajah[19][i]=1; }
for (byte i=61;i<=65;i++) {
datawajah[19][i]=0; }
for (byte i=66;i<=78;i++) {
datawajah[19][i]=1; }
for (byte i=79;i<=93;i++) {
datawajah[19][i]=0; }


 //Baris21
for (byte i=0;i<=61;i++) {
datawajah[20][i]=1; }
for (byte i=62;i<=66;i++) {
datawajah[20][i]=0; }
for (byte i=67;i<=79;i++) {
datawajah[20][i]=1; }
for (byte i=80;i<=93;i++) {
datawajah[20][i]=0; }

}

dataset:: wajahkanan4()
{
  baris = 22 ;
  kolom = 95;
  //baris 1
//Baris1
for (byte i=0;i<=35;i++) {
datawajah[0][i]=0; }
for (byte i=36;i<=52;i++) {
datawajah[0][i]=1; }
for (byte i=53;i<=53;i++) {
datawajah[0][i]=0; }
for (byte i=54;i<=54;i++) {
datawajah[0][i]=1; }
for (byte i=55;i<=71;i++) {
datawajah[0][i]=0; }
for (byte i=72;i<=72;i++) {
datawajah[0][i]=1; }
for (byte i=73;i<=74;i++) {
datawajah[0][i]=0; }
for (byte i=75;i<=94;i++) {
datawajah[0][i]=1; }

//Baris2
for (byte i=0;i<=38;i++) {
datawajah[1][i]=0; }
for (byte i=39;i<=52;i++) {
datawajah[1][i]=1; }
for (byte i=53;i<=73;i++) {
datawajah[1][i]=0; }
for (byte i=74;i<=94;i++) {
datawajah[1][i]=1; }


//Baris3
for (byte i=0;i<=5;i++) {
datawajah[2][i]=0; }
for (byte i=6;i<=8;i++) {
datawajah[2][i]=1; }
for (byte i=9;i<=38;i++) {
datawajah[2][i]=0; }
for (byte i=39;i<=53;i++) {
datawajah[2][i]=1; }
for (byte i=54;i<=73;i++) {
datawajah[2][i]=0; }
for (byte i=74;i<=94;i++) {
datawajah[2][i]=1; }

//Baris4
for (byte i=0;i<=39;i++) {
datawajah[3][i]=0; }
for (byte i=40;i<=53;i++) {
datawajah[3][i]=1; }
for (byte i=54;i<=72;i++) {
datawajah[3][i]=0; }
for (byte i=73;i<=94;i++) {
datawajah[3][i]=1; }

//Baris5
for (byte i=0;i<=38;i++) {
datawajah[4][i]=0; }
for (byte i=39;i<=54;i++) {
datawajah[4][i]=1; }
for (byte i=55;i<=84;i++) {
datawajah[4][i]=0; }
for (byte i=85;i<=94;i++) {
datawajah[4][i]=1; }

//Baris6
for (byte i=0;i<=38;i++) {
datawajah[5][i]=0; }
for (byte i=39;i<=55;i++) {
datawajah[5][i]=1; }
for (byte i=56;i<=91;i++) {
datawajah[5][i]=0; }
for (byte i=92;i<=94;i++) {
datawajah[5][i]=1; }

//Baris7
for (byte i=0;i<=38;i++) {
datawajah[6][i]=0; }
for (byte i=39;i<=55;i++) {
datawajah[6][i]=1; }
for (byte i=56;i<=92;i++) {
datawajah[6][i]=0; }
for (byte i=93;i<=94;i++) {
datawajah[6][i]=1; }

//Baris8
for (byte i=0;i<=13;i++) {
datawajah[7][i]=0; }
for (byte i=14;i<=16;i++) {
datawajah[7][i]=1; }
for (byte i=17;i<=39;i++) {
datawajah[7][i]=0; }
for (byte i=40;i<=55;i++) {
datawajah[7][i]=1; }
for (byte i=56;i<=94;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=12;i++) {
datawajah[8][i]=0; }
for (byte i=13;i<=16;i++) {
datawajah[8][i]=1; }
for (byte i=17;i<=39;i++) {
datawajah[8][i]=0; }
for (byte i=40;i<=55;i++) {
datawajah[8][i]=1; }
for (byte i=56;i<=94;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=12;i++) {
datawajah[9][i]=0; }
for (byte i=13;i<=15;i++) {
datawajah[9][i]=1; }
for (byte i=16;i<=38;i++) {
datawajah[9][i]=0; }
for (byte i=39;i<=56;i++) {
datawajah[9][i]=1; }
for (byte i=57;i<=60;i++) {
datawajah[9][i]=0; }
for (byte i=61;i<=61;i++) {
datawajah[9][i]=1; }
for (byte i=62;i<=94;i++) {
datawajah[9][i]=0; }


//Baris11
for (byte i=0;i<=37;i++) {
datawajah[10][i]=0; }
for (byte i=38;i<=56;i++) {
datawajah[10][i]=1; }
for (byte i=57;i<=61;i++) {
datawajah[10][i]=0; }
for (byte i=62;i<=62;i++) {
datawajah[10][i]=1; }
for (byte i=63;i<=69;i++) {
datawajah[10][i]=0; }
for (byte i=70;i<=70;i++) {
datawajah[10][i]=1; }
for (byte i=71;i<=94;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=36;i++) {
datawajah[11][i]=0; }
for (byte i=37;i<=56;i++) {
datawajah[11][i]=1; }
for (byte i=57;i<=61;i++) {
datawajah[11][i]=0; }
for (byte i=62;i<=62;i++) {
datawajah[11][i]=1; }
for (byte i=63;i<=94;i++) {
datawajah[11][i]=0; }

//Baris13
for (byte i=0;i<=36;i++) {
datawajah[12][i]=0; }
for (byte i=37;i<=56;i++) {
datawajah[12][i]=1; }
for (byte i=57;i<=94;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=34;i++) {
datawajah[13][i]=0; }
for (byte i=35;i<=57;i++) {
datawajah[13][i]=1; }
for (byte i=58;i<=94;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=33;i++) {
datawajah[14][i]=0; }
for (byte i=34;i<=57;i++) {
datawajah[14][i]=1; }
for (byte i=58;i<=94;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=32;i++) {
datawajah[15][i]=0; }
for (byte i=33;i<=58;i++) {
datawajah[15][i]=1; }
for (byte i=59;i<=94;i++) {
datawajah[15][i]=0; }

//Baris17
for (byte i=0;i<=14;i++) {
datawajah[16][i]=0; }
for (byte i=15;i<=15;i++) {
datawajah[16][i]=1; }
for (byte i=16;i<=30;i++) {
datawajah[16][i]=0; }
for (byte i=31;i<=58;i++) {
datawajah[16][i]=1; }
for (byte i=59;i<=63;i++) {
datawajah[16][i]=0; }
for (byte i=64;i<=66;i++) {
datawajah[16][i]=1; }
for (byte i=67;i<=94;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=16;i++) {
datawajah[17][i]=1; }
for (byte i=17;i<=26;i++) {
datawajah[17][i]=0; }
for (byte i=27;i<=27;i++) {
datawajah[17][i]=1; }
for (byte i=28;i<=30;i++) {
datawajah[17][i]=0; }
for (byte i=31;i<=58;i++) {
datawajah[17][i]=1; }
for (byte i=59;i<=63;i++) {
datawajah[17][i]=0; }
for (byte i=64;i<=65;i++) {
datawajah[17][i]=1; }
for (byte i=66;i<=94;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=18;i++) {
datawajah[18][i]=1; }
for (byte i=19;i<=22;i++) {
datawajah[18][i]=0; }
for (byte i=23;i<=24;i++) {
datawajah[18][i]=1; }
for (byte i=25;i<=26;i++) {
datawajah[18][i]=0; }
for (byte i=27;i<=59;i++) {
datawajah[18][i]=1; }
for (byte i=60;i<=64;i++) {
datawajah[18][i]=0; }
for (byte i=65;i<=69;i++) {
datawajah[18][i]=1; }
for (byte i=70;i<=94;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=19;i++) {
datawajah[19][i]=1; }
for (byte i=20;i<=22;i++) {
datawajah[19][i]=0; }
for (byte i=23;i<=59;i++) {
datawajah[19][i]=1; }
for (byte i=60;i<=64;i++) {
datawajah[19][i]=0; }
for (byte i=65;i<=71;i++) {
datawajah[19][i]=1; }
for (byte i=72;i<=72;i++) {
datawajah[19][i]=0; }
for (byte i=73;i<=76;i++) {
datawajah[19][i]=1; }
for (byte i=77;i<=94;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=20;i++) {
datawajah[20][i]=1; }
for (byte i=21;i<=21;i++) {
datawajah[20][i]=0; }
for (byte i=22;i<=60;i++) {
datawajah[20][i]=1; }
for (byte i=61;i<=65;i++) {
datawajah[20][i]=0; }
for (byte i=66;i<=76;i++) {
datawajah[20][i]=1; }
for (byte i=77;i<=94;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=19;i++) {
datawajah[21][i]=1; }
for (byte i=20;i<=21;i++) {
datawajah[21][i]=0; }
for (byte i=22;i<=60;i++) {
datawajah[21][i]=1; }
for (byte i=61;i<=66;i++) {
datawajah[21][i]=0; }
for (byte i=67;i<=77;i++) {
datawajah[21][i]=1; }
for (byte i=78;i<=94;i++) {
datawajah[21][i]=0; }

}

dataset:: wajahkanan5()
{
  baris = 21;
  kolom = 92;
//Baris1
for (byte i=0;i<=36;i++) {
datawajah[0][i]=0; }
for (byte i=37;i<=51;i++) {
datawajah[0][i]=1; }
for (byte i=52;i<=74;i++) {
datawajah[0][i]=0; }
for (byte i=75;i<=91;i++) {
datawajah[0][i]=1; }


//Baris2
for (byte i=0;i<=4;i++) {
datawajah[1][i]=0; }
for (byte i=5;i<=7;i++) {
datawajah[1][i]=1; }
for (byte i=8;i<=37;i++) {
datawajah[1][i]=0; }
for (byte i=38;i<=52;i++) {
datawajah[1][i]=1; }
for (byte i=53;i<=73;i++) {
datawajah[1][i]=0; }
for (byte i=74;i<=91;i++) {
datawajah[1][i]=1; }


//Baris3
for (byte i=0;i<=4;i++) {
datawajah[2][i]=0; }
for (byte i=5;i<=8;i++) {
datawajah[2][i]=1; }
for (byte i=9;i<=38;i++) {
datawajah[2][i]=0; }
for (byte i=39;i<=52;i++) {
datawajah[2][i]=1; }
for (byte i=53;i<=73;i++) {
datawajah[2][i]=0; }
for (byte i=74;i<=91;i++) {
datawajah[2][i]=1; }

//Baris4
for (byte i=0;i<=37;i++) {
datawajah[3][i]=0; }
for (byte i=38;i<=52;i++) {
datawajah[3][i]=1; }
for (byte i=53;i<=71;i++) {
datawajah[3][i]=0; }
for (byte i=72;i<=72;i++) {
datawajah[3][i]=1; }
for (byte i=73;i<=73;i++) {
datawajah[3][i]=0; }
for (byte i=74;i<=91;i++) {
datawajah[3][i]=1; }

//Baris5
for (byte i=0;i<=38;i++) {
datawajah[4][i]=0; }
for (byte i=39;i<=53;i++) {
datawajah[4][i]=1; }
for (byte i=54;i<=84;i++) {
datawajah[4][i]=0; }
for (byte i=85;i<=91;i++) {
datawajah[4][i]=1; }

//Baris6
for (byte i=0;i<=38;i++) {
datawajah[5][i]=0; }
for (byte i=39;i<=54;i++) {
datawajah[5][i]=1; }
for (byte i=55;i<=90;i++) {
datawajah[5][i]=0; }
for (byte i=91;i<=91;i++) {
datawajah[5][i]=1; }


//Baris7
for (byte i=0;i<=38;i++) {
datawajah[6][i]=0; }
for (byte i=39;i<=54;i++) {
datawajah[6][i]=1; }
for (byte i=55;i<=91;i++) {
datawajah[6][i]=0; }


//Baris8
for (byte i=0;i<=12;i++) {
datawajah[7][i]=0; }
for (byte i=13;i<=16;i++) {
datawajah[7][i]=1; }
for (byte i=17;i<=38;i++) {
datawajah[7][i]=0; }
for (byte i=39;i<=54;i++) {
datawajah[7][i]=1; }
for (byte i=55;i<=91;i++) {
datawajah[7][i]=0; }


//Baris9
for (byte i=0;i<=12;i++) {
datawajah[8][i]=0; }
for (byte i=13;i<=16;i++) {
datawajah[8][i]=1; }
for (byte i=17;i<=37;i++) {
datawajah[8][i]=0; }
for (byte i=38;i<=55;i++) {
datawajah[8][i]=1; }
for (byte i=56;i<=91;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=11;i++) {
datawajah[9][i]=0; }
for (byte i=12;i<=15;i++) {
datawajah[9][i]=1; }
for (byte i=16;i<=37;i++) {
datawajah[9][i]=0; }
for (byte i=38;i<=55;i++) {
datawajah[9][i]=1; }
for (byte i=56;i<=61;i++) {
datawajah[9][i]=0; }
for (byte i=62;i<=62;i++) {
datawajah[9][i]=1; }
for (byte i=63;i<=91;i++) {
datawajah[9][i]=0; }

//Baris11
for (byte i=0;i<=36;i++) {
datawajah[10][i]=0; }
for (byte i=37;i<=55;i++) {
datawajah[10][i]=1; }
for (byte i=56;i<=61;i++) {
datawajah[10][i]=0; }
for (byte i=62;i<=62;i++) {
datawajah[10][i]=1; }
for (byte i=63;i<=69;i++) {
datawajah[10][i]=0; }
for (byte i=70;i<=70;i++) {
datawajah[10][i]=1; }
for (byte i=71;i<=91;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=35;i++) {
datawajah[11][i]=0; }
for (byte i=36;i<=56;i++) {
datawajah[11][i]=1; }
for (byte i=57;i<=91;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=34;i++) {
datawajah[12][i]=0; }
for (byte i=35;i<=56;i++) {
datawajah[12][i]=1; }
for (byte i=57;i<=91;i++) {
datawajah[12][i]=0; }


//Baris14
for (byte i=0;i<=5;i++) {
datawajah[13][i]=0; }
for (byte i=6;i<=6;i++) {
datawajah[13][i]=1; }
for (byte i=7;i<=33;i++) {
datawajah[13][i]=0; }
for (byte i=34;i<=56;i++) {
datawajah[13][i]=1; }
for (byte i=57;i<=91;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=33;i++) {
datawajah[14][i]=0; }
for (byte i=34;i<=57;i++) {
datawajah[14][i]=1; }
for (byte i=58;i<=91;i++) {
datawajah[14][i]=0; }


//Baris16
for (byte i=0;i<=30;i++) {
datawajah[15][i]=0; }
for (byte i=31;i<=57;i++) {
datawajah[15][i]=1; }
for (byte i=58;i<=91;i++) {
datawajah[15][i]=0; }

//Baris17
for (byte i=0;i<=9;i++) {
datawajah[16][i]=0; }
for (byte i=10;i<=11;i++) {
datawajah[16][i]=1; }
for (byte i=12;i<=30;i++) {
datawajah[16][i]=0; }
for (byte i=31;i<=57;i++) {
datawajah[16][i]=1; }
for (byte i=58;i<=64;i++) {
datawajah[16][i]=0; }
for (byte i=65;i<=65;i++) {
datawajah[16][i]=1; }
for (byte i=66;i<=91;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=0;i++) {
datawajah[17][i]=1; }
for (byte i=1;i<=4;i++) {
datawajah[17][i]=0; }
for (byte i=5;i<=17;i++) {
datawajah[17][i]=1; }
for (byte i=18;i<=23;i++) {
datawajah[17][i]=0; }
for (byte i=24;i<=27;i++) {
datawajah[17][i]=1; }
for (byte i=28;i<=29;i++) {
datawajah[17][i]=0; }
for (byte i=30;i<=57;i++) {
datawajah[17][i]=1; }
for (byte i=58;i<=91;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=18;i++) {
datawajah[18][i]=1; }
for (byte i=19;i<=22;i++) {
datawajah[18][i]=0; }
for (byte i=23;i<=57;i++) {
datawajah[18][i]=1; }
for (byte i=58;i<=64;i++) {
datawajah[18][i]=0; }
for (byte i=65;i<=67;i++) {
datawajah[18][i]=1; }
for (byte i=68;i<=91;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=58;i++) {
datawajah[19][i]=1; }
for (byte i=59;i<=65;i++) {
datawajah[19][i]=0; }
for (byte i=66;i<=70;i++) {
datawajah[19][i]=1; }
for (byte i=71;i<=73;i++) {
datawajah[19][i]=0; }
for (byte i=74;i<=74;i++) {
datawajah[19][i]=1; }
for (byte i=75;i<=91;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=59;i++) {
datawajah[20][i]=1; }
for (byte i=60;i<=66;i++) {
datawajah[20][i]=0; }
for (byte i=67;i<=75;i++) {
datawajah[20][i]=1; }
for (byte i=76;i<=91;i++) {
datawajah[20][i]=0; }

}

dataset:: wajahkanan6()
{
  baris = 24 ;
  kolom = 104;
//Baris1
for (byte i=0;i<=11;i++) {
datawajah[0][i]=0; }
for (byte i=12;i<=12;i++) {
datawajah[0][i]=1; }
for (byte i=13;i<=39;i++) {
datawajah[0][i]=0; }
for (byte i=40;i<=40;i++) {
datawajah[0][i]=1; }
for (byte i=41;i<=41;i++) {
datawajah[0][i]=0; }
for (byte i=42;i<=58;i++) {
datawajah[0][i]=1; }
for (byte i=59;i<=60;i++) {
datawajah[0][i]=0; }
for (byte i=61;i<=61;i++) {
datawajah[0][i]=1; }
for (byte i=62;i<=76;i++) {
datawajah[0][i]=0; }
for (byte i=77;i<=79;i++) {
datawajah[0][i]=1; }
for (byte i=80;i<=80;i++) {
datawajah[0][i]=0; }
for (byte i=81;i<=100;i++) {
datawajah[0][i]=1; }
for (byte i=101;i<=101;i++) {
datawajah[0][i]=0; }
for (byte i=102;i<=103;i++) {
datawajah[0][i]=1; }

//Baris2
for (byte i=0;i<=9;i++) {
datawajah[1][i]=0; }
for (byte i=10;i<=13;i++) {
datawajah[1][i]=1; }
for (byte i=14;i<=42;i++) {
datawajah[1][i]=0; }
for (byte i=43;i<=58;i++) {
datawajah[1][i]=1; }
for (byte i=59;i<=76;i++) {
datawajah[1][i]=0; }
for (byte i=77;i<=78;i++) {
datawajah[1][i]=1; }
for (byte i=79;i<=80;i++) {
datawajah[1][i]=0; }
for (byte i=81;i<=103;i++) {
datawajah[1][i]=1; }

//Baris3
for (byte i=0;i<=12;i++) {
datawajah[2][i]=0; }
for (byte i=13;i<=13;i++) {
datawajah[2][i]=1; }
for (byte i=14;i<=43;i++) {
datawajah[2][i]=0; }
for (byte i=44;i<=58;i++) {
datawajah[2][i]=1; }
for (byte i=59;i<=79;i++) {
datawajah[2][i]=0; }
for (byte i=80;i<=103;i++) {
datawajah[2][i]=1; }

//Baris4
for (byte i=0;i<=43;i++) {
datawajah[3][i]=0; }
for (byte i=44;i<=57;i++) {
datawajah[3][i]=1; }
for (byte i=58;i<=78;i++) {
datawajah[3][i]=0; }
for (byte i=79;i<=103;i++) {
datawajah[3][i]=1; }


//Baris5
for (byte i=0;i<=43;i++) {
datawajah[4][i]=0; }
for (byte i=44;i<=59;i++) {
datawajah[4][i]=1; }
for (byte i=60;i<=81;i++) {
datawajah[4][i]=0; }
for (byte i=82;i<=103;i++) {
datawajah[4][i]=1; }

//Baris6
for (byte i=0;i<=43;i++) {
datawajah[5][i]=0; }
for (byte i=44;i<=60;i++) {
datawajah[5][i]=1; }
for (byte i=61;i<=89;i++) {
datawajah[5][i]=0; }
for (byte i=90;i<=103;i++) {
datawajah[5][i]=1; }


//Baris7
for (byte i=0;i<=43;i++) {
datawajah[6][i]=0; }
for (byte i=44;i<=60;i++) {
datawajah[6][i]=1; }
for (byte i=61;i<=82;i++) {
datawajah[6][i]=0; }
for (byte i=83;i<=84;i++) {
datawajah[6][i]=1; }
for (byte i=85;i<=95;i++) {
datawajah[6][i]=0; }
for (byte i=96;i<=103;i++) {
datawajah[6][i]=1; }

//Baris8
for (byte i=0;i<=17;i++) {
datawajah[7][i]=0; }
for (byte i=18;i<=21;i++) {
datawajah[7][i]=1; }
for (byte i=22;i<=42;i++) {
datawajah[7][i]=0; }
for (byte i=43;i<=60;i++) {
datawajah[7][i]=1; }
for (byte i=61;i<=99;i++) {
datawajah[7][i]=0; }
for (byte i=100;i<=103;i++) {
datawajah[7][i]=1; }

//Baris9
for (byte i=0;i<=17;i++) {
datawajah[8][i]=0; }
for (byte i=18;i<=21;i++) {
datawajah[8][i]=1; }
for (byte i=22;i<=42;i++) {
datawajah[8][i]=0; }
for (byte i=43;i<=60;i++) {
datawajah[8][i]=1; }
for (byte i=61;i<=100;i++) {
datawajah[8][i]=0; }
for (byte i=101;i<=103;i++) {
datawajah[8][i]=1; }

//Baris10
for (byte i=0;i<=16;i++) {
datawajah[9][i]=0; }
for (byte i=17;i<=20;i++) {
datawajah[9][i]=1; }
for (byte i=21;i<=42;i++) {
datawajah[9][i]=0; }
for (byte i=43;i<=60;i++) {
datawajah[9][i]=1; }
for (byte i=61;i<=100;i++) {
datawajah[9][i]=0; }
for (byte i=101;i<=103;i++) {
datawajah[9][i]=1; }


//Baris11
for (byte i=0;i<=41;i++) {
datawajah[10][i]=0; }
for (byte i=42;i<=60;i++) {
datawajah[10][i]=1; }
for (byte i=61;i<=66;i++) {
datawajah[10][i]=0; }
for (byte i=67;i<=67;i++) {
datawajah[10][i]=1; }
for (byte i=68;i<=82;i++) {
datawajah[10][i]=0; }
for (byte i=83;i<=83;i++) {
datawajah[10][i]=1; }
for (byte i=84;i<=100;i++) {
datawajah[10][i]=0; }
for (byte i=101;i<=103;i++) {
datawajah[10][i]=1; }

//Baris12
for (byte i=0;i<=40;i++) {
datawajah[11][i]=0; }
for (byte i=41;i<=61;i++) {
datawajah[11][i]=1; }
for (byte i=62;i<=66;i++) {
datawajah[11][i]=0; }
for (byte i=67;i<=67;i++) {
datawajah[11][i]=1; }
for (byte i=68;i<=74;i++) {
datawajah[11][i]=0; }
for (byte i=75;i<=75;i++) {
datawajah[11][i]=1; }
for (byte i=76;i<=101;i++) {
datawajah[11][i]=0; }
for (byte i=102;i<=103;i++) {
datawajah[11][i]=1; }

//Baris13
for (byte i=0;i<=39;i++) {
datawajah[12][i]=0; }
for (byte i=40;i<=61;i++) {
datawajah[12][i]=1; }
for (byte i=62;i<=101;i++) {
datawajah[12][i]=0; }
for (byte i=102;i<=103;i++) {
datawajah[12][i]=1; }

//Baris14
for (byte i=0;i<=38;i++) {
datawajah[13][i]=0; }
for (byte i=39;i<=61;i++) {
datawajah[13][i]=1; }
for (byte i=62;i<=102;i++) {
datawajah[13][i]=0; }
for (byte i=103;i<=103;i++) {
datawajah[13][i]=1; }

//Baris15
for (byte i=0;i<=37;i++) {
datawajah[14][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[14][i]=1; }
for (byte i=62;i<=103;i++) {
datawajah[14][i]=0; }


//Baris16
for (byte i=0;i<=0;i++) {
datawajah[15][i]=1; }
for (byte i=1;i<=35;i++) {
datawajah[15][i]=0; }
for (byte i=36;i<=62;i++) {
datawajah[15][i]=1; }
for (byte i=63;i<=103;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=0;i<=3;i++) {
datawajah[16][i]=1; }
for (byte i=4;i<=13;i++) {
datawajah[16][i]=0; }
for (byte i=14;i<=18;i++) {
datawajah[16][i]=1; }
for (byte i=19;i<=34;i++) {
datawajah[16][i]=0; }
for (byte i=35;i<=62;i++) {
datawajah[16][i]=1; }
for (byte i=63;i<=68;i++) {
datawajah[16][i]=0; }
for (byte i=69;i<=69;i++) {
datawajah[16][i]=1; }
for (byte i=70;i<=103;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=21;i++) {
datawajah[17][i]=1; }
for (byte i=22;i<=25;i++) {
datawajah[17][i]=0; }
for (byte i=26;i<=26;i++) {
datawajah[17][i]=1; }
for (byte i=27;i<=29;i++) {
datawajah[17][i]=0; }
for (byte i=30;i<=33;i++) {
datawajah[17][i]=1; }
for (byte i=34;i<=34;i++) {
datawajah[17][i]=0; }
for (byte i=35;i<=62;i++) {
datawajah[17][i]=1; }
for (byte i=63;i<=67;i++) {
datawajah[17][i]=0; }
for (byte i=68;i<=71;i++) {
datawajah[17][i]=1; }
for (byte i=72;i<=103;i++) {
datawajah[17][i]=0; }


//Baris19
for (byte i=0;i<=25;i++) {
datawajah[18][i]=1; }
for (byte i=26;i<=28;i++) {
datawajah[18][i]=0; }
for (byte i=29;i<=63;i++) {
datawajah[18][i]=1; }
for (byte i=64;i<=68;i++) {
datawajah[18][i]=0; }
for (byte i=69;i<=72;i++) {
datawajah[18][i]=1; }
for (byte i=73;i<=103;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=25;i++) {
datawajah[19][i]=1; }
for (byte i=26;i<=27;i++) {
datawajah[19][i]=0; }
for (byte i=28;i<=63;i++) {
datawajah[19][i]=1; }
for (byte i=64;i<=69;i++) {
datawajah[19][i]=0; }
for (byte i=70;i<=79;i++) {
datawajah[19][i]=1; }
for (byte i=80;i<=103;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=63;i++) {
datawajah[20][i]=1; }
for (byte i=64;i<=70;i++) {
datawajah[20][i]=0; }
for (byte i=71;i<=82;i++) {
datawajah[20][i]=1; }
for (byte i=83;i<=103;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=65;i++) {
datawajah[21][i]=1; }
for (byte i=66;i<=70;i++) {
datawajah[21][i]=0; }
for (byte i=71;i<=83;i++) {
datawajah[21][i]=1; }
for (byte i=84;i<=103;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=65;i++) {
datawajah[22][i]=1; }
for (byte i=66;i<=70;i++) {
datawajah[22][i]=0; }
for (byte i=71;i<=83;i++) {
datawajah[22][i]=1; }
for (byte i=84;i<=103;i++) {
datawajah[22][i]=0; }

//Baris24
for (byte i=0;i<=66;i++) {
datawajah[23][i]=1; }
for (byte i=67;i<=70;i++) {
datawajah[23][i]=0; }
for (byte i=71;i<=88;i++) {
datawajah[23][i]=1; }
for (byte i=89;i<=103;i++) {
datawajah[23][i]=0; }


}

dataset:: wajahkanan7()
{
  baris = 22;
  kolom = 98;
//Baris1
for (byte i=0;i<=36;i++) {
datawajah[0][i]=0; }
for (byte i=37;i<=54;i++) {
datawajah[0][i]=1; }
for (byte i=55;i<=74;i++) {
datawajah[0][i]=0; }
for (byte i=75;i<=97;i++) {
datawajah[0][i]=1; }

//Baris2
for (byte i=0;i<=6;i++) {
datawajah[1][i]=0; }
for (byte i=7;i<=9;i++) {
datawajah[1][i]=1; }
for (byte i=10;i<=38;i++) {
datawajah[1][i]=0; }
for (byte i=39;i<=53;i++) {
datawajah[1][i]=1; }
for (byte i=54;i<=76;i++) {
datawajah[1][i]=0; }
for (byte i=77;i<=97;i++) {
datawajah[1][i]=1; }

//Baris3
for (byte i=0;i<=6;i++) {
datawajah[2][i]=0; }
for (byte i=7;i<=9;i++) {
datawajah[2][i]=1; }
for (byte i=10;i<=38;i++) {
datawajah[2][i]=0; }
for (byte i=39;i<=53;i++) {
datawajah[2][i]=1; }
for (byte i=54;i<=75;i++) {
datawajah[2][i]=0; }
for (byte i=76;i<=97;i++) {
datawajah[2][i]=1; }

//Baris4
for (byte i=0;i<=39;i++) {
datawajah[3][i]=0; }
for (byte i=40;i<=54;i++) {
datawajah[3][i]=1; }
for (byte i=55;i<=74;i++) {
datawajah[3][i]=0; }
for (byte i=75;i<=97;i++) {
datawajah[3][i]=1; }

//Baris5
for (byte i=0;i<=39;i++) {
datawajah[4][i]=0; }
for (byte i=40;i<=55;i++) {
datawajah[4][i]=1; }
for (byte i=56;i<=81;i++) {
datawajah[4][i]=0; }
for (byte i=82;i<=97;i++) {
datawajah[4][i]=1; }


//Baris6
for (byte i=0;i<=39;i++) {
datawajah[5][i]=0; }
for (byte i=40;i<=56;i++) {
datawajah[5][i]=1; }
for (byte i=57;i<=88;i++) {
datawajah[5][i]=0; }
for (byte i=89;i<=97;i++) {
datawajah[5][i]=1; }

//Baris7
for (byte i=0;i<=39;i++) {
datawajah[6][i]=0; }
for (byte i=40;i<=56;i++) {
datawajah[6][i]=1; }
for (byte i=57;i<=95;i++) {
datawajah[6][i]=0; }
for (byte i=96;i<=97;i++) {
datawajah[6][i]=1; }

//Baris8
for (byte i=0;i<=14;i++) {
datawajah[7][i]=0; }
for (byte i=15;i<=18;i++) {
datawajah[7][i]=1; }
for (byte i=19;i<=39;i++) {
datawajah[7][i]=0; }
for (byte i=40;i<=56;i++) {
datawajah[7][i]=1; }
for (byte i=57;i<=96;i++) {
datawajah[7][i]=0; }
for (byte i=97;i<=97;i++) {
datawajah[7][i]=1; }


//Baris9
for (byte i=0;i<=13;i++) {
datawajah[8][i]=0; }
for (byte i=14;i<=18;i++) {
datawajah[8][i]=1; }
for (byte i=19;i<=39;i++) {
datawajah[8][i]=0; }
for (byte i=40;i<=56;i++) {
datawajah[8][i]=1; }
for (byte i=57;i<=97;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=13;i++) {
datawajah[9][i]=0; }
for (byte i=14;i<=16;i++) {
datawajah[9][i]=1; }
for (byte i=17;i<=38;i++) {
datawajah[9][i]=0; }
for (byte i=39;i<=57;i++) {
datawajah[9][i]=1; }
for (byte i=58;i<=61;i++) {
datawajah[9][i]=0; }
for (byte i=62;i<=63;i++) {
datawajah[9][i]=1; }
for (byte i=64;i<=97;i++) {
datawajah[9][i]=0; }

//Baris11
for (byte i=0;i<=37;i++) {
datawajah[10][i]=0; }
for (byte i=38;i<=57;i++) {
datawajah[10][i]=1; }
for (byte i=58;i<=63;i++) {
datawajah[10][i]=0; }
for (byte i=64;i<=64;i++) {
datawajah[10][i]=1; }
for (byte i=65;i<=97;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=37;i++) {
datawajah[11][i]=0; }
for (byte i=38;i<=57;i++) {
datawajah[11][i]=1; }
for (byte i=58;i<=97;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=37;i++) {
datawajah[12][i]=0; }
for (byte i=38;i<=57;i++) {
datawajah[12][i]=1; }
for (byte i=58;i<=97;i++) {
datawajah[12][i]=0; }


//Baris14
for (byte i=0;i<=35;i++) {
datawajah[13][i]=0; }
for (byte i=36;i<=58;i++) {
datawajah[13][i]=1; }
for (byte i=59;i<=97;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=34;i++) {
datawajah[14][i]=0; }
for (byte i=35;i<=58;i++) {
datawajah[14][i]=1; }
for (byte i=59;i<=97;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=33;i++) {
datawajah[15][i]=0; }
for (byte i=34;i<=58;i++) {
datawajah[15][i]=1; }
for (byte i=59;i<=97;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=0;i<=12;i++) {
datawajah[16][i]=0; }
for (byte i=13;i<=15;i++) {
datawajah[16][i]=1; }
for (byte i=16;i<=32;i++) {
datawajah[16][i]=0; }
for (byte i=33;i<=59;i++) {
datawajah[16][i]=1; }
for (byte i=60;i<=64;i++) {
datawajah[16][i]=0; }
for (byte i=65;i<=66;i++) {
datawajah[16][i]=1; }
for (byte i=67;i<=97;i++) {
datawajah[16][i]=0; }


//Baris18
for (byte i=0;i<=0;i++) {
datawajah[17][i]=1; }
for (byte i=1;i<=3;i++) {
datawajah[17][i]=0; }
for (byte i=4;i<=6;i++) {
datawajah[17][i]=1; }
for (byte i=7;i<=10;i++) {
datawajah[17][i]=0; }
for (byte i=11;i<=16;i++) {
datawajah[17][i]=1; }
for (byte i=17;i<=25;i++) {
datawajah[17][i]=0; }
for (byte i=26;i<=28;i++) {
datawajah[17][i]=1; }
for (byte i=29;i<=31;i++) {
datawajah[17][i]=0; }
for (byte i=32;i<=59;i++) {
datawajah[17][i]=1; }
for (byte i=60;i<=64;i++) {
datawajah[17][i]=0; }
for (byte i=65;i<=67;i++) {
datawajah[17][i]=1; }
for (byte i=68;i<=97;i++) {
datawajah[17][i]=0; }


//Baris19
for (byte i=0;i<=17;i++) {
datawajah[18][i]=1; }
for (byte i=18;i<=19;i++) {
datawajah[18][i]=0; }
for (byte i=20;i<=22;i++) {
datawajah[18][i]=1; }
for (byte i=23;i<=25;i++) {
datawajah[18][i]=0; }
for (byte i=26;i<=59;i++) {
datawajah[18][i]=1; }
for (byte i=60;i<=65;i++) {
datawajah[18][i]=0; }
for (byte i=66;i<=69;i++) {
datawajah[18][i]=1; }
for (byte i=70;i<=97;i++) {
datawajah[18][i]=0; }

 //Baris20
for (byte i=0;i<=21;i++) {
datawajah[19][i]=1; }
for (byte i=22;i<=23;i++) {
datawajah[19][i]=0; }
for (byte i=24;i<=60;i++) {
datawajah[19][i]=1; }
for (byte i=61;i<=65;i++) {
datawajah[19][i]=0; }
for (byte i=66;i<=67;i++) {
datawajah[19][i]=1; }
for (byte i=68;i<=68;i++) {
datawajah[19][i]=0; }
for (byte i=69;i<=70;i++) {
datawajah[19][i]=1; }
for (byte i=71;i<=73;i++) {
datawajah[19][i]=0; }
for (byte i=74;i<=75;i++) {
datawajah[19][i]=1; }
for (byte i=76;i<=97;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=19;i++) {
datawajah[20][i]=1; }
for (byte i=20;i<=20;i++) {
datawajah[20][i]=0; }
for (byte i=21;i<=60;i++) {
datawajah[20][i]=1; }
for (byte i=61;i<=66;i++) {
datawajah[20][i]=0; }
for (byte i=67;i<=77;i++) {
datawajah[20][i]=1; }
for (byte i=78;i<=97;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=61;i++) {
datawajah[21][i]=1; }
for (byte i=62;i<=67;i++) {
datawajah[21][i]=0; }
for (byte i=68;i<=79;i++) {
datawajah[21][i]=1; }
for (byte i=80;i<=97;i++) {
datawajah[21][i]=0; }


}

dataset:: wajahkanan8 ()
{
  baris =22;
  kolom = 98;
//Baris1
for (byte i=0;i<=23;i++) {
datawajah[0][i]=1; }
for (byte i=24;i<=28;i++) {
datawajah[0][i]=0; }
for (byte i=29;i<=55;i++) {
datawajah[0][i]=1; }
for (byte i=56;i<=56;i++) {
datawajah[0][i]=0; }
for (byte i=57;i<=57;i++) {
datawajah[0][i]=1; }
for (byte i=58;i<=58;i++) {
datawajah[0][i]=0; }
for (byte i=59;i<=79;i++) {
datawajah[0][i]=1; }
for (byte i=80;i<=96;i++) {
datawajah[0][i]=0; }
for (byte i=97;i<=97;i++) {
datawajah[0][i]=1; }


//Baris2
for (byte i=0;i<=6;i++) {
datawajah[1][i]=1; }
for (byte i=7;i<=19;i++) {
datawajah[1][i]=0; }
for (byte i=20;i<=25;i++) {
datawajah[1][i]=1; }
for (byte i=26;i<=29;i++) {
datawajah[1][i]=0; }
for (byte i=30;i<=55;i++) {
datawajah[1][i]=1; }
for (byte i=56;i<=59;i++) {
datawajah[1][i]=0; }
for (byte i=60;i<=75;i++) {
datawajah[1][i]=1; }
for (byte i=76;i<=97;i++) {
datawajah[1][i]=0; }

//Baris3
for (byte i=0;i<=3;i++) {
datawajah[2][i]=1; }
for (byte i=4;i<=5;i++) {
datawajah[2][i]=0; }
for (byte i=6;i<=15;i++) {
datawajah[2][i]=1; }
for (byte i=16;i<=21;i++) {
datawajah[2][i]=0; }
for (byte i=22;i<=25;i++) {
datawajah[2][i]=1; }
for (byte i=26;i<=30;i++) {
datawajah[2][i]=0; }
for (byte i=31;i<=56;i++) {
datawajah[2][i]=1; }
for (byte i=57;i<=63;i++) {
datawajah[2][i]=0; }
for (byte i=64;i<=73;i++) {
datawajah[2][i]=1; }
for (byte i=74;i<=78;i++) {
datawajah[2][i]=0; }
for (byte i=79;i<=80;i++) {
datawajah[2][i]=1; }
for (byte i=81;i<=97;i++) {
datawajah[2][i]=0; }


//Baris4
for (byte i=0;i<=3;i++) {
datawajah[3][i]=0; }
for (byte i=4;i<=16;i++) {
datawajah[3][i]=1; }
for (byte i=17;i<=31;i++) {
datawajah[3][i]=0; }
for (byte i=32;i<=57;i++) {
datawajah[3][i]=1; }
for (byte i=58;i<=62;i++) {
datawajah[3][i]=0; }
for (byte i=63;i<=72;i++) {
datawajah[3][i]=1; }
for (byte i=73;i<=97;i++) {
datawajah[3][i]=0; }

//Baris5
for (byte i=0;i<=16;i++) {
datawajah[4][i]=1; }
for (byte i=17;i<=30;i++) {
datawajah[4][i]=0; }
for (byte i=31;i<=57;i++) {
datawajah[4][i]=1; }
for (byte i=58;i<=62;i++) {
datawajah[4][i]=0; }
for (byte i=63;i<=70;i++) {
datawajah[4][i]=1; }
for (byte i=71;i<=97;i++) {
datawajah[4][i]=0; }

//Baris6
for (byte i=0;i<=11;i++) {
datawajah[5][i]=1; }
for (byte i=12;i<=31;i++) {
datawajah[5][i]=0; }
for (byte i=32;i<=57;i++) {
datawajah[5][i]=1; }
for (byte i=58;i<=62;i++) {
datawajah[5][i]=0; }
for (byte i=63;i<=68;i++) {
datawajah[5][i]=1; }
for (byte i=69;i<=97;i++) {
datawajah[5][i]=0; }


//Baris7
for (byte i=0;i<=6;i++) {
datawajah[6][i]=1; }
for (byte i=7;i<=31;i++) {
datawajah[6][i]=0; }
for (byte i=32;i<=57;i++) {
datawajah[6][i]=1; }
for (byte i=58;i<=63;i++) {
datawajah[6][i]=0; }
for (byte i=64;i<=68;i++) {
datawajah[6][i]=1; }
for (byte i=69;i<=76;i++) {
datawajah[6][i]=0; }
for (byte i=77;i<=79;i++) {
datawajah[6][i]=1; }
for (byte i=80;i<=97;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=2;i++) {
datawajah[7][i]=1; }
for (byte i=3;i<=32;i++) {
datawajah[7][i]=0; }
for (byte i=33;i<=57;i++) {
datawajah[7][i]=1; }
for (byte i=58;i<=64;i++) {
datawajah[7][i]=0; }
for (byte i=65;i<=67;i++) {
datawajah[7][i]=1; }
for (byte i=68;i<=74;i++) {
datawajah[7][i]=0; }
for (byte i=75;i<=79;i++) {
datawajah[7][i]=1; }
for (byte i=80;i<=97;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=33;i++) {
datawajah[8][i]=0; }
for (byte i=34;i<=58;i++) {
datawajah[8][i]=1; }
for (byte i=59;i<=71;i++) {
datawajah[8][i]=0; }
for (byte i=72;i<=79;i++) {
datawajah[8][i]=1; }
for (byte i=80;i<=82;i++) {
datawajah[8][i]=0; }
for (byte i=83;i<=83;i++) {
datawajah[8][i]=1; }
for (byte i=84;i<=97;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=3;i++) {
datawajah[9][i]=0; }
for (byte i=4;i<=6;i++) {
datawajah[9][i]=1; }
for (byte i=7;i<=34;i++) {
datawajah[9][i]=0; }
for (byte i=35;i<=58;i++) {
datawajah[9][i]=1; }
for (byte i=59;i<=74;i++) {
datawajah[9][i]=0; }
for (byte i=75;i<=79;i++) {
datawajah[9][i]=1; }
for (byte i=80;i<=97;i++) {
datawajah[9][i]=0; }


//Baris11
for (byte i=0;i<=3;i++) {
datawajah[10][i]=0; }
for (byte i=4;i<=6;i++) {
datawajah[10][i]=1; }
for (byte i=7;i<=35;i++) {
datawajah[10][i]=0; }
for (byte i=36;i<=59;i++) {
datawajah[10][i]=1; }
for (byte i=60;i<=76;i++) {
datawajah[10][i]=0; }
for (byte i=77;i<=79;i++) {
datawajah[10][i]=1; }
for (byte i=80;i<=97;i++) {
datawajah[10][i]=0; }


//Baris12
for (byte i=0;i<=1;i++) {
datawajah[11][i]=0; }
for (byte i=2;i<=6;i++) {
datawajah[11][i]=1; }
for (byte i=7;i<=34;i++) {
datawajah[11][i]=0; }
for (byte i=35;i<=59;i++) {
datawajah[11][i]=1; }
for (byte i=60;i<=97;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=1;i++) {
datawajah[12][i]=0; }
for (byte i=2;i<=7;i++) {
datawajah[12][i]=1; }
for (byte i=8;i<=34;i++) {
datawajah[12][i]=0; }
for (byte i=35;i<=60;i++) {
datawajah[12][i]=1; }
for (byte i=61;i<=97;i++) {
datawajah[12][i]=0; }


//Baris14
for (byte i=0;i<=2;i++) {
datawajah[13][i]=0; }
for (byte i=3;i<=8;i++) {
datawajah[13][i]=1; }
for (byte i=9;i<=23;i++) {
datawajah[13][i]=0; }
for (byte i=24;i<=31;i++) {
datawajah[13][i]=1; }
for (byte i=32;i<=32;i++) {
datawajah[13][i]=0; }
for (byte i=33;i<=61;i++) {
datawajah[13][i]=1; }
for (byte i=62;i<=97;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=3;i++) {
datawajah[14][i]=0; }
for (byte i=4;i<=8;i++) {
datawajah[14][i]=1; }
for (byte i=9;i<=21;i++) {
datawajah[14][i]=0; }
for (byte i=22;i<=62;i++) {
datawajah[14][i]=1; }
for (byte i=63;i<=97;i++) {
datawajah[14][i]=0; }


//Baris16
for (byte i=0;i<=6;i++) {
datawajah[15][i]=0; }
for (byte i=7;i<=8;i++) {
datawajah[15][i]=1; }
for (byte i=9;i<=19;i++) {
datawajah[15][i]=0; }
for (byte i=20;i<=63;i++) {
datawajah[15][i]=1; }
for (byte i=64;i<=73;i++) {
datawajah[15][i]=0; }
for (byte i=74;i<=79;i++) {
datawajah[15][i]=1; }
for (byte i=80;i<=97;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=0;i<=1;i++) {
datawajah[16][i]=1; }
for (byte i=2;i<=5;i++) {
datawajah[16][i]=0; }
for (byte i=6;i<=7;i++) {
datawajah[16][i]=1; }
for (byte i=8;i<=16;i++) {
datawajah[16][i]=0; }
for (byte i=17;i<=64;i++) {
datawajah[16][i]=1; }
for (byte i=65;i<=73;i++) {
datawajah[16][i]=0; }
for (byte i=74;i<=82;i++) {
datawajah[16][i]=1; }
for (byte i=83;i<=97;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=9;i++) {
datawajah[17][i]=1; }
for (byte i=10;i<=11;i++) {
datawajah[17][i]=0; }
for (byte i=12;i<=65;i++) {
datawajah[17][i]=1; }
for (byte i=66;i<=73;i++) {
datawajah[17][i]=0; }
for (byte i=74;i<=88;i++) {
datawajah[17][i]=1; }
for (byte i=89;i<=90;i++) {
datawajah[17][i]=0; }
for (byte i=91;i<=97;i++) {
datawajah[17][i]=1; }


//Baris19
for (byte i=0;i<=0;i++) {
datawajah[18][i]=0; }
for (byte i=1;i<=9;i++) {
datawajah[18][i]=1; }
for (byte i=10;i<=11;i++) {
datawajah[18][i]=0; }
for (byte i=12;i<=66;i++) {
datawajah[18][i]=1; }
for (byte i=67;i<=74;i++) {
datawajah[18][i]=0; }
for (byte i=75;i<=97;i++) {
datawajah[18][i]=1; }

//Baris20
for (byte i=0;i<=69;i++) {
datawajah[19][i]=1; }
for (byte i=70;i<=75;i++) {
datawajah[19][i]=0; }
for (byte i=76;i<=97;i++) {
datawajah[19][i]=1; }


//Baris21
for (byte i=0;i<=69;i++) {
datawajah[20][i]=1; }
for (byte i=70;i<=75;i++) {
datawajah[20][i]=0; }
for (byte i=76;i<=97;i++) {
datawajah[20][i]=1; }

//Baris22
for (byte i=0;i<=70;i++) {
datawajah[21][i]=1; }
for (byte i=71;i<=76;i++) {
datawajah[21][i]=0; }
for (byte i=77;i<=97;i++) {
datawajah[21][i]=1; }


}

dataset:: wajahkanan9 ()
{
  baris = 24;
  kolom = 106;
//Baris1
for (byte i=0;i<=12;i++) {
datawajah[0][i]=0; }
for (byte i=13;i<=15;i++) {
datawajah[0][i]=1; }
for (byte i=16;i<=39;i++) {
datawajah[0][i]=0; }
for (byte i=40;i<=40;i++) {
datawajah[0][i]=1; }
for (byte i=41;i<=42;i++) {
datawajah[0][i]=0; }
for (byte i=43;i<=60;i++) {
datawajah[0][i]=1; }
for (byte i=61;i<=82;i++) {
datawajah[0][i]=0; }
for (byte i=83;i<=101;i++) {
datawajah[0][i]=1; }
for (byte i=102;i<=105;i++) {
datawajah[0][i]=0; }

//Baris2
for (byte i=0;i<=10;i++) {
datawajah[1][i]=0; }
for (byte i=11;i<=18;i++) {
datawajah[1][i]=1; }
for (byte i=19;i<=39;i++) {
datawajah[1][i]=0; }
for (byte i=40;i<=40;i++) {
datawajah[1][i]=1; }
for (byte i=41;i<=43;i++) {
datawajah[1][i]=0; }
for (byte i=44;i<=61;i++) {
datawajah[1][i]=1; }
for (byte i=62;i<=62;i++) {
datawajah[1][i]=0; }
for (byte i=63;i<=63;i++) {
datawajah[1][i]=1; }
for (byte i=64;i<=81;i++) {
datawajah[1][i]=0; }
for (byte i=82;i<=100;i++) {
datawajah[1][i]=1; }
for (byte i=101;i<=105;i++) {
datawajah[1][i]=0; }

//Baris3
for (byte i=0;i<=8;i++) {
datawajah[2][i]=0; }
for (byte i=9;i<=18;i++) {
datawajah[2][i]=1; }
for (byte i=19;i<=44;i++) {
datawajah[2][i]=0; }
for (byte i=45;i<=61;i++) {
datawajah[2][i]=1; }
for (byte i=62;i<=80;i++) {
datawajah[2][i]=0; }
for (byte i=81;i<=100;i++) {
datawajah[2][i]=1; }
for (byte i=101;i<=105;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=10;i++) {
datawajah[3][i]=0; }
for (byte i=11;i<=15;i++) {
datawajah[3][i]=1; }
for (byte i=16;i<=44;i++) {
datawajah[3][i]=0; }
for (byte i=45;i<=62;i++) {
datawajah[3][i]=1; }
for (byte i=63;i<=80;i++) {
datawajah[3][i]=0; }
for (byte i=81;i<=100;i++) {
datawajah[3][i]=1; }
for (byte i=101;i<=105;i++) {
datawajah[3][i]=0; }


//Baris5
for (byte i=0;i<=44;i++) {
datawajah[4][i]=0; }
for (byte i=45;i<=62;i++) {
datawajah[4][i]=1; }
for (byte i=63;i<=78;i++) {
datawajah[4][i]=0; }
for (byte i=79;i<=79;i++) {
datawajah[4][i]=1; }
for (byte i=80;i<=93;i++) {
datawajah[4][i]=0; }
for (byte i=94;i<=100;i++) {
datawajah[4][i]=1; }
for (byte i=101;i<=105;i++) {
datawajah[4][i]=0; }


//Baris6
for (byte i=0;i<=44;i++) {
datawajah[5][i]=0; }
for (byte i=45;i<=62;i++) {
datawajah[5][i]=1; }
for (byte i=63;i<=105;i++) {
datawajah[5][i]=0; }

//Baris7
for (byte i=0;i<=44;i++) {
datawajah[6][i]=0; }
for (byte i=45;i<=62;i++) {
datawajah[6][i]=1; }
for (byte i=63;i<=105;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=44;i++) {
datawajah[7][i]=0; }
for (byte i=45;i<=63;i++) {
datawajah[7][i]=1; }
for (byte i=64;i<=105;i++) {
datawajah[7][i]=0; }


//Baris9
for (byte i=0;i<=19;i++) {
datawajah[8][i]=0; }
for (byte i=20;i<=23;i++) {
datawajah[8][i]=1; }
for (byte i=24;i<=43;i++) {
datawajah[8][i]=0; }
for (byte i=44;i<=63;i++) {
datawajah[8][i]=1; }
for (byte i=64;i<=105;i++) {
datawajah[8][i]=0; }


//Baris10
for (byte i=0;i<=19;i++) {
datawajah[9][i]=0; }
for (byte i=20;i<=23;i++) {
datawajah[9][i]=1; }
for (byte i=24;i<=42;i++) {
datawajah[9][i]=0; }
for (byte i=43;i<=63;i++) {
datawajah[9][i]=1; }
for (byte i=64;i<=105;i++) {
datawajah[9][i]=0; }


//Baris11
for (byte i=0;i<=18;i++) {
datawajah[10][i]=0; }
for (byte i=19;i<=23;i++) {
datawajah[10][i]=1; }
for (byte i=24;i<=42;i++) {
datawajah[10][i]=0; }
for (byte i=43;i<=63;i++) {
datawajah[10][i]=1; }
for (byte i=64;i<=105;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=19;i++) {
datawajah[11][i]=0; }
for (byte i=20;i<=21;i++) {
datawajah[11][i]=1; }
for (byte i=22;i<=41;i++) {
datawajah[11][i]=0; }
for (byte i=42;i<=64;i++) {
datawajah[11][i]=1; }
for (byte i=65;i<=84;i++) {
datawajah[11][i]=0; }
for (byte i=85;i<=86;i++) {
datawajah[11][i]=1; }
for (byte i=87;i<=105;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=40;i++) {
datawajah[12][i]=0; }
for (byte i=41;i<=64;i++) {
datawajah[12][i]=1; }
for (byte i=65;i<=105;i++) {
datawajah[12][i]=0; }


//Baris14
for (byte i=0;i<=38;i++) {
datawajah[13][i]=0; }
for (byte i=39;i<=64;i++) {
datawajah[13][i]=1; }
for (byte i=65;i<=105;i++) {
datawajah[13][i]=0; }


//Baris15
for (byte i=0;i<=30;i++) {
datawajah[14][i]=0; }
for (byte i=31;i<=34;i++) {
datawajah[14][i]=1; }
for (byte i=35;i<=37;i++) {
datawajah[14][i]=0; }
for (byte i=38;i<=64;i++) {
datawajah[14][i]=1; }
for (byte i=65;i<=105;i++) {
datawajah[14][i]=0; }


//Baris16
for (byte i=0;i<=24;i++) {
datawajah[15][i]=0; }
for (byte i=25;i<=28;i++) {
datawajah[15][i]=1; }
for (byte i=29;i<=29;i++) {
datawajah[15][i]=0; }
for (byte i=30;i<=65;i++) {
datawajah[15][i]=1; }
for (byte i=66;i<=105;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=0;i<=20;i++) {
datawajah[16][i]=0; }
for (byte i=21;i<=65;i++) {
datawajah[16][i]=1; }
for (byte i=66;i<=105;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=3;i++) {
datawajah[17][i]=1; }
for (byte i=4;i<=17;i++) {
datawajah[17][i]=0; }
for (byte i=18;i<=66;i++) {
datawajah[17][i]=1; }
for (byte i=67;i<=105;i++) {
datawajah[17][i]=0; }


//Baris19
for (byte i=0;i<=6;i++) {
datawajah[18][i]=1; }
for (byte i=7;i<=15;i++) {
datawajah[18][i]=0; }
for (byte i=16;i<=66;i++) {
datawajah[18][i]=1; }
for (byte i=67;i<=105;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=67;i++) {
datawajah[19][i]=1; }
for (byte i=68;i<=76;i++) {
datawajah[19][i]=0; }
for (byte i=77;i<=81;i++) {
datawajah[19][i]=1; }
for (byte i=82;i<=105;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=67;i++) {
datawajah[20][i]=1; }
for (byte i=68;i<=74;i++) {
datawajah[20][i]=0; }
for (byte i=75;i<=75;i++) {
datawajah[20][i]=1; }
for (byte i=76;i<=76;i++) {
datawajah[20][i]=0; }
for (byte i=77;i<=83;i++) {
datawajah[20][i]=1; }
for (byte i=84;i<=105;i++) {
datawajah[20][i]=0; }


//Baris22
for (byte i=0;i<=70;i++) {
datawajah[21][i]=1; }
for (byte i=71;i<=74;i++) {
datawajah[21][i]=0; }
for (byte i=75;i<=86;i++) {
datawajah[21][i]=1; }
for (byte i=87;i<=105;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=71;i++) {
datawajah[22][i]=1; }
for (byte i=72;i<=72;i++) {
datawajah[22][i]=0; }
for (byte i=73;i<=90;i++) {
datawajah[22][i]=1; }
for (byte i=91;i<=105;i++) {
datawajah[22][i]=0; }

//Baris24
for (byte i=0;i<=92;i++) {
datawajah[23][i]=1; }
for (byte i=93;i<=105;i++) {
datawajah[23][i]=0; }


}

dataset:: wajahkanan10 ()
{
  baris = 27;
  kolom = 120;
//Baris1
for (byte i=0;i<=28;i++) {
datawajah[0][i]=0; }
for (byte i=29;i<=34;i++) {
datawajah[0][i]=1; }
for (byte i=35;i<=40;i++) {
datawajah[0][i]=0; }
for (byte i=41;i<=74;i++) {
datawajah[0][i]=1; }
for (byte i=75;i<=75;i++) {
datawajah[0][i]=0; }
for (byte i=76;i<=79;i++) {
datawajah[0][i]=1; }
for (byte i=80;i<=85;i++) {
datawajah[0][i]=0; }
for (byte i=86;i<=87;i++) {
datawajah[0][i]=1; }
for (byte i=88;i<=88;i++) {
datawajah[0][i]=0; }
for (byte i=89;i<=105;i++) {
datawajah[0][i]=1; }
for (byte i=106;i<=118;i++) {
datawajah[0][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[0][i]=1; }


//Baris2
for (byte i=0;i<=19;i++) {
datawajah[1][i]=0; }
for (byte i=20;i<=23;i++) {
datawajah[1][i]=1; }
for (byte i=24;i<=43;i++) {
datawajah[1][i]=0; }
for (byte i=44;i<=80;i++) {
datawajah[1][i]=1; }
for (byte i=81;i<=81;i++) {
datawajah[1][i]=0; }
for (byte i=82;i<=83;i++) {
datawajah[1][i]=1; }
for (byte i=84;i<=85;i++) {
datawajah[1][i]=0; }
for (byte i=86;i<=107;i++) {
datawajah[1][i]=1; }
for (byte i=108;i<=118;i++) {
datawajah[1][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[1][i]=1; }


//Baris3
for (byte i=0;i<=17;i++) {
datawajah[2][i]=0; }
for (byte i=18;i<=25;i++) {
datawajah[2][i]=1; }
for (byte i=26;i<=43;i++) {
datawajah[2][i]=0; }
for (byte i=44;i<=47;i++) {
datawajah[2][i]=1; }
for (byte i=48;i<=48;i++) {
datawajah[2][i]=0; }
for (byte i=49;i<=77;i++) {
datawajah[2][i]=1; }
for (byte i=78;i<=78;i++) {
datawajah[2][i]=0; }
for (byte i=79;i<=109;i++) {
datawajah[2][i]=1; }
for (byte i=110;i<=118;i++) {
datawajah[2][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[2][i]=1; }


 //Baris4
for (byte i=0;i<=15;i++) {
datawajah[3][i]=0; }
for (byte i=16;i<=25;i++) {
datawajah[3][i]=1; }
for (byte i=26;i<=45;i++) {
datawajah[3][i]=0; }
for (byte i=46;i<=46;i++) {
datawajah[3][i]=1; }
for (byte i=47;i<=51;i++) {
datawajah[3][i]=0; }
for (byte i=52;i<=76;i++) {
datawajah[3][i]=1; }
for (byte i=77;i<=82;i++) {
datawajah[3][i]=0; }
for (byte i=83;i<=86;i++) {
datawajah[3][i]=1; }
for (byte i=87;i<=90;i++) {
datawajah[3][i]=0; }
for (byte i=91;i<=110;i++) {
datawajah[3][i]=1; }
for (byte i=111;i<=118;i++) {
datawajah[3][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[3][i]=1; }

//Baris5
for (byte i=0;i<=17;i++) {
datawajah[4][i]=0; }
for (byte i=18;i<=24;i++) {
datawajah[4][i]=1; }
for (byte i=25;i<=51;i++) {
datawajah[4][i]=0; }
for (byte i=52;i<=76;i++) {
datawajah[4][i]=1; }
for (byte i=77;i<=89;i++) {
datawajah[4][i]=0; }
for (byte i=90;i<=111;i++) {
datawajah[4][i]=1; }
for (byte i=112;i<=118;i++) {
datawajah[4][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[4][i]=1; }

//Baris6
for (byte i=0;i<=51;i++) {
datawajah[5][i]=0; }
for (byte i=52;i<=75;i++) {
datawajah[5][i]=1; }
for (byte i=76;i<=88;i++) {
datawajah[5][i]=0; }
for (byte i=89;i<=110;i++) {
datawajah[5][i]=1; }
for (byte i=111;i<=118;i++) {
datawajah[5][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[5][i]=1; }

//Baris7
for (byte i=0;i<=50;i++) {
datawajah[6][i]=0; }
for (byte i=51;i<=70;i++) {
datawajah[6][i]=1; }
for (byte i=71;i<=88;i++) {
datawajah[6][i]=0; }
for (byte i=89;i<=110;i++) {
datawajah[6][i]=1; }
for (byte i=111;i<=118;i++) {
datawajah[6][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[6][i]=1; }

//Baris8
for (byte i=0;i<=50;i++) {
datawajah[7][i]=0; }
for (byte i=51;i<=70;i++) {
datawajah[7][i]=1; }
for (byte i=71;i<=88;i++) {
datawajah[7][i]=0; }
for (byte i=89;i<=92;i++) {
datawajah[7][i]=1; }
for (byte i=93;i<=93;i++) {
datawajah[7][i]=0; }
for (byte i=94;i<=109;i++) {
datawajah[7][i]=1; }
for (byte i=110;i<=117;i++) {
datawajah[7][i]=0; }
for (byte i=118;i<=119;i++) {
datawajah[7][i]=1; }

//Baris9
for (byte i=0;i<=40;i++) {
datawajah[8][i]=0; }
for (byte i=41;i<=41;i++) {
datawajah[8][i]=1; }
for (byte i=42;i<=51;i++) {
datawajah[8][i]=0; }
for (byte i=52;i<=70;i++) {
datawajah[8][i]=1; }
for (byte i=71;i<=85;i++) {
datawajah[8][i]=0; }
for (byte i=86;i<=86;i++) {
datawajah[8][i]=1; }
for (byte i=87;i<=101;i++) {
datawajah[8][i]=0; }
for (byte i=102;i<=109;i++) {
datawajah[8][i]=1; }
for (byte i=110;i<=118;i++) {
datawajah[8][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[8][i]=1; }

//Baris10
for (byte i=0;i<=27;i++) {
datawajah[9][i]=0; }
for (byte i=28;i<=31;i++) {
datawajah[9][i]=1; }
for (byte i=32;i<=51;i++) {
datawajah[9][i]=0; }
for (byte i=52;i<=70;i++) {
datawajah[9][i]=1; }
for (byte i=71;i<=108;i++) {
datawajah[9][i]=0; }
for (byte i=109;i<=109;i++) {
datawajah[9][i]=1; }
for (byte i=110;i<=118;i++) {
datawajah[9][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[9][i]=1; }

//Baris11
for (byte i=0;i<=26;i++) {
datawajah[10][i]=0; }
for (byte i=27;i<=31;i++) {
datawajah[10][i]=1; }
for (byte i=32;i<=49;i++) {
datawajah[10][i]=0; }
for (byte i=50;i<=70;i++) {
datawajah[10][i]=1; }
for (byte i=71;i<=118;i++) {
datawajah[10][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[10][i]=1; }

//Baris12
for (byte i=0;i<=26;i++) {
datawajah[11][i]=0; }
for (byte i=27;i<=29;i++) {
datawajah[11][i]=1; }
for (byte i=30;i<=49;i++) {
datawajah[11][i]=0; }
for (byte i=50;i<=70;i++) {
datawajah[11][i]=1; }
for (byte i=71;i<=118;i++) {
datawajah[11][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[11][i]=1; }

//Baris13
for (byte i=0;i<=48;i++) {
datawajah[12][i]=0; }
for (byte i=49;i<=71;i++) {
datawajah[12][i]=1; }
for (byte i=72;i<=118;i++) {
datawajah[12][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[12][i]=1; }

//Baris14
for (byte i=0;i<=47;i++) {
datawajah[13][i]=0; }
for (byte i=48;i<=71;i++) {
datawajah[13][i]=1; }
for (byte i=72;i<=118;i++) {
datawajah[13][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[13][i]=1; }

//Baris15
for (byte i=0;i<=37;i++) {
datawajah[14][i]=0; }
for (byte i=38;i<=39;i++) {
datawajah[14][i]=1; }
for (byte i=40;i<=45;i++) {
datawajah[14][i]=0; }
for (byte i=46;i<=71;i++) {
datawajah[14][i]=1; }
for (byte i=72;i<=94;i++) {
datawajah[14][i]=0; }
for (byte i=95;i<=95;i++) {
datawajah[14][i]=1; }
for (byte i=96;i<=118;i++) {
datawajah[14][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[14][i]=1; }

//Baris16
for (byte i=0;i<=0;i++) {
datawajah[15][i]=1; }
for (byte i=1;i<=36;i++) {
datawajah[15][i]=0; }
for (byte i=37;i<=40;i++) {
datawajah[15][i]=1; }
for (byte i=41;i<=44;i++) {
datawajah[15][i]=0; }
for (byte i=45;i<=71;i++) {
datawajah[15][i]=1; }
for (byte i=72;i<=118;i++) {
datawajah[15][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[15][i]=1; }

//Baris17
for (byte i=0;i<=7;i++) {
datawajah[16][i]=1; }
for (byte i=8;i<=32;i++) {
datawajah[16][i]=0; }
for (byte i=33;i<=71;i++) {
datawajah[16][i]=1; }
for (byte i=72;i<=118;i++) {
datawajah[16][i]=0; }
for (byte i=119;i<=119;i++) {
datawajah[16][i]=1; }

//Baris18
for (byte i=0;i<=11;i++) {
datawajah[17][i]=1; }
for (byte i=12;i<=25;i++) {
datawajah[17][i]=0; }
for (byte i=26;i<=72;i++) {
datawajah[17][i]=1; }
for (byte i=73;i<=119;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=12;i++) {
datawajah[18][i]=1; }
for (byte i=13;i<=22;i++) {
datawajah[18][i]=0; }
for (byte i=23;i<=72;i++) {
datawajah[18][i]=1; }
for (byte i=73;i<=119;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=17;i++) {
datawajah[19][i]=1; }
for (byte i=18;i<=18;i++) {
datawajah[19][i]=0; }
for (byte i=19;i<=73;i++) {
datawajah[19][i]=1; }
for (byte i=74;i<=119;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=74;i++) {
datawajah[20][i]=1; }
for (byte i=75;i<=78;i++) {
datawajah[20][i]=0; }
for (byte i=79;i<=80;i++) {
datawajah[20][i]=1; }
for (byte i=81;i<=119;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=74;i++) {
datawajah[21][i]=1; }
for (byte i=75;i<=78;i++) {
datawajah[21][i]=0; }
for (byte i=79;i<=80;i++) {
datawajah[21][i]=1; }
for (byte i=81;i<=119;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=76;i++) {
datawajah[22][i]=1; }
for (byte i=77;i<=79;i++) {
datawajah[22][i]=0; }
for (byte i=80;i<=81;i++) {
datawajah[22][i]=1; }
for (byte i=82;i<=84;i++) {
datawajah[22][i]=0; }
for (byte i=85;i<=89;i++) {
datawajah[22][i]=1; }
for (byte i=90;i<=119;i++) {
datawajah[22][i]=0; }

//Baris24
for (byte i=0;i<=76;i++) {
datawajah[23][i]=1; }
for (byte i=77;i<=79;i++) {
datawajah[23][i]=0; }
for (byte i=80;i<=91;i++) {
datawajah[23][i]=1; }
for (byte i=92;i<=119;i++) {
datawajah[23][i]=0; }

//Baris25
for (byte i=0;i<=94;i++) {
datawajah[24][i]=1; }
for (byte i=95;i<=119;i++) {
datawajah[24][i]=0; }

//Baris26
for (byte i=0;i<=96;i++) {
datawajah[25][i]=1; }
for (byte i=97;i<=119;i++) {
datawajah[25][i]=0; }

//Baris27
for (byte i=0;i<=98;i++) {
datawajah[26][i]=1; }
for (byte i=99;i<=119;i++) {
datawajah[26][i]=0; }

}



//wajah depan
dataset::wajahdepan1()
{
baris = 25;
  kolom = 108;
  //baris 1
  for (byte i = 0 ; i < 3; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 3 ; i < 29; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 29 ; i < 45; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 45 ; i < 60; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 60 ; i < 79; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 79 ; i < 108; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 3; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 3; i < 30; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 30; i < 44; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 44; i < 61; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 61; i < 79; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 79; i < 108; i++) {
    datawajah[1][i] = 1;
  }

  //baris 3
  for (byte i = 0; i < 3; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 3; i < 30; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 30; i < 44; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 44; i < 62; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 62; i < 80; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 80; i < 108; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 6; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 6; i < 31; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 31; i < 44; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 44; i < 63; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 63; i < 91; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 91; i < 108; i++) {
    datawajah[3][i] = 1;
  }

  //baris 5
  for (byte i = 0; i < 7; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 7; i < 9; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 9; i < 26; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 26; i < 34; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 34; i < 44; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 44; i < 64; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 64; i < 100; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 100; i < 108; i++) {
    datawajah[4][i] = 1;
  }


  //baris 6
  for (byte i = 0; i < 28; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 28; i < 34; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 34; i < 44; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 44; i < 64; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 64; i < 103; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 103; i < 108; i++) {
    datawajah[5][i] = 1;
  }

  //baris 7
  for (byte i = 0; i < 44; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 44; i < 64; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 64; i < 104; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 104; i < 108; i++) {
    datawajah[6][i] = 1;
  }

  //baris 8
  for (byte i = 0; i < 44; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 44; i < 65; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 65; i < 106; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 106; i < 108; i++) {
    datawajah[7][i] = 1;
  }

  //baris 9
  for (byte i = 0; i < 44; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 44; i < 65; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 65; i < 108; i++) {
    datawajah[8][i] = 0;
  }

  //baris 10
  for (byte i = 0; i < 44; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 44; i < 65; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 65; i < 108; i++) {
    datawajah[9][i] = 0;
  }

  //baris 11
  for (byte i = 0; i < 34; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 34; i < 39; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 39; i < 45; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 45; i < 66; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 66; i < 108; i++) {
    datawajah[10][i] = 0;
  }

  //baris 12
  for (byte i = 0; i < 35; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 35; i < 40; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 40; i < 45; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 45; i < 68; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 68; i < 108; i++) {
    datawajah[11][i] = 0;
  }

  //baris 13
  for (byte i = 0; i < 35; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 35; i < 40; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 40; i < 42; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 42; i < 70; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 70; i < 108; i++) {
    datawajah[12][i] = 0;
  }

  //baris 14
  for (byte i = 0; i < 35; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 35; i < 77; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 77; i < 108; i++) {
    datawajah[13][i] = 0;
  }

  //baris 15
  for (byte i = 0; i < 25; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 25; i < 83; i++) {
    datawajah[14][i] = 1;
  } for (byte i = 83; i < 97; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 97; i < 101; i++) {
    datawajah[14][i] = 1;
  } for (byte i = 101; i < 108; i++) {
    datawajah[14][i] = 0;
  }

  //baris 16
  for (byte i = 0; i < 24; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 24; i < 86; i++) {
    datawajah[15][i] = 1;
  } for (byte i = 86; i < 93; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 93; i < 104; i++) {
    datawajah[15][i] = 1;
  } for (byte i = 104; i < 108; i++) {
    datawajah[15][i] = 0;
  }

  //baris 17
  for (byte i = 0; i < 22; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 22; i < 108; i++) {
    datawajah[16][i] = 1;
  }

  //baris 18
  for (byte i = 0; i < 20; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 20; i < 108; i++) {
    datawajah[17][i] = 1;
  }

  //baris 19
  for (byte i = 0; i < 14; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 14; i < 108; i++) {
    datawajah[18][i] = 1;
  }

  //baris 20
  for (byte i = 0; i < 17; i++) {
    datawajah[19][i] = 0;
  } for (byte i = 17; i < 108; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 7; i++) {
    datawajah[20][i] = 0;
  } for (byte i = 7; i < 13; i++) {
    datawajah[20][i] = 1;
  } for (byte i = 13; i < 16; i++) {
    datawajah[20][i] = 0;
  } for (byte i = 16; i < 108; i++) {
    datawajah[20][i] = 1;
  }
  //baris 22
  for (byte i = 0; i < 6; i++) {
    datawajah[21][i] = 0;
  } for (byte i = 6; i < 108; i++) {
    datawajah[21][i] = 1;
  }

  //baris 23
  for (byte i = 0; i < 4; i++) {
    datawajah[22][i] = 0;
  } for (byte i = 4; i < 108; i++) {
    datawajah[22][i] = 1;
  }

  //baris 24
  for (byte i = 0; i < 4; i++) {
    datawajah[23][i] = 0;
  } for (byte i = 4; i < 108; i++) {
    datawajah[23][i] = 1;
  }

  //baris 25
  for (byte i = 0; i < 108; i++) {
    datawajah[24][i] = 1;
  }
}

dataset:: wajahdepan2()
{
  baris = 22;
  kolom = 97;
  //baris 1
  for (byte i = 0 ; i < 25; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 25 ; i < 38; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 38 ; i < 56; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 56 ; i < 72; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 72 ; i < 97; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 26; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 26; i < 38; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 38; i < 57; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 57; i < 72; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 72; i < 75; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 75; i < 78; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 78; i < 97; i++) {
    datawajah[1][i] = 1;
  }

  //baris 3
  for (byte i = 0; i < 2; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 2; i < 26; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 26; i < 38; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 38; i < 58; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 58; i < 92; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 92; i < 97; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 3; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 3; i < 6; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 6; i < 23; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 23; i < 26; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 26; i < 38; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 38; i < 58; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 58; i < 96; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 96; i < 97; i++) {
    datawajah[3][i] = 1;
  }

  //baris 5
  for (byte i = 0; i < 38; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 38; i < 58; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 58; i < 97; i++) {
    datawajah[4][i] = 0;
  }

  //baris 6
  for (byte i = 0; i < 38; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 38; i < 59; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 59; i < 97; i++) {
    datawajah[5][i] = 0;
  }

  //baris 7
  for (byte i = 0; i < 38; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 38; i < 59; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 59; i < 97; i++) {
    datawajah[6][i] = 0;
  }

  //baris 8
  for (byte i = 0; i < 38; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 38; i < 59; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 59; i < 97; i++) {
    datawajah[7][i] = 0;
  }

  //baris 9
  for (byte i = 0; i < 30; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 30; i < 32; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 32; i < 38; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 38; i < 60; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 60; i < 97; i++) {
    datawajah[8][i] = 0;
  }

  //baris 10
  for (byte i = 0; i < 29; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 29; i < 33; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 33; i < 39; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 39; i < 62; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 62; i < 97; i++) {
    datawajah[9][i] = 0;
  }

  //baris 11
  for (byte i = 0; i < 30; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 30; i < 34; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 34; i < 35; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 35; i < 64; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 64; i < 97; i++) {
    datawajah[10][i] = 0;
  }

  //baris 12
  for (byte i = 0; i < 30; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 30; i < 71; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 71; i < 97; i++) {
    datawajah[11][i] = 0;
  }

  //baris 13
  for (byte i = 0; i < 25; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 25; i < 77; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 77; i < 91; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 91; i < 93; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 93; i < 94; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 94; i < 96; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 96; i < 97; i++) {
    datawajah[12][i] = 0;
  }

  //baris 14
  for (byte i = 0; i < 21; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 21; i < 82; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 82; i < 88; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 88; i < 97; i++) {
    datawajah[13][i] = 1;
  }

  //baris 15
  for (byte i = 0; i < 19; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 19; i < 97; i++) {
    datawajah[14][i] = 1;
  }

  //baris 16
  for (byte i = 0; i < 17; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 17; i < 97; i++) {
    datawajah[15][i] = 1;
  }

  //baris 17
  for (byte i = 0; i < 13; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 13; i < 97; i++) {
    datawajah[16][i] = 1;
  }

  //baris 18
  for (byte i = 0; i < 13; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 13; i < 97; i++) {
    datawajah[17][i] = 1;
  }

  //baris 19
  for (byte i = 0; i < 7; i++) {
    datawajah[18][i] = 1;
  } for (byte i = 7; i < 13; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 13; i < 97; i++) {
    datawajah[18][i] = 1;
  }

  //baris 20
  for (byte i = 0; i < 97; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 97; i++) {
    datawajah[20][i] = 1;
  }

  //baris 22
  for (byte i = 0; i < 97; i++) {
    datawajah[21][i] = 1;
  }

}

dataset:: wajahdepan3()
{
  baris = 23;
  kolom = 100;
  //baris 1
  for (byte i = 0 ; i < 2; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 2 ; i < 26; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 26 ; i < 39; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 39 ; i < 56; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 56 ; i < 71; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 71 ; i < 100; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 2; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 2; i < 27; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 27; i < 39; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 39; i < 56; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 56; i < 71; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 71; i < 100; i++) {
    datawajah[1][i] = 1;
  }
  //baris 3
  for (byte i = 0; i < 4; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 4; i < 28; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 28; i < 39; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 39; i < 57; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 57; i < 84; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 84; i < 100; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 5; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 5; i < 9; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 9; i < 22; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 22; i < 30; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 30; i < 39; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 39; i < 58; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 58; i < 91; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 91; i < 100; i++) {
    datawajah[3][i] = 1;
  }

  //baris 5
  for (byte i = 0; i < 28; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 28; i < 30; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 30; i < 39; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 39; i < 58; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 58; i < 93; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 93; i < 100; i++) {
    datawajah[4][i] = 1;
  }

  //baris 6
  for (byte i = 0; i < 13; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 13; i < 15; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 15; i < 39; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 39; i < 58; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 58; i < 96; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 96; i < 100; i++) {
    datawajah[5][i] = 1;
  }

  //baris 7
  for (byte i = 0; i < 39; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 39; i < 58; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 58; i < 97; i++) {
    datawajah[6][i] = 0;
  }  for (byte i = 97; i < 100; i++) {
    datawajah[6][i] = 1;
  }

  //baris 8
  for (byte i = 0; i < 39; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 39; i < 59; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 59; i < 98; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 98; i < 100; i++) {
    datawajah[7][i] = 1;
  }

  //baris 9
  for (byte i = 0; i < 30; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 30; i < 33; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 33; i < 40; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 40; i < 60; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 60; i < 100; i++) {
    datawajah[8][i] = 0;
  }

  //baris 10
  for (byte i = 0; i < 31; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 31; i < 33; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 33; i < 40; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 40; i < 62; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 62; i < 98; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 98; i < 100; i++) {
    datawajah[9][i] = 1;
  }

  //baris 11
  for (byte i = 0; i < 31; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 31; i < 64; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 64; i < 87; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 87; i < 100; i++) {
    datawajah[10][i] = 1;
  }

  //baris 12
  for (byte i = 0; i < 31; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 31; i < 35; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 35; i < 40; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 40; i < 70; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 70; i < 87; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 87; i < 100; i++) {
    datawajah[11][i] = 1;
  }

  //baris 13
  for (byte i = 0; i < 21; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 21; i < 70; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 70; i < 86; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 86; i < 88; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 88; i < 100; i++) {
    datawajah[12][i] = 0;
  }


  //baris 14
  for (byte i = 0; i < 20; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 20; i < 76; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 76; i < 86; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 86; i < 93; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 93; i < 100; i++) {
    datawajah[13][i] = 0;
  }

  //baris 15
  for (byte i = 0; i < 19; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 19; i < 100; i++) {
    datawajah[14][i] = 1;
  }

  //baris 16
  for (byte i = 0; i < 16; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 16; i < 100; i++) {
    datawajah[15][i] = 1;
  }

  //baris 17
  for (byte i = 0; i < 9; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 9; i < 15; i++) {
    datawajah[16][i] = 1;
  } for (byte i = 15; i < 100; i++) {
    datawajah[16][i] = 0;
  }

  //baris 18
  for (byte i = 0; i < 7; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 7; i < 10; i++) {
    datawajah[17][i] = 1;
  } for (byte i = 10; i < 14; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 14; i < 20; i++) {
    datawajah[17][i] = 1;
  } for (byte i = 20; i < 100; i++) {
    datawajah[17][i] = 0;
  }

  //baris 19
  for (byte i = 0; i < 1; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 1; i < 4; i++) {
    datawajah[18][i] = 1;
  } for (byte i = 4; i < 100; i++) {
    datawajah[18][i] = 0;
  }

  //baris 20
  for (byte i = 0; i < 1; i++) {
    datawajah[19][i] = 0;
  }  for (byte i = 1; i < 100; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 1; i++) {
    datawajah[20][i] = 0;
  } for (byte i = 1; i < 100; i++) {
    datawajah[20][i] = 1;
  }

  //baris 22
  for (byte i = 0; i < 100; i++) {
    datawajah[21][i] = 1;
  }

  //baris23
  for (byte i = 0; i < 100; i++) {
    datawajah[22][i] = 1;
  }

}

dataset:: wajahdepan4()
{
  baris = 22;
  kolom = 99;
  //baris 1
  for (byte i = 0 ; i < 3; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 3 ; i < 27; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 27 ; i < 38; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 38 ; i < 55; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 55 ; i < 70; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 70 ; i < 99; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 3; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 3; i < 6; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 6; i < 7; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 7; i < 28; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 28; i < 39; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 39; i < 56; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 56; i < 70; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 70; i < 71; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 71; i < 84; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 84; i < 99; i++) {
    datawajah[1][i] = 1;
  }


  //baris 3
  for (byte i = 0; i < 3; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 3; i < 6; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 6; i < 21; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 21; i < 27; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 27; i < 38; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 38; i < 57; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 57; i < 90; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 90; i < 99; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 38; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 38; i < 58; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 58; i < 93; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 93; i < 99; i++) {
    datawajah[3][i] = 1;
  }

  //baris 5
  for (byte i = 0; i < 15; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 15; i < 16; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 16; i < 39; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 39; i < 58; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 58; i < 95; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 95; i < 99; i++) {
    datawajah[4][i] = 1;
  }

  //baris 6
  for (byte i = 0; i < 39; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 39; i < 58; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 58; i < 96; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 96; i < 99; i++) {
    datawajah[5][i] = 1;
  }

  //baris 7
  for (byte i = 0; i < 39; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 39; i < 56; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 56; i < 97; i++) {
    datawajah[6][i] = 0;
  }  for (byte i = 97; i < 99; i++) {
    datawajah[6][i] = 1;
  }

  //baris 8
  for (byte i = 0; i < 30; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 30; i < 32; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 32; i < 40; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 40; i < 60; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 60; i < 99; i++) {
    datawajah[7][i] = 0;
  }

  //baris 9
  for (byte i = 0; i < 30; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 30; i < 34; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 34; i < 39; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 39; i < 61; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 61; i < 99; i++) {
    datawajah[8][i] = 0;
  }

  //baris 10
  for (byte i = 0; i < 31; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 31; i < 62; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 62; i < 86; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 86; i < 88; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 88; i < 99; i++) {
    datawajah[9][i] = 0;
  }

  //baris 11
  for (byte i = 0; i < 31; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 31; i < 69; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 69; i < 99; i++) {
    datawajah[10][i] = 0;
  }

  //baris 12
  for (byte i = 0; i < 21; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 31; i < 75; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 35; i < 85; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 40; i < 93; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 70; i < 99; i++) {
    datawajah[11][i] = 0;
  }

  //baris 13
  for (byte i = 0; i < 20; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 20; i < 79; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 79; i < 83; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 83; i < 94; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 94; i < 99; i++) {
    datawajah[12][i] = 0;
  }


  //baris 14
  for (byte i = 0; i < 17; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 20; i < 99 ; i++) {
    datawajah[13][i] = 1;
  }

  //baris 15
  for (byte i = 0; i < 15; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 19; i < 99; i++) {
    datawajah[14][i] = 1;
  }

  //baris 16
  for (byte i = 0; i < 13; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 13; i < 99; i++) {
    datawajah[15][i] = 1;
  }

  //baris 17
  for (byte i = 0; i < 6; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 6; i < 9; i++) {
    datawajah[16][i] = 1;
  } for (byte i = 9; i < 15; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 15; i < 99; i++) {
    datawajah[16][i] = 1;
  }

  //baris 18
  for (byte i = 0; i < 4; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 7; i < 99; i++) {
    datawajah[17][i] = 1;
  }

  //baris 19
  for (byte i = 0; i < 99; i++) {
    datawajah[18][i] = 1;
  }

  //baris 20
  for (byte i = 0; i < 99; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 99; i++) {
    datawajah[20][i] = 1;
  }

  //baris 22
  for (byte i = 0; i < 99; i++) {
    datawajah[21][i] = 1;
  }
}

dataset:: wajahdepan5()
{
  baris = 21;
  kolom = 92;
  //baris 1
  for (byte i = 0 ; i < 22; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 22 ; i < 37; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 37 ; i < 52; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 52 ; i < 68; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 68 ; i < 92; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 23; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 3; i < 36; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 6; i < 53; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 7; i < 67; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 28; i < 92; i++) {
    datawajah[1][i] = 1;
  }

  //baris 3
  for (byte i = 0; i < 24; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 24; i < 36; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 36; i < 53; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 53; i < 67; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 67; i < 69; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 69; i < 78; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 78; i < 92; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 1; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 1; i < 3; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 3; i < 17; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 17; i < 24; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 24; i < 36; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 36; i < 55; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 55; i < 87; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 87; i < 92; i++) {
    datawajah[3][i] = 1;
  }

  //baris 5
  for (byte i = 0; i < 21; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 21; i < 25; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 25; i < 36; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 36; i < 55; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 55; i < 92; i++) {
    datawajah[4][i] = 0;
  }

  //baris 6
  for (byte i = 0; i < 36; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 36; i < 55; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 55; i < 92; i++) {
    datawajah[5][i] = 0;
  }

  //baris 7
  for (byte i = 0; i < 36; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 36; i < 56; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 56; i < 92; i++) {
    datawajah[6][i] = 0;
  }

  //baris 8
  for (byte i = 0; i < 36; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 36; i < 55; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 55; i < 92; i++) {
    datawajah[7][i] = 0;
  }

  //baris 9
  for (byte i = 0; i < 28; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 28; i < 29; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 29; i < 36; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 36; i < 55; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 55; i < 92; i++) {
    datawajah[8][i] = 0;
  }

  //baris 10
  for (byte i = 0; i < 27; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 27; i < 31; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 31; i < 36; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 36; i < 56; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 56; i < 57; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 57; i < 59; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 59; i < 92; i++) {
    datawajah[9][i] = 0;
  }

  //baris 11
  for (byte i = 0; i < 28; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 28; i < 31; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 31; i < 34; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 34; i < 59; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 59; i < 92; i++) {
    datawajah[10][i] = 0;
  }

  //baris 12
  for (byte i = 0; i < 28; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 28; i < 64; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 64; i < 85; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 85; i < 86; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 86; i < 92; i++) {
    datawajah[11][i] = 0;
  }

  //baris 13
  for (byte i = 0; i < 19; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 19; i < 20; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 20; i < 21; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 21; i < 71; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 71; i < 85; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 85; i < 86; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 86; i < 92; i++) {
    datawajah[12][i] = 0;
  }


  //baris 14
  for (byte i = 0; i < 17; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 17; i < 74 ; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 74; i < 81; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 81; i < 92 ; i++) {
    datawajah[13][i] = 1;
  }

  //baris 15
  for (byte i = 0; i < 16; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 16; i < 92; i++) {
    datawajah[14][i] = 1;
  }

  //baris 16
  for (byte i = 0; i < 14; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 14; i < 92; i++) {
    datawajah[15][i] = 1;
  }

  //baris 17
  for (byte i = 0; i < 13; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 13; i < 92; i++) {
    datawajah[16][i] = 1;
  }

  //baris 18
  for (byte i = 0; i < 13; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 13; i < 92; i++) {
    datawajah[17][i] = 1;
  }

  //baris 19
  for (byte i = 0; i < 3; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 3; i < 8; i++) {
    datawajah[18][i] = 1;
  } for (byte i = 8; i < 10; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 10; i < 92; i++) {
    datawajah[18][i] = 1;
  }

  //baris 20
  for (byte i = 0; i < 92; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 92; i++) {
    datawajah[20][i] = 1;
  }
}

dataset:: wajahdepan6()
{
  baris = 23;
  kolom = 101;
  //baris 1
  for (byte i = 0 ; i < 3; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 3 ; i < 26; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 26 ; i < 41; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 41 ; i < 56; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 56 ; i < 72; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 72 ; i < 101; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 2; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 2; i < 27; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 27; i < 41; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 41; i < 56; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 56; i < 72; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 72; i < 101; i++) {
    datawajah[1][i] = 1;
  }
  //baris 3
  for (byte i = 0; i < 3; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 3; i < 28; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 28; i < 41; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 41; i < 57; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 57; i < 72; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 71; i < 101; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 5; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 5; i < 29; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 29; i < 40; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 40; i < 58; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 58; i < 72; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 72; i < 80; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 80; i < 81; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 81; i < 82; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 82; i < 83; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 83; i < 101; i++) {
    datawajah[3][i] = 1;
  }


  //baris 5
  for (byte i = 0; i < 23; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 23; i < 29; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 29; i < 41; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 41; i < 59; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 59; i < 92; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 92; i < 101; i++) {
    datawajah[4][i] = 1;
  }

  //baris 6
  for (byte i = 0; i < 27; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 27; i < 28; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 28; i < 41; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 41; i < 59; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 59; i < 95; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 95; i < 101; i++) {
    datawajah[5][i] = 1;
  }

  //baris 7
  for (byte i = 0; i < 40; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 40; i < 60; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 60; i < 97; i++) {
    datawajah[6][i] = 0;
  }  for (byte i = 97; i < 101; i++) {
    datawajah[6][i] = 1;
  }

  //baris 8
  for (byte i = 0; i < 40; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 40; i < 60; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 60; i < 98; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 98; i < 101; i++) {
    datawajah[7][i] = 1;
  }

  //baris 9
  for (byte i = 0; i < 40; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 40; i < 60; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 60; i < 100; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 100; i < 101; i++) {
    datawajah[8][i] = 1;
  }

  //baris 10
  for (byte i = 0; i < 40; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 40; i < 60; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 60; i < 101; i++) {
    datawajah[9][i] = 0;
  }

  //baris 11
  for (byte i = 0; i < 32; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 32; i < 36; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 36; i < 40; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 40; i < 63; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 63; i < 101; i++) {
    datawajah[10][i] = 0;
  }

  //baris 12
  for (byte i = 0; i < 32; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 32; i < 37; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 37; i < 40; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 40; i < 64; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 64; i < 101; i++) {
    datawajah[11][i] = 0;
  }

  //baris 13
  for (byte i = 0; i < 32; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 32; i < 70; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 70; i < 101; i++) {
    datawajah[12][i] = 0;
  }

  //baris 14
  for (byte i = 0; i < 22; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 22; i < 76; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 76; i < 89; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 89; i < 90; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 90; i < 101; i++) {
    datawajah[13][i] = 0;
  }

  //baris 15
  for (byte i = 0; i < 21; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 21; i < 79; i++) {
    datawajah[14][i] = 1;
  } for (byte i = 79; i < 86; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 86; i < 101; i++) {
    datawajah[14][i] = 1;
  }

  //baris 16
  for (byte i = 0; i < 19; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 19; i < 101; i++) {
    datawajah[15][i] = 1;
  }

  //baris 17
  for (byte i = 0; i < 13; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 13; i < 15; i++) {
    datawajah[16][i] = 1;
  } for (byte i = 15; i < 17; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 17; i < 101; i++) {
    datawajah[16][i] = 1;
  }

  //baris 18
  for (byte i = 0; i < 9; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 9; i < 10; i++) {
    datawajah[17][i] = 1;
  } for (byte i = 10; i < 13; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 13; i < 16; i++) {
    datawajah[17][i] = 1;
  } for (byte i = 16; i < 17; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 17; i < 101; i++) {
    datawajah[17][i] = 1;
  }

  //baris 19
  for (byte i = 0; i < 8; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 8; i < 10; i++) {
    datawajah[18][i] = 1;
  } for (byte i = 10; i < 13; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 13; i < 101; i++) {
    datawajah[18][i] = 1;
  }

  //baris 20
  for (byte i = 0; i < 1; i++) {
    datawajah[19][i] = 0;
  }  for (byte i = 1; i < 3; i++) {
    datawajah[19][i] = 1;
  } for (byte i = 3; i < 5; i++) {
    datawajah[19][i] = 0;
  }  for (byte i = 5; i < 101; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 1; i++) {
    datawajah[20][i] = 0;
  } for (byte i = 1; i < 101; i++) {
    datawajah[20][i] = 1;
  }

  //baris 22
  for (byte i = 0; i < 101; i++) {
    datawajah[21][i] = 1;
  }

  //baris23
  for (byte i = 0; i < 101; i++) {
    datawajah[22][i] = 1;
  }

}

dataset:: wajahdepan7()
{
  baris = 21;
  kolom = 98;
  //baris 1
  for (byte i = 0 ; i < 2; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 2 ; i < 28; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 28 ; i < 40; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 40 ; i < 57; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 57 ; i < 71; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 71 ; i < 98; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 5; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 5; i < 13; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 13; i < 16; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 16; i < 17; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 17; i < 19; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 19; i < 30; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 30; i < 40; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 40; i < 58; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 58; i < 70; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 70; i < 98; i++) {
    datawajah[1][i] = 1;
  }

  //baris 3
  for (byte i = 0; i < 25; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 25; i < 29; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 29; i < 40; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 40; i < 58; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 58; i < 87; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 87; i < 98; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 40; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 40; i < 58; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 58; i < 92; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 92; i < 98; i++) {
    datawajah[3][i] = 1;
  }

  //baris 5
  for (byte i = 0; i < 13; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 13; i < 17; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 17; i < 39; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 39; i < 59; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 59; i < 95; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 95; i < 98; i++) {
    datawajah[4][i] = 1;
  }

  //baris 6
  for (byte i = 0; i < 40; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 40; i < 59; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 59; i < 96; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 96; i < 98; i++) {
    datawajah[5][i] = 1;
  }

  //baris 7
  for (byte i = 0; i < 40; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 40; i < 59; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 59; i < 98; i++) {
    datawajah[6][i] = 0;
  }

  //baris 8
  for (byte i = 0; i < 31; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 31; i < 35; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 35; i < 39; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 39; i < 59; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 59; i < 98; i++) {
    datawajah[7][i] = 0;
  }

  //baris 9
  for (byte i = 0; i < 31; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 31; i < 35; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 35; i < 39; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 39; i < 61; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 61; i < 98; i++) {
    datawajah[8][i] = 0;
  }

  //baris 10
  for (byte i = 0; i < 31; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 31; i < 63; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 63; i < 98; i++) {
    datawajah[9][i] = 0;
  }

  //baris 11
  for (byte i = 0; i < 22; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 22; i < 23; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 23; i < 31; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 31; i < 67; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 67; i < 98; i++) {
    datawajah[10][i] = 0;
  }

  //baris 12
  for (byte i = 0; i < 21; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 21; i < 74; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 74; i < 88; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 88; i < 90; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 90; i < 98; i++) {
    datawajah[11][i] = 0;
  }

  //baris 13
  for (byte i = 0; i < 20; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 20; i < 77; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 77; i < 86; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 86; i < 94; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 94; i < 98; i++) {
    datawajah[12][i] = 0;
  }

  //baris 14
  for (byte i = 0; i < 17; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 17; i < 98; i++) {
    datawajah[13][i] = 1;
  }

  //baris 15
  for (byte i = 0; i < 11; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 11; i < 98; i++) {
    datawajah[14][i] = 1;
  }

  //baris 16
  for (byte i = 0; i < 14; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 14; i < 98; i++) {
    datawajah[15][i] = 1;
  }

  //baris 17
  for (byte i = 0; i < 1; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 1; i < 98; i++) {
    datawajah[16][i] = 1;
  }

  //baris 18
  for (byte i = 0; i < 2; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 2; i < 98; i++) {
    datawajah[17][i] = 1;
  }

  //baris 19
  for (byte i = 0; i < 98; i++) {
    datawajah[18][i] = 1;
  }

  //baris 20
  for (byte i = 0; i < 98; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 98; i++) {
    datawajah[20][i] = 1;
  }

}

dataset:: wajahdepan8 ()
{
  baris = 22;
  kolom = 98;
  //baris 1
  for (byte i = 0 ; i < 1; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 1 ; i < 26; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 26 ; i < 40; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 40 ; i < 54; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 54 ; i < 72; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 72 ; i < 98; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 2; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 2; i < 3; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 3; i < 5; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 5; i < 26; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 26; i < 40; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 40; i < 56; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 56; i < 72; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 72; i < 98; i++) {
    datawajah[1][i] = 1;
  }

  //baris 3
  for (byte i = 0; i < 6; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 6; i < 7; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 7; i < 12; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 12; i < 14; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 14; i < 15; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 15; i < 17; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 17; i < 20; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 20; i < 28; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 28; i < 39; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 39; i < 57; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 57; i < 74; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 74; i < 98; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 24; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 24; i < 28; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 28; i < 39; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 39; i < 57; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 57; i < 88; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 88; i < 98; i++) {
    datawajah[3][i] = 1;
  }


  //baris 5
  for (byte i = 0; i < 39; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 39; i < 57; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 57; i < 92; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 92; i < 98; i++) {
    datawajah[4][i] = 1;
  }

  //baris 6
  for (byte i = 0; i < 39; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 39; i < 59; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 59; i < 95; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 95; i < 98; i++) {
    datawajah[5][i] = 1;
  }

  //baris 7
  for (byte i = 0; i < 39; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 39; i < 59; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 59; i < 97; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 97; i < 98; i++) {
    datawajah[6][i] = 1;
  }

  //baris 8
  for (byte i = 0; i < 39; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 39; i < 59; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 59; i < 98; i++) {
    datawajah[7][i] = 0;
  }

  //baris 9
  for (byte i = 0; i < 31; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 31; i < 33; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 33; i < 40; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 40; i < 59; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 59; i < 98; i++) {
    datawajah[8][i] = 0;
  }

  //baris 10
  for (byte i = 0; i < 31; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 31; i < 35; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 35; i < 39; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 39; i < 61; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 61; i < 98; i++) {
    datawajah[9][i] = 0;
  }

  //baris 11
  for (byte i = 0; i < 31; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 31; i < 62; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 62; i < 98; i++) {
    datawajah[10][i] = 0;
  }

  //baris 12
  for (byte i = 0; i < 21; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 21; i < 22; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 22; i < 30; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 30; i < 64; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 64; i < 98; i++) {
    datawajah[11][i] = 0;
  }

  //baris 13
  for (byte i = 0; i < 20; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 20; i < 70; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 70; i < 98; i++) {
    datawajah[12][i] = 0;
  }

  //baris 14
  for (byte i = 0; i < 19; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 19; i < 77; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 77; i < 86; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 86; i < 92; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 92; i < 93; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 93; i < 98; i++) {
    datawajah[13][i] = 1;
  }

  //baris 15
  for (byte i = 0; i < 17; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 17; i < 95; i++) {
    datawajah[14][i] = 1;
  } for (byte i = 95; i < 97; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 97; i < 98; i++) {
    datawajah[14][i] = 1;
  }

  //baris 16
  for (byte i = 0; i < 11; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 11; i < 13; i++) {
    datawajah[15][i] = 1;
  } for (byte i = 13; i < 15; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 15; i < 98; i++) {
    datawajah[15][i] = 1;
  }

  //baris 17
  for (byte i = 0; i < 15; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 15; i < 98; i++) {
    datawajah[16][i] = 1;
  }

  //baris 18
  for (byte i = 0; i < 4; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 4; i < 10; i++) {
    datawajah[17][i] = 1;
  } for (byte i = 10; i < 12; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 12; i < 13; i++) {
    datawajah[17][i] = 1;
  } for (byte i = 13; i < 14; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 14; i < 98; i++) {
    datawajah[17][i] = 1;
  }

  //baris 19
  for (byte i = 0; i < 98; i++) {
    datawajah[18][i] = 1;
  }

  //baris 20
  for (byte i = 0; i < 98; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 98; i++) {
    datawajah[20][i] = 1;
  }

  //baris 22
  for (byte i = 0; i < 98; i++) {
    datawajah[21][i] = 1;
  }

}

dataset:: wajahdepan9 ()
{
  baris = 23;
  kolom = 99;
  //baris 1
  for (byte i = 0 ; i < 1; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 1 ; i < 25; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 25 ; i < 40; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 40 ; i < 54; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 54 ; i < 73; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 73 ; i < 99; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 3; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 3; i < 27; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 27; i < 39; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 39; i < 55; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 55; i < 73; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 73; i < 99; i++) {
    datawajah[1][i] = 1;
  }

  //baris 3
  for (byte i = 0; i < 20; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 20; i < 28; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 28; i < 39; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 39; i < 57; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 57; i < 73; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 73; i < 99; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 24; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 24; i < 39; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 39; i < 57; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 57; i < 87; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 87; i < 99; i++) {
    datawajah[3][i] = 0;
  }


  //baris 5
  for (byte i = 0; i < 13; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 13; i < 15; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 15; i < 39; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 39; i < 58; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 58; i < 92; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 92; i < 99; i++) {
    datawajah[4][i] = 1;
  }

  //baris 6
  for (byte i = 0; i < 39; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 39; i < 58; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 58; i < 96; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 97; i < 99; i++) {
    datawajah[5][i] = 1;
  }

  //baris 7
  for (byte i = 0; i < 39; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 39; i < 58; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 58; i < 97; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 97; i < 99; i++) {
    datawajah[6][i] = 1;
  }

  //baris 8
  for (byte i = 0; i < 39; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 39; i < 59; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 59; i < 99; i++) {
    datawajah[7][i] = 0;
  }

  //baris 9
  for (byte i = 0; i < 31; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 31; i < 33; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 33; i < 40; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 40; i < 59; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 59; i < 99; i++) {
    datawajah[8][i] = 0;
  }

  //baris 10
  for (byte i = 0; i < 31; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 31; i < 34; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 34; i < 40; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 40; i < 60; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 60; i < 99; i++) {
    datawajah[9][i] = 0;
  }

  //baris 11
  for (byte i = 0; i < 31; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 31; i < 36; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 36; i < 38; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 38; i < 63; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 63; i < 99; i++) {
    datawajah[10][i] = 0;
  }

  //baris 12
  for (byte i = 0; i < 26; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 26; i < 29; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 29; i < 30; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 30; i < 64; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 64; i < 99; i++) {
    datawajah[11][i] = 0;
  }

  //baris 13
  for (byte i = 0; i < 19; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 19; i < 72; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 72; i < 99; i++) {
    datawajah[12][i] = 0;
  }

  //baris 14
  for (byte i = 0; i < 18; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 18; i < 72; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 72; i < 92; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 92; i < 99; i++) {
    datawajah[13][i] = 1;
  }

  //baris 15
  for (byte i = 0; i < 15; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 15; i < 99; i++) {
    datawajah[14][i] = 1;
  }

  //baris 16
  for (byte i = 0; i < 12; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 12; i < 99; i++) {
    datawajah[15][i] = 1;
  }

  //baris 17
  for (byte i = 0; i < 14; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 14; i < 99; i++) {
    datawajah[16][i] = 1;
  }

  //baris 18
  for (byte i = 0; i < 4; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 4; i < 8; i++) {
    datawajah[17][i] = 1;
  } for (byte i = 8; i < 11; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 11; i < 99; i++) {
    datawajah[17][i] = 1;
  }

  //baris 19
  for (byte i = 0; i < 1; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 1; i < 99; i++) {
    datawajah[18][i] = 1;
  }

  //baris 20
  for (byte i = 0; i < 1; i++) {
    datawajah[19][i] = 0;
  } for (byte i = 1; i < 99; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 99; i++) {
    datawajah[20][i] = 1;
  }

  //baris 22
  for (byte i = 0; i < 99; i++) {
    datawajah[21][i] = 1;
  }

  //baris 23
  for (byte i = 0; i < 99; i++) {
    datawajah[22][i] = 1;
  }
}

dataset:: wajahdepan10 ()
{
  baris = 21;
  kolom = 92;
  //baris 1
  for (byte i = 0 ; i < 22; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 1 ; i < 37; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 25 ; i < 52; i++) {
    datawajah[0][i] = 1;
  } for (byte i = 40 ; i < 68; i++) {
    datawajah[0][i] = 0;
  } for (byte i = 54 ; i < 92; i++) {
    datawajah[0][i] = 1;
  }

  //baris 2
  for (byte i = 0; i < 23; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 3; i < 36; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 27; i < 53; i++) {
    datawajah[1][i] = 1;
  } for (byte i = 39; i < 67; i++) {
    datawajah[1][i] = 0;
  } for (byte i = 55; i < 92; i++) {
    datawajah[1][i] = 1;
  }

  //baris 3
  for (byte i = 0; i < 24; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 24; i < 36; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 36; i < 53; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 53; i < 67; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 67; i < 69; i++) {
    datawajah[2][i] = 1;
  } for (byte i = 69; i < 75; i++) {
    datawajah[2][i] = 0;
  } for (byte i = 75; i < 92; i++) {
    datawajah[2][i] = 1;
  }

  //baris 4
  for (byte i = 0; i < 1; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 1; i < 3; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 3; i < 17; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 17; i < 24; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 24; i < 36; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 36; i < 55; i++) {
    datawajah[3][i] = 1;
  } for (byte i = 55; i < 87; i++) {
    datawajah[3][i] = 0;
  } for (byte i = 87; i < 92; i++) {
    datawajah[3][i] = 1;
  }


  //baris 5
  for (byte i = 0; i < 21; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 21; i < 25; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 25; i < 36; i++) {
    datawajah[4][i] = 0;
  } for (byte i = 36; i < 55; i++) {
    datawajah[4][i] = 1;
  } for (byte i = 55; i < 92; i++) {
    datawajah[4][i] = 0;
  }

  //baris 6
  for (byte i = 0; i < 36; i++) {
    datawajah[5][i] = 0;
  } for (byte i = 39; i < 55; i++) {
    datawajah[5][i] = 1;
  } for (byte i = 58; i < 92; i++) {
    datawajah[5][i] = 0;
  }

  //baris 7
  for (byte i = 0; i < 36; i++) {
    datawajah[6][i] = 0;
  } for (byte i = 36; i < 56; i++) {
    datawajah[6][i] = 1;
  } for (byte i = 56; i < 92; i++) {
    datawajah[6][i] = 0;
  }

  //baris 8
  for (byte i = 0; i < 36; i++) {
    datawajah[7][i] = 0;
  } for (byte i = 36; i < 55; i++) {
    datawajah[7][i] = 1;
  } for (byte i = 55; i < 92; i++) {
    datawajah[7][i] = 0;
  }

  //baris 9
  for (byte i = 0; i < 25; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 25; i < 29; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 29; i < 35; i++) {
    datawajah[8][i] = 0;
  } for (byte i = 35; i < 55; i++) {
    datawajah[8][i] = 1;
  } for (byte i = 55; i < 91; i++) {
    datawajah[8][i] = 0;
  }

  //baris 10
  for (byte i = 0; i < 27; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 27; i < 31; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 31; i < 36; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 36; i < 56; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 56; i < 57; i++) {
    datawajah[9][i] = 0;
  } for (byte i = 57; i < 59; i++) {
    datawajah[9][i] = 1;
  } for (byte i = 59; i < 92; i++) {
    datawajah[9][i] = 0;
  }

  //baris 11
  for (byte i = 0; i < 25; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 25; i < 31; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 31; i < 34; i++) {
    datawajah[10][i] = 0;
  } for (byte i = 34; i < 59; i++) {
    datawajah[10][i] = 1;
  } for (byte i = 59; i < 92; i++) {
    datawajah[10][i] = 0;
  }

  //baris 12
  for (byte i = 0; i < 28; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 28; i < 64; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 64; i < 84; i++) {
    datawajah[11][i] = 0;
  } for (byte i = 84; i < 86; i++) {
    datawajah[11][i] = 1;
  } for (byte i = 86; i < 92; i++) {
    datawajah[11][i] = 0;
  }

  //baris 13
  for (byte i = 0; i < 19; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 19; i < 20; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 20; i < 21; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 21; i < 71; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 71; i < 85; i++) {
    datawajah[12][i] = 0;
  } for (byte i = 85; i < 86; i++) {
    datawajah[12][i] = 1;
  } for (byte i = 86; i < 92; i++) {
    datawajah[12][i] = 0;
  }

  //baris 14
  for (byte i = 0; i < 17; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 17; i < 74; i++) {
    datawajah[13][i] = 1;
  } for (byte i = 74; i < 81; i++) {
    datawajah[13][i] = 0;
  } for (byte i = 81; i < 92; i++) {
    datawajah[13][i] = 1;
  }

  //baris 15
  for (byte i = 0; i < 16; i++) {
    datawajah[14][i] = 0;
  } for (byte i = 16; i < 92; i++) {
    datawajah[14][i] = 1;
  }

  //baris 16
  for (byte i = 0; i < 14; i++) {
    datawajah[15][i] = 0;
  } for (byte i = 14; i < 92; i++) {
    datawajah[15][i] = 1;
  }

  //baris 17
  for (byte i = 0; i < 13; i++) {
    datawajah[16][i] = 0;
  } for (byte i = 13; i < 92; i++) {
    datawajah[16][i] = 1;
  }

  //baris 18
  for (byte i = 0; i < 13; i++) {
    datawajah[17][i] = 0;
  } for (byte i = 13; i < 92; i++) {
    datawajah[17][i] = 1;
  }

  //baris 19
  for (byte i = 0; i < 3; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 3; i < 8; i++) {
    datawajah[18][i] = 1;
  } for (byte i = 8; i < 10; i++) {
    datawajah[18][i] = 0;
  } for (byte i = 10; i < 92; i++) {
    datawajah[18][i] = 1;
  }

  //baris 20
  for (byte i = 0; i < 92; i++) {
    datawajah[19][i] = 1;
  }

  //baris 21
  for (byte i = 0; i < 92; i++) {
    datawajah[20][i] = 1;
  }
}


//wajah samping kiri
dataset::wajahkiri1()
{
baris = 23;
  kolom = 102;
//Baris1
for (byte i=0;i<=30;i++) {
datawajah[0][i]=1; }
for (byte i=31;i<=42;i++) {
datawajah[0][i]=0; }
for (byte i=43;i<=60;i++) {
datawajah[0][i]=1; }
for (byte i=61;i<=78;i++) {
datawajah[0][i]=0; }
for (byte i=79;i<=101;i++) {
datawajah[0][i]=1; }


//Baris2
for (byte i=0;i<=16;i++) {
datawajah[1][i]=1; }
for (byte i=17;i<=42;i++) {
datawajah[1][i]=0; }
for (byte i=43;i<=60;i++) {
datawajah[1][i]=1; }
for (byte i=61;i<=76;i++) {
datawajah[1][i]=0; }
for (byte i=77;i<=99;i++) {
datawajah[1][i]=1; }
for (byte i=100;i<=100;i++) {
datawajah[1][i]=0; }
for (byte i=101;i<=101;i++) {
datawajah[1][i]=1; }

//Baris3
for (byte i=0;i<=12;i++) {
datawajah[2][i]=1; }
for (byte i=13;i<=42;i++) {
datawajah[2][i]=0; }
for (byte i=43;i<=61;i++) {
datawajah[2][i]=1; }
for (byte i=62;i<=74;i++) {
datawajah[2][i]=0; }
for (byte i=75;i<=85;i++) {
datawajah[2][i]=1; }
for (byte i=86;i<=88;i++) {
datawajah[2][i]=0; }
for (byte i=89;i<=89;i++) {
datawajah[2][i]=1; }
for (byte i=90;i<=91;i++) {
datawajah[2][i]=0; }
for (byte i=92;i<=98;i++) {
datawajah[2][i]=1; }
for (byte i=99;i<=101;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=5;i++) {
datawajah[3][i]=1; }
for (byte i=6;i<=6;i++) {
datawajah[3][i]=0; }
for (byte i=7;i<=8;i++) {
datawajah[3][i]=1; }
for (byte i=9;i<=16;i++) {
datawajah[3][i]=0; }
for (byte i=17;i<=18;i++) {
datawajah[3][i]=1; }
for (byte i=19;i<=42;i++) {
datawajah[3][i]=0; }
for (byte i=43;i<=61;i++) {
datawajah[3][i]=1; }
for (byte i=62;i<=74;i++) {
datawajah[3][i]=0; }
for (byte i=75;i<=80;i++) {
datawajah[3][i]=1; }
for (byte i=81;i<=101;i++) {
datawajah[3][i]=0; }


//Baris5
for (byte i=0;i<=4;i++) {
datawajah[4][i]=1; }
for (byte i=5;i<=12;i++) {
datawajah[4][i]=0; }
for (byte i=13;i<=20;i++) {
datawajah[4][i]=1; }
for (byte i=21;i<=42;i++) {
datawajah[4][i]=0; }
for (byte i=43;i<=63;i++) {
datawajah[4][i]=1; }
for (byte i=64;i<=75;i++) {
datawajah[4][i]=0; }
for (byte i=76;i<=76;i++) {
datawajah[4][i]=1; }
for (byte i=77;i<=101;i++) {
datawajah[4][i]=0; }

//Baris6
for (byte i=0;i<=1;i++) {
datawajah[5][i]=0; }
for (byte i=2;i<=2;i++) {
datawajah[5][i]=1; }
for (byte i=3;i<=11;i++) {
datawajah[5][i]=0; }
for (byte i=12;i<=18;i++) {
datawajah[5][i]=1; }
for (byte i=19;i<=44;i++) {
datawajah[5][i]=0; }
for (byte i=45;i<=64;i++) {
datawajah[5][i]=1; }
for (byte i=65;i<=101;i++) {
datawajah[5][i]=0; }

//Baris7
for (byte i=0;i<=42;i++) {
datawajah[6][i]=0; }
for (byte i=43;i<=64;i++) {
datawajah[6][i]=1; }
for (byte i=65;i<=71;i++) {
datawajah[6][i]=0; }
for (byte i=72;i<=73;i++) {
datawajah[6][i]=1; }
for (byte i=74;i<=101;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=41;i++) {
datawajah[7][i]=0; }
for (byte i=42;i<=64;i++) {
datawajah[7][i]=1; }
for (byte i=65;i<=70;i++) {
datawajah[7][i]=0; }
for (byte i=71;i<=73;i++) {
datawajah[7][i]=1; }
for (byte i=74;i<=101;i++) {
datawajah[7][i]=0; }


//Baris9
for (byte i=0;i<=41;i++) {
datawajah[8][i]=0; }
for (byte i=42;i<=64;i++) {
datawajah[8][i]=1; }
for (byte i=65;i<=70;i++) {
datawajah[8][i]=0; }
for (byte i=71;i<=72;i++) {
datawajah[8][i]=1; }
for (byte i=73;i<=101;i++) {
datawajah[8][i]=0; }


//Baris10
for (byte i=0;i<=41;i++) {
datawajah[9][i]=0; }
for (byte i=42;i<=65;i++) {
datawajah[9][i]=1; }
for (byte i=66;i<=70;i++) {
datawajah[9][i]=0; }
for (byte i=71;i<=71;i++) {
datawajah[9][i]=1; }
for (byte i=72;i<=76;i++) {
datawajah[9][i]=0; }
for (byte i=77;i<=78;i++) {
datawajah[9][i]=1; }
for (byte i=79;i<=101;i++) {
datawajah[9][i]=0; }

//Baris11
for (byte i=0;i<=24;i++) {
datawajah[10][i]=0; }
for (byte i=25;i<=25;i++) {
datawajah[10][i]=1; }
for (byte i=26;i<=44;i++) {
datawajah[10][i]=0; }
for (byte i=45;i<=65;i++) {
datawajah[10][i]=1; }
for (byte i=66;i<=76;i++) {
datawajah[10][i]=0; }
for (byte i=77;i<=78;i++) {
datawajah[10][i]=1; }
for (byte i=79;i<=101;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=44;i++) {
datawajah[11][i]=0; }
for (byte i=45;i<=65;i++) {
datawajah[11][i]=1; }
for (byte i=66;i<=76;i++) {
datawajah[11][i]=0; }
for (byte i=77;i<=78;i++) {
datawajah[11][i]=1; }
for (byte i=79;i<=101;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=43;i++) {
datawajah[12][i]=0; }
for (byte i=44;i<=65;i++) {
datawajah[12][i]=1; }
for (byte i=66;i<=101;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=42;i++) {
datawajah[13][i]=0; }
for (byte i=43;i<=65;i++) {
datawajah[13][i]=1; }
for (byte i=66;i<=101;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=41;i++) {
datawajah[14][i]=0; }
for (byte i=42;i<=66;i++) {
datawajah[14][i]=1; }
for (byte i=67;i<=101;i++) {
datawajah[14][i]=0; }


//Baris16
for (byte i=0;i<=40;i++) {
datawajah[15][i]=0; }
for (byte i=41;i<=67;i++) {
datawajah[15][i]=1; }
for (byte i=68;i<=101;i++) {
datawajah[15][i]=0; }

//Baris17
for (byte i=0;i<=8;i++) {
datawajah[16][i]=0; }
for (byte i=9;i<=13;i++) {
datawajah[16][i]=1; }
for (byte i=14;i<=14;i++) {
datawajah[16][i]=0; }
for (byte i=15;i<=16;i++) {
datawajah[16][i]=1; }
for (byte i=17;i<=38;i++) {
datawajah[16][i]=0; }
for (byte i=39;i<=67;i++) {
datawajah[16][i]=1; }
for (byte i=68;i<=101;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=11;i++) {
datawajah[17][i]=0; }
for (byte i=12;i<=16;i++) {
datawajah[17][i]=1; }
for (byte i=17;i<=25;i++) {
datawajah[17][i]=0; }
for (byte i=26;i<=31;i++) {
datawajah[17][i]=1; }
for (byte i=32;i<=37;i++) {
datawajah[17][i]=0; }
for (byte i=38;i<=67;i++) {
datawajah[17][i]=1; }
for (byte i=68;i<=101;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=2;i++) {
datawajah[18][i]=0; }
for (byte i=3;i<=4;i++) {
datawajah[18][i]=1; }
for (byte i=5;i<=22;i++) {
datawajah[18][i]=0; }
for (byte i=23;i<=31;i++) {
datawajah[18][i]=1; }
for (byte i=32;i<=36;i++) {
datawajah[18][i]=0; }
for (byte i=37;i<=68;i++) {
datawajah[18][i]=1; }
for (byte i=69;i<=78;i++) {
datawajah[18][i]=0; }
for (byte i=79;i<=83;i++) {
datawajah[18][i]=1; }
for (byte i=84;i<=101;i++) {
datawajah[18][i]=0; }


//Baris20
for (byte i=0;i<=10;i++) {
datawajah[19][i]=1; }
for (byte i=11;i<=21;i++) {
datawajah[19][i]=0; }
for (byte i=22;i<=32;i++) {
datawajah[19][i]=1; }
for (byte i=33;i<=36;i++) {
datawajah[19][i]=0; }
for (byte i=37;i<=68;i++) {
datawajah[19][i]=1; }
for (byte i=69;i<=78;i++) {
datawajah[19][i]=0; }
for (byte i=79;i<=84;i++) {
datawajah[19][i]=1; }
for (byte i=85;i<=101;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=15;i++) {
datawajah[20][i]=1; }
for (byte i=16;i<=17;i++) {
datawajah[20][i]=0; }
for (byte i=18;i<=32;i++) {
datawajah[20][i]=1; }
for (byte i=33;i<=35;i++) {
datawajah[20][i]=0; }
for (byte i=36;i<=68;i++) {
datawajah[20][i]=1; }
for (byte i=69;i<=77;i++) {
datawajah[20][i]=0; }
for (byte i=78;i<=90;i++) {
datawajah[20][i]=1; }
for (byte i=91;i<=101;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=33;i++) {
datawajah[21][i]=1; }
for (byte i=34;i<=34;i++) {
datawajah[21][i]=0; }
for (byte i=35;i<=68;i++) {
datawajah[21][i]=1; }
for (byte i=69;i<=77;i++) {
datawajah[21][i]=0; }
for (byte i=78;i<=91;i++) {
datawajah[21][i]=1; }
for (byte i=92;i<=101;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=32;i++) {
datawajah[22][i]=1; }
for (byte i=33;i<=34;i++) {
datawajah[22][i]=0; }
for (byte i=35;i<=69;i++) {
datawajah[22][i]=1; }
for (byte i=70;i<=77;i++) {
datawajah[22][i]=0; }
for (byte i=78;i<=92;i++) {
datawajah[22][i]=1; }
for (byte i=93;i<=94;i++) {
datawajah[22][i]=0; }
for (byte i=95;i<=95;i++) {
datawajah[22][i]=1; }
for (byte i=96;i<=101;i++) {
datawajah[22][i]=0; }

}

dataset:: wajahkiri2()

{
  baris = 25;
  kolom = 108;
//Baris1
for (byte i=0;i<=26;i++) {
datawajah[0][i]=1; }
for (byte i=27;i<=38;i++) {
datawajah[0][i]=0; }
for (byte i=39;i<=59;i++) {
datawajah[0][i]=1; }
for (byte i=60;i<=76;i++) {
datawajah[0][i]=0; }
for (byte i=77;i<=86;i++) {
datawajah[0][i]=1; }
for (byte i=87;i<=87;i++) {
datawajah[0][i]=0; }
for (byte i=88;i<=98;i++) {
datawajah[0][i]=1; }
for (byte i=99;i<=107;i++) {
datawajah[0][i]=0; }

//Baris2
for (byte i=0;i<=27;i++) {
datawajah[1][i]=1; }
for (byte i=28;i<=38;i++) {
datawajah[1][i]=0; }
for (byte i=39;i<=59;i++) {
datawajah[1][i]=1; }
for (byte i=60;i<=75;i++) {
datawajah[1][i]=0; }
for (byte i=76;i<=82;i++) {
datawajah[1][i]=1; }
for (byte i=83;i<=107;i++) {
datawajah[1][i]=0; }

//Baris3
for (byte i=0;i<=28;i++) {
datawajah[2][i]=1; }
for (byte i=29;i<=39;i++) {
datawajah[2][i]=0; }
for (byte i=40;i<=59;i++) {
datawajah[2][i]=1; }
for (byte i=60;i<=74;i++) {
datawajah[2][i]=0; }
for (byte i=75;i<=78;i++) {
datawajah[2][i]=1; }
for (byte i=79;i<=107;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=13;i++) {
datawajah[3][i]=1; }
for (byte i=14;i<=40;i++) {
datawajah[3][i]=0; }
for (byte i=41;i<=60;i++) {
datawajah[3][i]=1; }
for (byte i=61;i<=74;i++) {
datawajah[3][i]=0; }
for (byte i=75;i<=77;i++) {
datawajah[3][i]=1; }
for (byte i=78;i<=107;i++) {
datawajah[3][i]=0; }

//Baris5
for (byte i=0;i<=8;i++) {
datawajah[4][i]=1; }
for (byte i=9;i<=40;i++) {
datawajah[4][i]=0; }
for (byte i=41;i<=62;i++) {
datawajah[4][i]=1; }
for (byte i=63;i<=74;i++) {
datawajah[4][i]=0; }
for (byte i=75;i<=75;i++) {
datawajah[4][i]=1; }
for (byte i=76;i<=107;i++) {
datawajah[4][i]=0; }

//Baris6
for (byte i=0;i<=3;i++) {
datawajah[5][i]=1; }
for (byte i=4;i<=15;i++) {
datawajah[5][i]=0; }
for (byte i=16;i<=17;i++) {
datawajah[5][i]=1; }
for (byte i=18;i<=40;i++) {
datawajah[5][i]=0; }
for (byte i=41;i<=63;i++) {
datawajah[5][i]=1; }
for (byte i=64;i<=107;i++) {
datawajah[5][i]=0; }

//Baris7
for (byte i=0;i<=11;i++) {
datawajah[6][i]=0; }
for (byte i=12;i<=18;i++) {
datawajah[6][i]=1; }
for (byte i=19;i<=40;i++) {
datawajah[6][i]=0; }
for (byte i=41;i<=63;i++) {
datawajah[6][i]=1; }
for (byte i=64;i<=71;i++) {
datawajah[6][i]=0; }
for (byte i=72;i<=73;i++) {
datawajah[6][i]=1; }
for (byte i=74;i<=107;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=10;i++) {
datawajah[7][i]=0; }
for (byte i=11;i<=15;i++) {
datawajah[7][i]=1; }
for (byte i=16;i<=40;i++) {
datawajah[7][i]=0; }
for (byte i=41;i<=63;i++) {
datawajah[7][i]=1; }
for (byte i=64;i<=70;i++) {
datawajah[7][i]=0; }
for (byte i=71;i<=72;i++) {
datawajah[7][i]=1; }
for (byte i=73;i<=107;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=39;i++) {
datawajah[8][i]=0; }
for (byte i=40;i<=64;i++) {
datawajah[8][i]=1; }
for (byte i=65;i<=71;i++) {
datawajah[8][i]=0; }
for (byte i=72;i<=72;i++) {
datawajah[8][i]=1; }
for (byte i=73;i<=78;i++) {
datawajah[8][i]=0; }
for (byte i=79;i<=79;i++) {
datawajah[8][i]=1; }
for (byte i=80;i<=107;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=39;i++) {
datawajah[9][i]=0; }
for (byte i=40;i<=64;i++) {
datawajah[9][i]=1; }
for (byte i=65;i<=77;i++) {
datawajah[9][i]=0; }
for (byte i=78;i<=80;i++) {
datawajah[9][i]=1; }
for (byte i=81;i<=107;i++) {
datawajah[9][i]=0; }

//Baris11
for (byte i=0;i<=40;i++) {
datawajah[10][i]=0; }
for (byte i=41;i<=64;i++) {
datawajah[10][i]=1; }
for (byte i=65;i<=69;i++) {
datawajah[10][i]=0; }
for (byte i=70;i<=71;i++) {
datawajah[10][i]=1; }
for (byte i=72;i<=78;i++) {
datawajah[10][i]=0; }
for (byte i=79;i<=80;i++) {
datawajah[10][i]=1; }
for (byte i=81;i<=107;i++) {
datawajah[10][i]=0; }


//Baris12
for (byte i=0;i<=24;i++) {
datawajah[11][i]=0; }
for (byte i=25;i<=26;i++) {
datawajah[11][i]=1; }
for (byte i=27;i<=42;i++) {
datawajah[11][i]=0; }
for (byte i=43;i<=64;i++) {
datawajah[11][i]=1; }
for (byte i=65;i<=107;i++) {
datawajah[11][i]=0; }

//Baris13
for (byte i=0;i<=43;i++) {
datawajah[12][i]=0; }
for (byte i=44;i<=65;i++) {
datawajah[12][i]=1; }
for (byte i=66;i<=107;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=42;i++) {
datawajah[13][i]=0; }
for (byte i=43;i<=65;i++) {
datawajah[13][i]=1; }
for (byte i=66;i<=107;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=7;i++) {
datawajah[14][i]=0; }
for (byte i=8;i<=9;i++) {
datawajah[14][i]=1; }
for (byte i=10;i<=41;i++) {
datawajah[14][i]=0; }
for (byte i=42;i<=65;i++) {
datawajah[14][i]=1; }
for (byte i=66;i<=107;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=40;i++) {
datawajah[15][i]=0; }
for (byte i=41;i<=66;i++) {
datawajah[15][i]=1; }
for (byte i=67;i<=107;i++) {
datawajah[15][i]=0; }

//Baris17
for (byte i=0;i<=39;i++) {
datawajah[16][i]=0; }
for (byte i=40;i<=67;i++) {
datawajah[16][i]=1; }
for (byte i=68;i<=107;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=38;i++) {
datawajah[17][i]=0; }
for (byte i=39;i<=67;i++) {
datawajah[17][i]=1; }
for (byte i=68;i<=77;i++) {
datawajah[17][i]=0; }
for (byte i=78;i<=80;i++) {
datawajah[17][i]=1; }
for (byte i=81;i<=107;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=26;i++) {
datawajah[18][i]=0; }
for (byte i=27;i<=29;i++) {
datawajah[18][i]=1; }
for (byte i=30;i<=37;i++) {
datawajah[18][i]=0; }
for (byte i=38;i<=67;i++) {
datawajah[18][i]=1; }
for (byte i=68;i<=77;i++) {
datawajah[18][i]=0; }
for (byte i=78;i<=83;i++) {
datawajah[18][i]=1; }
for (byte i=84;i<=85;i++) {
datawajah[18][i]=0; }
for (byte i=86;i<=87;i++) {
datawajah[18][i]=1; }
for (byte i=88;i<=106;i++) {
datawajah[18][i]=0; }
for (byte i=107;i<=107;i++) {
datawajah[18][i]=1; }

//Baris20
for (byte i=0;i<=10;i++) {
datawajah[19][i]=0; }
for (byte i=11;i<=14;i++) {
datawajah[19][i]=1; }
for (byte i=15;i<=23;i++) {
datawajah[19][i]=0; }
for (byte i=24;i<=28;i++) {
datawajah[19][i]=1; }
for (byte i=29;i<=35;i++) {
datawajah[19][i]=0; }
for (byte i=36;i<=68;i++) {
datawajah[19][i]=1; }
for (byte i=69;i<=77;i++) {
datawajah[19][i]=0; }
for (byte i=78;i<=91;i++) {
datawajah[19][i]=1; }
for (byte i=92;i<=95;i++) {
datawajah[19][i]=0; }
for (byte i=96;i<=96;i++) {
datawajah[19][i]=1; }
for (byte i=97;i<=107;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=10;i++) {
datawajah[20][i]=0; }
for (byte i=11;i<=14;i++) {
datawajah[20][i]=1; }
for (byte i=15;i<=20;i++) {
datawajah[20][i]=0; }
for (byte i=21;i<=30;i++) {
datawajah[20][i]=1; }
for (byte i=31;i<=35;i++) {
datawajah[20][i]=0; }
for (byte i=36;i<=68;i++) {
datawajah[20][i]=1; }
for (byte i=69;i<=77;i++) {
datawajah[20][i]=0; }
for (byte i=78;i<=96;i++) {
datawajah[20][i]=1; }
for (byte i=97;i<=107;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=7;i++) {
datawajah[21][i]=0; }
for (byte i=8;i<=8;i++) {
datawajah[21][i]=1; }
for (byte i=9;i<=11;i++) {
datawajah[21][i]=0; }
for (byte i=12;i<=14;i++) {
datawajah[21][i]=1; }
for (byte i=15;i<=19;i++) {
datawajah[21][i]=0; }
for (byte i=20;i<=31;i++) {
datawajah[21][i]=1; }
for (byte i=32;i<=34;i++) {
datawajah[21][i]=0; }
for (byte i=35;i<=68;i++) {
datawajah[21][i]=1; }
for (byte i=69;i<=71;i++) {
datawajah[21][i]=0; }
for (byte i=72;i<=72;i++) {
datawajah[21][i]=1; }
for (byte i=73;i<=77;i++) {
datawajah[21][i]=0; }
for (byte i=78;i<=97;i++) {
datawajah[21][i]=1; }
for (byte i=98;i<=107;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=2;i++) {
datawajah[22][i]=0; }
for (byte i=3;i<=3;i++) {
datawajah[22][i]=1; }
for (byte i=4;i<=11;i++) {
datawajah[22][i]=0; }
for (byte i=12;i<=12;i++) {
datawajah[22][i]=1; }
for (byte i=13;i<=17;i++) {
datawajah[22][i]=0; }
for (byte i=18;i<=32;i++) {
datawajah[22][i]=1; }
for (byte i=33;i<=33;i++) {
datawajah[22][i]=0; }
for (byte i=34;i<=69;i++) {
datawajah[22][i]=1; }
for (byte i=70;i<=77;i++) {
datawajah[22][i]=0; }
for (byte i=78;i<=94;i++) {
datawajah[22][i]=1; }
for (byte i=95;i<=107;i++) {
datawajah[22][i]=0; }

//Baris24
for (byte i=0;i<=31;i++) {
datawajah[23][i]=1; }
for (byte i=32;i<=32;i++) {
datawajah[23][i]=0; }
for (byte i=33;i<=70;i++) {
datawajah[23][i]=1; }
for (byte i=71;i<=71;i++) {
datawajah[23][i]=0; }
for (byte i=72;i<=73;i++) {
datawajah[23][i]=1; }
for (byte i=74;i<=78;i++) {
datawajah[23][i]=0; }
for (byte i=79;i<=94;i++) {
datawajah[23][i]=1; }
for (byte i=95;i<=96;i++) {
datawajah[23][i]=0; }
for (byte i=97;i<=97;i++) {
datawajah[23][i]=1; }
for (byte i=98;i<=98;i++) {
datawajah[23][i]=0; }
for (byte i=99;i<=100;i++) {
datawajah[23][i]=1; }
for (byte i=101;i<=105;i++) {
datawajah[23][i]=0; }
for (byte i=106;i<=107;i++) {
datawajah[23][i]=1; }

//Baris25
for (byte i=0;i<=30;i++) {
datawajah[24][i]=1; }
for (byte i=31;i<=32;i++) {
datawajah[24][i]=0; }
for (byte i=33;i<=73;i++) {
datawajah[24][i]=1; }
for (byte i=74;i<=79;i++) {
datawajah[24][i]=0; }
for (byte i=80;i<=94;i++) {
datawajah[24][i]=1; }
for (byte i=95;i<=104;i++) {
datawajah[24][i]=0; }
for (byte i=105;i<=107;i++) {
datawajah[24][i]=1; }



}

dataset:: wajahkiri3()
{
  baris = 25;
  kolom = 115;
//Baris1
for (byte i=0;i<=28;i++) {
datawajah[0][i]=1; }
for (byte i=29;i<=35;i++) {
datawajah[0][i]=0; }
for (byte i=36;i<=62;i++) {
datawajah[0][i]=1; }
for (byte i=63;i<=78;i++) {
datawajah[0][i]=0; }
for (byte i=79;i<=101;i++) {
datawajah[0][i]=1; }
for (byte i=102;i<=114;i++) {
datawajah[0][i]=0; }

//Baris2
for (byte i=0;i<=29;i++) {
datawajah[1][i]=1; }
for (byte i=30;i<=38;i++) {
datawajah[1][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[1][i]=1; }
for (byte i=63;i<=75;i++) {
datawajah[1][i]=0; }
for (byte i=76;i<=92;i++) {
datawajah[1][i]=1; }
for (byte i=93;i<=95;i++) {
datawajah[1][i]=0; }
for (byte i=96;i<=97;i++) {
datawajah[1][i]=1; }
for (byte i=98;i<=114;i++) {
datawajah[1][i]=0; }

//Baris3
for (byte i=0;i<=29;i++) {
datawajah[2][i]=1; }
for (byte i=30;i<=38;i++) {
datawajah[2][i]=0; }
for (byte i=39;i<=61;i++) {
datawajah[2][i]=1; }
for (byte i=62;i<=75;i++) {
datawajah[2][i]=0; }
for (byte i=76;i<=85;i++) {
datawajah[2][i]=1; }
for (byte i=86;i<=114;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=29;i++) {
datawajah[3][i]=1; }
for (byte i=30;i<=41;i++) {
datawajah[3][i]=0; }
for (byte i=42;i<=61;i++) {
datawajah[3][i]=1; }
for (byte i=62;i<=76;i++) {
datawajah[3][i]=0; }
for (byte i=77;i<=81;i++) {
datawajah[3][i]=1; }
for (byte i=82;i<=114;i++) {
datawajah[3][i]=0; }

//Baris5
for (byte i=0;i<=29;i++) {
datawajah[4][i]=1; }
for (byte i=30;i<=41;i++) {
datawajah[4][i]=0; }
for (byte i=42;i<=63;i++) {
datawajah[4][i]=1; }
for (byte i=64;i<=76;i++) {
datawajah[4][i]=0; }
for (byte i=77;i<=80;i++) {
datawajah[4][i]=1; }
for (byte i=81;i<=114;i++) {
datawajah[4][i]=0; }

//Baris6
for (byte i=0;i<=16;i++) {
datawajah[5][i]=1; }
for (byte i=17;i<=42;i++) {
datawajah[5][i]=0; }
for (byte i=43;i<=65;i++) {
datawajah[5][i]=1; }
for (byte i=66;i<=75;i++) {
datawajah[5][i]=0; }
for (byte i=76;i<=78;i++) {
datawajah[5][i]=1; }
for (byte i=79;i<=114;i++) {
datawajah[5][i]=0; }


//Baris7
for (byte i=0;i<=10;i++) {
datawajah[6][i]=1; }
for (byte i=11;i<=42;i++) {
datawajah[6][i]=0; }
for (byte i=43;i<=65;i++) {
datawajah[6][i]=1; }
for (byte i=66;i<=74;i++) {
datawajah[6][i]=0; }
for (byte i=75;i<=77;i++) {
datawajah[6][i]=1; }
for (byte i=78;i<=114;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=7;i++) {
datawajah[7][i]=1; }
for (byte i=8;i<=13;i++) {
datawajah[7][i]=0; }
for (byte i=14;i<=19;i++) {
datawajah[7][i]=1; }
for (byte i=20;i<=42;i++) {
datawajah[7][i]=0; }
for (byte i=43;i<=66;i++) {
datawajah[7][i]=1; }
for (byte i=67;i<=73;i++) {
datawajah[7][i]=0; }
for (byte i=74;i<=76;i++) {
datawajah[7][i]=1; }
for (byte i=77;i<=114;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=0;i++) {
datawajah[8][i]=1; }
for (byte i=1;i<=12;i++) {
datawajah[8][i]=0; }
for (byte i=13;i<=20;i++) {
datawajah[8][i]=1; }
for (byte i=21;i<=42;i++) {
datawajah[8][i]=0; }
for (byte i=43;i<=66;i++) {
datawajah[8][i]=1; }
for (byte i=67;i<=72;i++) {
datawajah[8][i]=0; }
for (byte i=73;i<=75;i++) {
datawajah[8][i]=1; }
for (byte i=76;i<=81;i++) {
datawajah[8][i]=0; }
for (byte i=82;i<=83;i++) {
datawajah[8][i]=1; }
for (byte i=84;i<=114;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=11;i++) {
datawajah[9][i]=0; }
for (byte i=12;i<=13;i++) {
datawajah[9][i]=1; }
for (byte i=14;i<=15;i++) {
datawajah[9][i]=0; }
for (byte i=16;i<=17;i++) {
datawajah[9][i]=1; }
for (byte i=18;i<=42;i++) {
datawajah[9][i]=0; }
for (byte i=43;i<=66;i++) {
datawajah[9][i]=1; }
for (byte i=67;i<=71;i++) {
datawajah[9][i]=0; }
for (byte i=72;i<=75;i++) {
datawajah[9][i]=1; }
for (byte i=76;i<=80;i++) {
datawajah[9][i]=0; }
for (byte i=81;i<=83;i++) {
datawajah[9][i]=1; }
for (byte i=84;i<=114;i++) {
datawajah[9][i]=0; }

//Baris11
for (byte i=0;i<=41;i++) {
datawajah[10][i]=0; }
for (byte i=42;i<=66;i++) {
datawajah[10][i]=1; }
for (byte i=67;i<=71;i++) {
datawajah[10][i]=0; }
for (byte i=72;i<=74;i++) {
datawajah[10][i]=1; }
for (byte i=75;i<=79;i++) {
datawajah[10][i]=0; }
for (byte i=80;i<=83;i++) {
datawajah[10][i]=1; }
for (byte i=84;i<=114;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=16;i++) {
datawajah[11][i]=0; }
for (byte i=17;i<=17;i++) {
datawajah[11][i]=1; }
for (byte i=18;i<=42;i++) {
datawajah[11][i]=0; }
for (byte i=43;i<=67;i++) {
datawajah[11][i]=1; }
for (byte i=68;i<=72;i++) {
datawajah[11][i]=0; }
for (byte i=73;i<=73;i++) {
datawajah[11][i]=1; }
for (byte i=74;i<=81;i++) {
datawajah[11][i]=0; }
for (byte i=82;i<=84;i++) {
datawajah[11][i]=1; }
for (byte i=85;i<=114;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=16;i++) {
datawajah[12][i]=0; }
for (byte i=17;i<=17;i++) {
datawajah[12][i]=1; }
for (byte i=18;i<=42;i++) {
datawajah[12][i]=0; }
for (byte i=43;i<=67;i++) {
datawajah[12][i]=1; }
for (byte i=68;i<=82;i++) {
datawajah[12][i]=0; }
for (byte i=83;i<=83;i++) {
datawajah[12][i]=1; }
for (byte i=84;i<=114;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=25;i++) {
datawajah[13][i]=0; }
for (byte i=26;i<=28;i++) {
datawajah[13][i]=1; }
for (byte i=29;i<=43;i++) {
datawajah[13][i]=0; }
for (byte i=44;i<=68;i++) {
datawajah[13][i]=1; }
for (byte i=69;i<=114;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=25;i++) {
datawajah[14][i]=0; }
for (byte i=26;i<=28;i++) {
datawajah[14][i]=1; }
for (byte i=29;i<=43;i++) {
datawajah[14][i]=0; }
for (byte i=44;i<=68;i++) {
datawajah[14][i]=1; }
for (byte i=69;i<=114;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=9;i++) {
datawajah[15][i]=0; }
for (byte i=10;i<=10;i++) {
datawajah[15][i]=1; }
for (byte i=11;i<=24;i++) {
datawajah[15][i]=0; }
for (byte i=25;i<=26;i++) {
datawajah[15][i]=1; }
for (byte i=27;i<=43;i++) {
datawajah[15][i]=0; }
for (byte i=44;i<=69;i++) {
datawajah[15][i]=1; }
for (byte i=70;i<=114;i++) {
datawajah[15][i]=0; }

//Baris17
for (byte i=0;i<=9;i++) {
datawajah[16][i]=0; }
for (byte i=10;i<=12;i++) {
datawajah[16][i]=1; }
for (byte i=13;i<=42;i++) {
datawajah[16][i]=0; }
for (byte i=43;i<=69;i++) {
datawajah[16][i]=1; }
for (byte i=70;i<=114;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=10;i++) {
datawajah[17][i]=0; }
for (byte i=11;i<=12;i++) {
datawajah[17][i]=1; }
for (byte i=13;i<=42;i++) {
datawajah[17][i]=0; }
for (byte i=43;i<=69;i++) {
datawajah[17][i]=1; }
for (byte i=70;i<=80;i++) {
datawajah[17][i]=0; }
for (byte i=81;i<=81;i++) {
datawajah[17][i]=1; }
for (byte i=82;i<=111;i++) {
datawajah[17][i]=0; }
for (byte i=112;i<=114;i++) {
datawajah[17][i]=1; }

//Baris19
for (byte i=0;i<=41;i++) {
datawajah[18][i]=0; }
for (byte i=42;i<=70;i++) {
datawajah[18][i]=1; }
for (byte i=71;i<=79;i++) {
datawajah[18][i]=0; }
for (byte i=80;i<=86;i++) {
datawajah[18][i]=1; }
for (byte i=87;i<=111;i++) {
datawajah[18][i]=0; }
for (byte i=112;i<=114;i++) {
datawajah[18][i]=1; }

//Baris20
for (byte i=0;i<=40;i++) {
datawajah[19][i]=0; }
for (byte i=41;i<=69;i++) {
datawajah[19][i]=1; }
for (byte i=70;i<=70;i++) {
datawajah[19][i]=0; }
for (byte i=71;i<=72;i++) {
datawajah[19][i]=1; }
for (byte i=73;i<=78;i++) {
datawajah[19][i]=0; }
for (byte i=79;i<=90;i++) {
datawajah[19][i]=1; }
for (byte i=91;i<=110;i++) {
datawajah[19][i]=0; }
for (byte i=111;i<=114;i++) {
datawajah[19][i]=1; }

//Baris21
for (byte i=0;i<=11;i++) {
datawajah[20][i]=0; }
for (byte i=12;i<=14;i++) {
datawajah[20][i]=1; }
for (byte i=15;i<=17;i++) {
datawajah[20][i]=0; }
for (byte i=18;i<=19;i++) {
datawajah[20][i]=1; }
for (byte i=20;i<=26;i++) {
datawajah[20][i]=0; }
for (byte i=27;i<=30;i++) {
datawajah[20][i]=1; }
for (byte i=31;i<=37;i++) {
datawajah[20][i]=0; }
for (byte i=38;i<=69;i++) {
datawajah[20][i]=1; }
for (byte i=70;i<=70;i++) {
datawajah[20][i]=0; }
for (byte i=71;i<=73;i++) {
datawajah[20][i]=1; }
for (byte i=74;i<=78;i++) {
datawajah[20][i]=0; }
for (byte i=79;i<=94;i++) {
datawajah[20][i]=1; }
for (byte i=95;i<=110;i++) {
datawajah[20][i]=0; }
for (byte i=111;i<=114;i++) {
datawajah[20][i]=1; }

//Baris22
for (byte i=0;i<=7;i++) {
datawajah[21][i]=0; }
for (byte i=8;i<=18;i++) {
datawajah[21][i]=1; }
for (byte i=19;i<=24;i++) {
datawajah[21][i]=0; }
for (byte i=25;i<=33;i++) {
datawajah[21][i]=1; }
for (byte i=34;i<=35;i++) {
datawajah[21][i]=0; }
for (byte i=36;i<=74;i++) {
datawajah[21][i]=1; }
for (byte i=75;i<=79;i++) {
datawajah[21][i]=0; }
for (byte i=80;i<=103;i++) {
datawajah[21][i]=1; }
for (byte i=104;i<=107;i++) {
datawajah[21][i]=0; }
for (byte i=108;i<=114;i++) {
datawajah[21][i]=1; }

//Baris23
for (byte i=0;i<=7;i++) {
datawajah[22][i]=0; }
for (byte i=8;i<=17;i++) {
datawajah[22][i]=1; }
for (byte i=18;i<=21;i++) {
datawajah[22][i]=0; }
for (byte i=22;i<=33;i++) {
datawajah[22][i]=1; }
for (byte i=34;i<=35;i++) {
datawajah[22][i]=0; }
for (byte i=36;i<=74;i++) {
datawajah[22][i]=1; }
for (byte i=75;i<=79;i++) {
datawajah[22][i]=0; }
for (byte i=80;i<=103;i++) {
datawajah[22][i]=1; }
for (byte i=104;i<=107;i++) {
datawajah[22][i]=0; }
for (byte i=108;i<=114;i++) {
datawajah[22][i]=1; }

//Baris24
for (byte i=0;i<=4;i++) {
datawajah[23][i]=0; }
for (byte i=5;i<=17;i++) {
datawajah[23][i]=1; }
for (byte i=18;i<=20;i++) {
datawajah[23][i]=0; }
for (byte i=21;i<=77;i++) {
datawajah[23][i]=1; }
for (byte i=78;i<=80;i++) {
datawajah[23][i]=0; }
for (byte i=81;i<=105;i++) {
datawajah[23][i]=1; }
for (byte i=106;i<=107;i++) {
datawajah[23][i]=0; }
for (byte i=108;i<=114;i++) {
datawajah[23][i]=1; }

//Baris25
for (byte i=0;i<=78;i++) {
datawajah[24][i]=1; }
for (byte i=79;i<=80;i++) {
datawajah[24][i]=0; }
for (byte i=81;i<=105;i++) {
datawajah[24][i]=1; }
for (byte i=106;i<=107;i++) {
datawajah[24][i]=0; }
for (byte i=108;i<=114;i++) {
datawajah[24][i]=1; }

//Baris26
for (byte i=0;i<=101;i++) {
datawajah[25][i]=1; }
for (byte i=102;i<=107;i++) {
datawajah[25][i]=0; }
for (byte i=108;i<=114;i++) {
datawajah[25][i]=1; }


}

dataset:: wajahkiri4()
{
  baris = 22;
  kolom = 98;
//Baris1
for (byte i=0;i<=14;i++) {
datawajah[0][i]=1; }
for (byte i=15;i<=21;i++) {
datawajah[0][i]=0; }
for (byte i=22;i<=23;i++) {
datawajah[0][i]=1; }
for (byte i=24;i<=38;i++) {
datawajah[0][i]=0; }
for (byte i=39;i<=55;i++) {
datawajah[0][i]=1; }
for (byte i=56;i<=72;i++) {
datawajah[0][i]=0; }
for (byte i=73;i<=95;i++) {
datawajah[0][i]=1; }
for (byte i=96;i<=97;i++) {
datawajah[0][i]=0; }

//Baris2
for (byte i=0;i<=7;i++) {
datawajah[1][i]=1; }
for (byte i=8;i<=37;i++) {
datawajah[1][i]=0; }
for (byte i=38;i<=56;i++) {
datawajah[1][i]=1; }
for (byte i=57;i<=72;i++) {
datawajah[1][i]=0; }
for (byte i=73;i<=78;i++) {
datawajah[1][i]=1; }
for (byte i=79;i<=89;i++) {
datawajah[1][i]=0; }
for (byte i=90;i<=92;i++) {
datawajah[1][i]=1; }
for (byte i=93;i<=97;i++) {
datawajah[1][i]=0; }


//Baris3
for (byte i=0;i<=37;i++) {
datawajah[2][i]=0; }
for (byte i=38;i<=57;i++) {
datawajah[2][i]=1; }
for (byte i=58;i<=71;i++) {
datawajah[2][i]=0; }
for (byte i=72;i<=74;i++) {
datawajah[2][i]=1; }
for (byte i=75;i<=97;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=10;i++) {
datawajah[3][i]=0; }
for (byte i=11;i<=13;i++) {
datawajah[3][i]=1; }
for (byte i=14;i<=38;i++) {
datawajah[3][i]=0; }
for (byte i=39;i<=58;i++) {
datawajah[3][i]=1; }
for (byte i=59;i<=71;i++) {
datawajah[3][i]=0; }
for (byte i=72;i<=73;i++) {
datawajah[3][i]=1; }
for (byte i=74;i<=97;i++) {
datawajah[3][i]=0; }

//Baris5
for (byte i=0;i<=8;i++) {
datawajah[4][i]=0; }
for (byte i=9;i<=12;i++) {
datawajah[4][i]=1; }
for (byte i=13;i<=38;i++) {
datawajah[4][i]=0; }
for (byte i=39;i<=59;i++) {
datawajah[4][i]=1; }
for (byte i=60;i<=97;i++) {
datawajah[4][i]=0; }

//Baris6
for (byte i=0;i<=38;i++) {
datawajah[5][i]=0; }
for (byte i=39;i<=59;i++) {
datawajah[5][i]=1; }
for (byte i=60;i<=97;i++) {
datawajah[5][i]=0; }


//Baris7
for (byte i=0;i<=37;i++) {
datawajah[6][i]=0; }
for (byte i=38;i<=60;i++) {
datawajah[6][i]=1; }
for (byte i=61;i<=67;i++) {
datawajah[6][i]=0; }
for (byte i=68;i<=69;i++) {
datawajah[6][i]=1; }
for (byte i=70;i<=97;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=37;i++) {
datawajah[7][i]=0; }
for (byte i=38;i<=60;i++) {
datawajah[7][i]=1; }
for (byte i=61;i<=66;i++) {
datawajah[7][i]=0; }
for (byte i=67;i<=69;i++) {
datawajah[7][i]=1; }
for (byte i=70;i<=97;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=38;i++) {
datawajah[8][i]=0; }
for (byte i=39;i<=60;i++) {
datawajah[8][i]=1; }
for (byte i=61;i<=66;i++) {
datawajah[8][i]=0; }
for (byte i=67;i<=68;i++) {
datawajah[8][i]=1; }
for (byte i=69;i<=73;i++) {
datawajah[8][i]=0; }
for (byte i=74;i<=76;i++) {
datawajah[8][i]=1; }
for (byte i=77;i<=97;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=20;i++) {
datawajah[9][i]=0; }
for (byte i=21;i<=22;i++) {
datawajah[9][i]=1; }
for (byte i=23;i<=39;i++) {
datawajah[9][i]=0; }
for (byte i=40;i<=61;i++) {
datawajah[9][i]=1; }
for (byte i=62;i<=66;i++) {
datawajah[9][i]=0; }
for (byte i=67;i<=67;i++) {
datawajah[9][i]=1; }
for (byte i=68;i<=73;i++) {
datawajah[9][i]=0; }
for (byte i=74;i<=76;i++) {
datawajah[9][i]=1; }
for (byte i=77;i<=97;i++) {
datawajah[9][i]=0; }

//Baris11
for (byte i=0;i<=19;i++) {
datawajah[10][i]=0; }
for (byte i=20;i<=22;i++) {
datawajah[10][i]=1; }
for (byte i=23;i<=39;i++) {
datawajah[10][i]=0; }
for (byte i=40;i<=61;i++) {
datawajah[10][i]=1; }
for (byte i=62;i<=74;i++) {
datawajah[10][i]=0; }
for (byte i=75;i<=76;i++) {
datawajah[10][i]=1; }
for (byte i=77;i<=97;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=19;i++) {
datawajah[11][i]=0; }
for (byte i=20;i<=21;i++) {
datawajah[11][i]=1; }
for (byte i=22;i<=38;i++) {
datawajah[11][i]=0; }
for (byte i=39;i<=61;i++) {
datawajah[11][i]=1; }
for (byte i=62;i<=97;i++) {
datawajah[11][i]=0; }

//Baris13
for (byte i=0;i<=38;i++) {
datawajah[12][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[12][i]=1; }
for (byte i=63;i<=97;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=38;i++) {
datawajah[13][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[13][i]=1; }
for (byte i=63;i<=97;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=38;i++) {
datawajah[14][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[14][i]=1; }
for (byte i=63;i<=97;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=37;i++) {
datawajah[15][i]=0; }
for (byte i=38;i<=63;i++) {
datawajah[15][i]=1; }
for (byte i=64;i<=97;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=0;i<=3;i++) {
datawajah[16][i]=0; }
for (byte i=4;i<=11;i++) {
datawajah[16][i]=1; }
for (byte i=12;i<=36;i++) {
datawajah[16][i]=0; }
for (byte i=37;i<=63;i++) {
datawajah[16][i]=1; }
for (byte i=64;i<=97;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=2;i++) {
datawajah[17][i]=0; }
for (byte i=3;i<=11;i++) {
datawajah[17][i]=1; }
for (byte i=12;i<=35;i++) {
datawajah[17][i]=0; }
for (byte i=36;i<=63;i++) {
datawajah[17][i]=1; }
for (byte i=64;i<=97;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=1;i++) {
datawajah[18][i]=0; }
for (byte i=2;i<=3;i++) {
datawajah[18][i]=1; }
for (byte i=4;i<=4;i++) {
datawajah[18][i]=0; }
for (byte i=5;i<=5;i++) {
datawajah[18][i]=1; }
for (byte i=6;i<=6;i++) {
datawajah[18][i]=0; }
for (byte i=7;i<=12;i++) {
datawajah[18][i]=1; }
for (byte i=13;i<=21;i++) {
datawajah[18][i]=0; }
for (byte i=22;i<=24;i++) {
datawajah[18][i]=1; }
for (byte i=25;i<=32;i++) {
datawajah[18][i]=0; }
for (byte i=33;i<=63;i++) {
datawajah[18][i]=1; }
for (byte i=64;i<=76;i++) {
datawajah[18][i]=0; }
for (byte i=77;i<=79;i++) {
datawajah[18][i]=1; }
for (byte i=80;i<=97;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=3;i++) {
datawajah[19][i]=1; }
for (byte i=4;i<=6;i++) {
datawajah[19][i]=0; }
for (byte i=7;i<=9;i++) {
datawajah[19][i]=1; }
for (byte i=10;i<=10;i++) {
datawajah[19][i]=0; }
for (byte i=11;i<=14;i++) {
datawajah[19][i]=1; }
for (byte i=15;i<=16;i++) {
datawajah[19][i]=0; }
for (byte i=17;i<=25;i++) {
datawajah[19][i]=1; }
for (byte i=26;i<=32;i++) {
datawajah[19][i]=0; }
for (byte i=33;i<=63;i++) {
datawajah[19][i]=1; }
for (byte i=64;i<=75;i++) {
datawajah[19][i]=0; }
for (byte i=76;i<=79;i++) {
datawajah[19][i]=1; }
for (byte i=80;i<=97;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=25;i++) {
datawajah[20][i]=1; }
for (byte i=26;i<=31;i++) {
datawajah[20][i]=0; }
for (byte i=32;i<=64;i++) {
datawajah[20][i]=1; }
for (byte i=65;i<=73;i++) {
datawajah[20][i]=0; }
for (byte i=74;i<=79;i++) {
datawajah[20][i]=1; }
for (byte i=80;i<=97;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=25;i++) {
datawajah[21][i]=1; }
for (byte i=26;i<=30;i++) {
datawajah[21][i]=0; }
for (byte i=31;i<=64;i++) {
datawajah[21][i]=1; }
for (byte i=65;i<=73;i++) {
datawajah[21][i]=0; }
for (byte i=74;i<=87;i++) {
datawajah[21][i]=1; }
for (byte i=88;i<=97;i++) {
datawajah[21][i]=0; }

}

dataset:: wajahkiri5()
{
  baris = 23;
  kolom = 101;
//Baris1
for (byte i=0;i<=25;i++) {
datawajah[0][i]=1; }
for (byte i=26;i<=37;i++) {
datawajah[0][i]=0; }
for (byte i=38;i<=56;i++) {
datawajah[0][i]=1; }
for (byte i=57;i<=74;i++) {
datawajah[0][i]=0; }
for (byte i=75;i<=97;i++) {
datawajah[0][i]=1; }
for (byte i=98;i<=99;i++) {
datawajah[0][i]=0; }
for (byte i=100;i<=100;i++) {
datawajah[0][i]=1; }

//Baris2
for (byte i=0;i<=10;i++) {
datawajah[1][i]=1; }
for (byte i=11;i<=22;i++) {
datawajah[1][i]=0; }
for (byte i=23;i<=25;i++) {
datawajah[1][i]=1; }
for (byte i=26;i<=37;i++) {
datawajah[1][i]=0; }
for (byte i=38;i<=57;i++) {
datawajah[1][i]=1; }
for (byte i=58;i<=73;i++) {
datawajah[1][i]=0; }
for (byte i=74;i<=96;i++) {
datawajah[1][i]=1; }
for (byte i=97;i<=99;i++) {
datawajah[1][i]=0; }
for (byte i=100;i<=100;i++) {
datawajah[1][i]=1; }

//Baris3
for (byte i=0;i<=4;i++) {
datawajah[2][i]=1; }
for (byte i=5;i<=37;i++) {
datawajah[2][i]=0; }
for (byte i=38;i<=57;i++) {
datawajah[2][i]=1; }
for (byte i=58;i<=71;i++) {
datawajah[2][i]=0; }
for (byte i=72;i<=78;i++) {
datawajah[2][i]=1; }
for (byte i=79;i<=100;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=1;i++) {
datawajah[3][i]=1; }
for (byte i=2;i<=9;i++) {
datawajah[3][i]=0; }
for (byte i=10;i<=11;i++) {
datawajah[3][i]=1; }
for (byte i=12;i<=38;i++) {
datawajah[3][i]=0; }
for (byte i=39;i<=57;i++) {
datawajah[3][i]=1; }
for (byte i=58;i<=71;i++) {
datawajah[3][i]=0; }
for (byte i=72;i<=75;i++) {
datawajah[3][i]=1; }
for (byte i=76;i<=100;i++) {
datawajah[3][i]=0; }

//Baris5
for (byte i=0;i<=7;i++) {
datawajah[4][i]=0; }
for (byte i=8;i<=14;i++) {
datawajah[4][i]=1; }
for (byte i=15;i<=38;i++) {
datawajah[4][i]=0; }
for (byte i=39;i<=58;i++) {
datawajah[4][i]=1; }
for (byte i=59;i<=69;i++) {
datawajah[4][i]=0; }
for (byte i=70;i<=74;i++) {
datawajah[4][i]=1; }
for (byte i=75;i<=100;i++) {
datawajah[4][i]=0; }

//Baris6
for (byte i=0;i<=38;i++) {
datawajah[5][i]=0; }
for (byte i=39;i<=60;i++) {
datawajah[5][i]=1; }
for (byte i=61;i<=70;i++) {
datawajah[5][i]=0; }
for (byte i=71;i<=71;i++) {
datawajah[5][i]=1; }
for (byte i=72;i<=100;i++) {
datawajah[5][i]=0; }

//Baris7
for (byte i=0;i<=37;i++) {
datawajah[6][i]=0; }
for (byte i=38;i<=60;i++) {
datawajah[6][i]=1; }
for (byte i=61;i<=68;i++) {
datawajah[6][i]=0; }
for (byte i=69;i<=71;i++) {
datawajah[6][i]=1; }
for (byte i=72;i<=100;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=37;i++) {
datawajah[7][i]=0; }
for (byte i=38;i<=60;i++) {
datawajah[7][i]=1; }
for (byte i=61;i<=67;i++) {
datawajah[7][i]=0; }
for (byte i=68;i<=70;i++) {
datawajah[7][i]=1; }
for (byte i=71;i<=100;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=11;i++) {
datawajah[8][i]=0; }
for (byte i=12;i<=12;i++) {
datawajah[8][i]=1; }
for (byte i=13;i<=37;i++) {
datawajah[8][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[8][i]=1; }
for (byte i=62;i<=67;i++) {
datawajah[8][i]=0; }
for (byte i=68;i<=69;i++) {
datawajah[8][i]=1; }
for (byte i=70;i<=74;i++) {
datawajah[8][i]=0; }
for (byte i=75;i<=77;i++) {
datawajah[8][i]=1; }
for (byte i=78;i<=100;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=20;i++) {
datawajah[9][i]=0; }
for (byte i=21;i<=22;i++) {
datawajah[9][i]=1; }
for (byte i=23;i<=37;i++) {
datawajah[9][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[9][i]=1; }
for (byte i=62;i<=66;i++) {
datawajah[9][i]=0; }
for (byte i=67;i<=69;i++) {
datawajah[9][i]=1; }
for (byte i=70;i<=74;i++) {
datawajah[9][i]=0; }
for (byte i=75;i<=77;i++) {
datawajah[9][i]=1; }
for (byte i=78;i<=100;i++) {
datawajah[9][i]=0; }

//Baris11
for (byte i=0;i<=19;i++) {
datawajah[10][i]=0; }
for (byte i=20;i<=23;i++) {
datawajah[10][i]=1; }
for (byte i=24;i<=39;i++) {
datawajah[10][i]=0; }
for (byte i=40;i<=61;i++) {
datawajah[10][i]=1; }
for (byte i=62;i<=66;i++) {
datawajah[10][i]=0; }
for (byte i=67;i<=68;i++) {
datawajah[10][i]=1; }
for (byte i=69;i<=74;i++) {
datawajah[10][i]=0; }
for (byte i=75;i<=77;i++) {
datawajah[10][i]=1; }
for (byte i=78;i<=100;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=4;i++) {
datawajah[11][i]=0; }
for (byte i=5;i<=6;i++) {
datawajah[11][i]=1; }
for (byte i=7;i<=19;i++) {
datawajah[11][i]=0; }
for (byte i=20;i<=23;i++) {
datawajah[11][i]=1; }
for (byte i=24;i<=39;i++) {
datawajah[11][i]=0; }
for (byte i=40;i<=62;i++) {
datawajah[11][i]=1; }
for (byte i=63;i<=75;i++) {
datawajah[11][i]=0; }
for (byte i=76;i<=77;i++) {
datawajah[11][i]=1; }
for (byte i=78;i<=100;i++) {
datawajah[11][i]=0; }

//Baris13
for (byte i=0;i<=5;i++) {
datawajah[12][i]=0; }
for (byte i=6;i<=7;i++) {
datawajah[12][i]=1; }
for (byte i=8;i<=19;i++) {
datawajah[12][i]=0; }
for (byte i=20;i<=21;i++) {
datawajah[12][i]=1; }
for (byte i=22;i<=38;i++) {
datawajah[12][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[12][i]=1; }
for (byte i=63;i<=100;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=6;i++) {
datawajah[13][i]=0; }
for (byte i=7;i<=7;i++) {
datawajah[13][i]=1; }
for (byte i=8;i<=38;i++) {
datawajah[13][i]=0; }
for (byte i=39;i<=63;i++) {
datawajah[13][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=38;i++) {
datawajah[14][i]=0; }
for (byte i=39;i<=63;i++) {
datawajah[14][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=10;i++) {
datawajah[15][i]=0; }
for (byte i=11;i<=11;i++) {
datawajah[15][i]=1; }
for (byte i=12;i<=38;i++) {
datawajah[15][i]=0; }
for (byte i=39;i<=63;i++) {
datawajah[15][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[15][i]=0; }

//Baris17
for (byte i=0;i<=5;i++) {
datawajah[16][i]=0; }
for (byte i=6;i<=10;i++) {
datawajah[16][i]=1; }
for (byte i=11;i<=37;i++) {
datawajah[16][i]=0; }
for (byte i=38;i<=63;i++) {
datawajah[16][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=1;i++) {
datawajah[17][i]=0; }
for (byte i=2;i<=11;i++) {
datawajah[17][i]=1; }
for (byte i=12;i<=14;i++) {
datawajah[17][i]=0; }
for (byte i=15;i<=16;i++) {
datawajah[17][i]=1; }
for (byte i=17;i<=35;i++) {
datawajah[17][i]=0; }
for (byte i=36;i<=64;i++) {
datawajah[17][i]=1; }
for (byte i=65;i<=100;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=11;i++) {
datawajah[18][i]=1; }
for (byte i=12;i<=14;i++) {
datawajah[18][i]=0; }
for (byte i=15;i<=16;i++) {
datawajah[18][i]=1; }
for (byte i=17;i<=34;i++) {
datawajah[18][i]=0; }
for (byte i=35;i<=64;i++) {
datawajah[18][i]=1; }
for (byte i=65;i<=74;i++) {
datawajah[18][i]=0; }
for (byte i=75;i<=77;i++) {
datawajah[18][i]=1; }
for (byte i=78;i<=100;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=17;i++) {
datawajah[19][i]=1; }
for (byte i=18;i<=19;i++) {
datawajah[19][i]=0; }
for (byte i=20;i<=23;i++) {
datawajah[19][i]=1; }
for (byte i=24;i<=32;i++) {
datawajah[19][i]=0; }
for (byte i=33;i<=64;i++) {
datawajah[19][i]=1; }
for (byte i=65;i<=72;i++) {
datawajah[19][i]=0; }
for (byte i=73;i<=79;i++) {
datawajah[19][i]=1; }
for (byte i=80;i<=100;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=2;i++) {
datawajah[20][i]=1; }
for (byte i=3;i<=4;i++) {
datawajah[20][i]=0; }
for (byte i=5;i<=25;i++) {
datawajah[20][i]=1; }
for (byte i=26;i<=31;i++) {
datawajah[20][i]=0; }
for (byte i=32;i<=64;i++) {
datawajah[20][i]=1; }
for (byte i=65;i<=73;i++) {
datawajah[20][i]=0; }
for (byte i=74;i<=82;i++) {
datawajah[20][i]=1; }
for (byte i=83;i<=100;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=26;i++) {
datawajah[21][i]=1; }
for (byte i=27;i<=30;i++) {
datawajah[21][i]=0; }
for (byte i=31;i<=65;i++) {
datawajah[21][i]=1; }
for (byte i=66;i<=73;i++) {
datawajah[21][i]=0; }
for (byte i=74;i<=85;i++) {
datawajah[21][i]=1; }
for (byte i=86;i<=100;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=26;i++) {
datawajah[22][i]=1; }
for (byte i=27;i<=29;i++) {
datawajah[22][i]=0; }
for (byte i=30;i<=66;i++) {
datawajah[22][i]=1; }
for (byte i=67;i<=73;i++) {
datawajah[22][i]=0; }
for (byte i=74;i<=89;i++) {
datawajah[22][i]=1; }
for (byte i=90;i<=100;i++) {
datawajah[22][i]=0; }


}

dataset:: wajahkiri6()
{
  baris = 23;
  kolom = 101;
//Baris1
for (byte i=0;i<=25;i++) {
datawajah[0][i]=1; }
for (byte i=26;i<=36;i++) {
datawajah[0][i]=0; }
for (byte i=37;i<=56;i++) {
datawajah[0][i]=1; }
for (byte i=57;i<=75;i++) {
datawajah[0][i]=0; }
for (byte i=76;i<=98;i++) {
datawajah[0][i]=1; }
for (byte i=99;i<=99;i++) {
datawajah[0][i]=0; }
for (byte i=100;i<=100;i++) {
datawajah[0][i]=1; }


//Baris2
for (byte i=0;i<=14;i++) {
datawajah[1][i]=1; }
for (byte i=15;i<=16;i++) {
datawajah[1][i]=0; }
for (byte i=17;i<=25;i++) {
datawajah[1][i]=1; }
for (byte i=26;i<=37;i++) {
datawajah[1][i]=0; }
for (byte i=38;i<=57;i++) {
datawajah[1][i]=1; }
for (byte i=58;i<=74;i++) {
datawajah[1][i]=0; }
for (byte i=75;i<=95;i++) {
datawajah[1][i]=1; }
for (byte i=96;i<=96;i++) {
datawajah[1][i]=0; }
for (byte i=97;i<=97;i++) {
datawajah[1][i]=1; }
for (byte i=98;i<=100;i++) {
datawajah[1][i]=0; }

//Baris3
for (byte i=0;i<=6;i++) {
datawajah[2][i]=1; }
for (byte i=7;i<=37;i++) {
datawajah[2][i]=0; }
for (byte i=38;i<=57;i++) {
datawajah[2][i]=1; }
for (byte i=58;i<=72;i++) {
datawajah[2][i]=0; }
for (byte i=73;i<=82;i++) {
datawajah[2][i]=1; }
for (byte i=83;i<=100;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=3;i++) {
datawajah[3][i]=1; }
for (byte i=4;i<=38;i++) {
datawajah[3][i]=0; }
for (byte i=39;i<=57;i++) {
datawajah[3][i]=1; }
for (byte i=58;i<=72;i++) {
datawajah[3][i]=0; }
for (byte i=73;i<=79;i++) {
datawajah[3][i]=1; }
for (byte i=80;i<=100;i++) {
datawajah[3][i]=0; }

//Baris5
for (byte i=0;i<=7;i++) {
datawajah[4][i]=0; }
for (byte i=8;i<=14;i++) {
datawajah[4][i]=1; }
for (byte i=15;i<=38;i++) {
datawajah[4][i]=0; }
for (byte i=39;i<=58;i++) {
datawajah[4][i]=1; }
for (byte i=59;i<=71;i++) {
datawajah[4][i]=0; }
for (byte i=72;i<=75;i++) {
datawajah[4][i]=1; }
for (byte i=76;i<=100;i++) {
datawajah[4][i]=0; }

//Baris6
for (byte i=0;i<=7;i++) {
datawajah[5][i]=0; }
for (byte i=8;i<=9;i++) {
datawajah[5][i]=1; }
for (byte i=10;i<=10;i++) {
datawajah[5][i]=0; }
for (byte i=11;i<=13;i++) {
datawajah[5][i]=1; }
for (byte i=14;i<=38;i++) {
datawajah[5][i]=0; }
for (byte i=39;i<=60;i++) {
datawajah[5][i]=1; }
for (byte i=61;i<=100;i++) {
datawajah[5][i]=0; }

//Baris7
for (byte i=0;i<=38;i++) {
datawajah[6][i]=0; }
for (byte i=39;i<=60;i++) {
datawajah[6][i]=1; }
for (byte i=61;i<=70;i++) {
datawajah[6][i]=0; }
for (byte i=71;i<=71;i++) {
datawajah[6][i]=1; }
for (byte i=72;i<=100;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=37;i++) {
datawajah[7][i]=0; }
for (byte i=38;i<=60;i++) {
datawajah[7][i]=1; }
for (byte i=61;i<=68;i++) {
datawajah[7][i]=0; }
for (byte i=69;i<=70;i++) {
datawajah[7][i]=1; }
for (byte i=71;i<=100;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=37;i++) {
datawajah[8][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[8][i]=1; }
for (byte i=62;i<=67;i++) {
datawajah[8][i]=0; }
for (byte i=68;i<=70;i++) {
datawajah[8][i]=1; }
for (byte i=71;i<=76;i++) {
datawajah[8][i]=0; }
for (byte i=77;i<=77;i++) {
datawajah[8][i]=1; }
for (byte i=78;i<=82;i++) {
datawajah[8][i]=0; }
for (byte i=83;i<=83;i++) {
datawajah[8][i]=1; }
for (byte i=84;i<=100;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=37;i++) {
datawajah[9][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[9][i]=1; }
for (byte i=62;i<=67;i++) {
datawajah[9][i]=0; }
for (byte i=68;i<=70;i++) {
datawajah[9][i]=1; }
for (byte i=71;i<=75;i++) {
datawajah[9][i]=0; }
for (byte i=76;i<=78;i++) {
datawajah[9][i]=1; }
for (byte i=79;i<=82;i++) {
datawajah[9][i]=0; }
for (byte i=83;i<=83;i++) {
datawajah[9][i]=1; }
for (byte i=84;i<=100;i++) {
datawajah[9][i]=0; }

//Baris11
for (byte i=0;i<=20;i++) {
datawajah[10][i]=0; }
for (byte i=21;i<=22;i++) {
datawajah[10][i]=1; }
for (byte i=23;i<=38;i++) {
datawajah[10][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[10][i]=1; }
for (byte i=63;i<=67;i++) {
datawajah[10][i]=0; }
for (byte i=68;i<=69;i++) {
datawajah[10][i]=1; }
for (byte i=70;i<=74;i++) {
datawajah[10][i]=0; }
for (byte i=75;i<=78;i++) {
datawajah[10][i]=1; }
for (byte i=79;i<=100;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=5;i++) {
datawajah[11][i]=0; }
for (byte i=6;i<=6;i++) {
datawajah[11][i]=1; }
for (byte i=7;i<=20;i++) {
datawajah[11][i]=0; }
for (byte i=21;i<=22;i++) {
datawajah[11][i]=1; }
for (byte i=23;i<=38;i++) {
datawajah[11][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[11][i]=1; }
for (byte i=63;i<=67;i++) {
datawajah[11][i]=0; }
for (byte i=68;i<=69;i++) {
datawajah[11][i]=1; }
for (byte i=70;i<=76;i++) {
datawajah[11][i]=0; }
for (byte i=77;i<=78;i++) {
datawajah[11][i]=1; }
for (byte i=79;i<=100;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=4;i++) {
datawajah[12][i]=0; }
for (byte i=5;i<=7;i++) {
datawajah[12][i]=1; }
for (byte i=8;i<=20;i++) {
datawajah[12][i]=0; }
for (byte i=21;i<=21;i++) {
datawajah[12][i]=1; }
for (byte i=22;i<=38;i++) {
datawajah[12][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[12][i]=1; }
for (byte i=63;i<=100;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=6;i++) {
datawajah[13][i]=0; }
for (byte i=7;i<=8;i++) {
datawajah[13][i]=1; }
for (byte i=9;i<=38;i++) {
datawajah[13][i]=0; }
for (byte i=39;i<=63;i++) {
datawajah[13][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=7;i++) {
datawajah[14][i]=0; }
for (byte i=8;i<=8;i++) {
datawajah[14][i]=1; }
for (byte i=9;i<=38;i++) {
datawajah[14][i]=0; }
for (byte i=39;i<=63;i++) {
datawajah[14][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=38;i++) {
datawajah[15][i]=0; }
for (byte i=39;i<=63;i++) {
datawajah[15][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[15][i]=0; }

//Baris17
for (byte i=0;i<=11;i++) {
datawajah[16][i]=0; }
for (byte i=12;i<=12;i++) {
datawajah[16][i]=1; }
for (byte i=13;i<=38;i++) {
datawajah[16][i]=0; }
for (byte i=39;i<=64;i++) {
datawajah[16][i]=1; }
for (byte i=65;i<=100;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=1;i++) {
datawajah[17][i]=1; }
for (byte i=2;i<=3;i++) {
datawajah[17][i]=0; }
for (byte i=4;i<=12;i++) {
datawajah[17][i]=1; }
for (byte i=13;i<=37;i++) {
datawajah[17][i]=0; }
for (byte i=38;i<=64;i++) {
datawajah[17][i]=1; }
for (byte i=65;i<=100;i++) {
datawajah[17][i]=0; }


//Baris19
for (byte i=0;i<=0;i++) {
datawajah[18][i]=0; }
for (byte i=1;i<=1;i++) {
datawajah[18][i]=1; }
for (byte i=2;i<=4;i++) {
datawajah[18][i]=0; }
for (byte i=5;i<=13;i++) {
datawajah[18][i]=1; }
for (byte i=14;i<=35;i++) {
datawajah[18][i]=0; }
for (byte i=36;i<=64;i++) {
datawajah[18][i]=1; }
for (byte i=65;i<=73;i++) {
datawajah[18][i]=0; }
for (byte i=74;i<=75;i++) {
datawajah[18][i]=1; }
for (byte i=76;i<=100;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=14;i++) {
datawajah[19][i]=1; }
for (byte i=15;i<=15;i++) {
datawajah[19][i]=0; }
for (byte i=16;i<=17;i++) {
datawajah[19][i]=1; }
for (byte i=18;i<=33;i++) {
datawajah[19][i]=0; }
for (byte i=34;i<=65;i++) {
datawajah[19][i]=1; }
for (byte i=66;i<=73;i++) {
datawajah[19][i]=0; }
for (byte i=74;i<=80;i++) {
datawajah[19][i]=1; }
for (byte i=81;i<=100;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=26;i++) {
datawajah[20][i]=1; }
for (byte i=27;i<=32;i++) {
datawajah[20][i]=0; }
for (byte i=33;i<=65;i++) {
datawajah[20][i]=1; }
for (byte i=66;i<=73;i++) {
datawajah[20][i]=0; }
for (byte i=74;i<=81;i++) {
datawajah[20][i]=1; }
for (byte i=82;i<=100;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=26;i++) {
datawajah[21][i]=1; }
for (byte i=27;i<=30;i++) {
datawajah[21][i]=0; }
for (byte i=31;i<=66;i++) {
datawajah[21][i]=1; }
for (byte i=67;i<=73;i++) {
datawajah[21][i]=0; }
for (byte i=74;i<=83;i++) {
datawajah[21][i]=1; }
for (byte i=84;i<=100;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=28;i++) {
datawajah[22][i]=1; }
for (byte i=29;i<=30;i++) {
datawajah[22][i]=0; }
for (byte i=31;i<=67;i++) {
datawajah[22][i]=1; }
for (byte i=68;i<=74;i++) {
datawajah[22][i]=0; }
for (byte i=75;i<=88;i++) {
datawajah[22][i]=1; }
for (byte i=89;i<=100;i++) {
datawajah[22][i]=0; }


}

dataset:: wajahkiri7()
{
  baris = 23;
  kolom = 103;
//Baris1
for (byte i=0;i<=25;i++) {
datawajah[0][i]=1; }
for (byte i=26;i<=36;i++) {
datawajah[0][i]=0; }
for (byte i=37;i<=57;i++) {
datawajah[0][i]=1; }
for (byte i=58;i<=76;i++) {
datawajah[0][i]=0; }
for (byte i=77;i<=100;i++) {
datawajah[0][i]=1; }
for (byte i=101;i<=102;i++) {
datawajah[0][i]=0; }

//Baris2
for (byte i=0;i<=25;i++) {
datawajah[1][i]=1; }
for (byte i=26;i<=37;i++) {
datawajah[1][i]=0; }
for (byte i=38;i<=57;i++) {
datawajah[1][i]=1; }
for (byte i=58;i<=74;i++) {
datawajah[1][i]=0; }
for (byte i=75;i<=98;i++) {
datawajah[1][i]=1; }
for (byte i=99;i<=100;i++) {
datawajah[1][i]=0; }
for (byte i=101;i<=101;i++) {
datawajah[1][i]=1; }
for (byte i=102;i<=102;i++) {
datawajah[1][i]=0; }

//Baris3
for (byte i=0;i<=9;i++) {
datawajah[2][i]=1; }
for (byte i=10;i<=38;i++) {
datawajah[2][i]=0; }
for (byte i=39;i<=57;i++) {
datawajah[2][i]=1; }
for (byte i=58;i<=73;i++) {
datawajah[2][i]=0; }
for (byte i=74;i<=83;i++) {
datawajah[2][i]=1; }
for (byte i=84;i<=92;i++) {
datawajah[2][i]=0; }
for (byte i=93;i<=94;i++) {
datawajah[2][i]=1; }
for (byte i=95;i<=102;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=4;i++) {
datawajah[3][i]=1; }
for (byte i=5;i<=38;i++) {
datawajah[3][i]=0; }
for (byte i=39;i<=57;i++) {
datawajah[3][i]=1; }
for (byte i=58;i<=73;i++) {
datawajah[3][i]=0; }
for (byte i=74;i<=78;i++) {
datawajah[3][i]=1; }
for (byte i=79;i<=102;i++) {
datawajah[3][i]=0; }

//Baris5
for (byte i=0;i<=0;i++) {
datawajah[4][i]=1; }
for (byte i=1;i<=9;i++) {
datawajah[4][i]=0; }
for (byte i=10;i<=15;i++) {
datawajah[4][i]=1; }
for (byte i=16;i<=38;i++) {
datawajah[4][i]=0; }
for (byte i=39;i<=59;i++) {
datawajah[4][i]=1; }
for (byte i=60;i<=71;i++) {
datawajah[4][i]=0; }
for (byte i=72;i<=75;i++) {
datawajah[4][i]=1; }
for (byte i=76;i<=102;i++) {
datawajah[4][i]=0; }

//Baris6
for (byte i=0;i<=9;i++) {
datawajah[5][i]=0; }
for (byte i=10;i<=15;i++) {
datawajah[5][i]=1; }
for (byte i=16;i<=38;i++) {
datawajah[5][i]=0; }
for (byte i=39;i<=60;i++) {
datawajah[5][i]=1; }
for (byte i=61;i<=71;i++) {
datawajah[5][i]=0; }
for (byte i=72;i<=73;i++) {
datawajah[5][i]=1; }
for (byte i=74;i<=102;i++) {
datawajah[5][i]=0; }

//Baris7
for (byte i=0;i<=38;i++) {
datawajah[6][i]=0; }
for (byte i=39;i<=60;i++) {
datawajah[6][i]=1; }
for (byte i=61;i<=102;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=38;i++) {
datawajah[7][i]=0; }
for (byte i=39;i<=61;i++) {
datawajah[7][i]=1; }
for (byte i=62;i<=70;i++) {
datawajah[7][i]=0; }
for (byte i=71;i<=71;i++) {
datawajah[7][i]=1; }
for (byte i=72;i<=102;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=37;i++) {
datawajah[8][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[8][i]=1; }
for (byte i=62;i<=67;i++) {
datawajah[8][i]=0; }
for (byte i=68;i<=70;i++) {
datawajah[8][i]=1; }
for (byte i=71;i<=76;i++) {
datawajah[8][i]=0; }
for (byte i=77;i<=77;i++) {
datawajah[8][i]=1; }
for (byte i=78;i<=102;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=38;i++) {
datawajah[9][i]=0; }
for (byte i=39;i<=61;i++) {
datawajah[9][i]=1; }
for (byte i=62;i<=67;i++) {
datawajah[9][i]=0; }
for (byte i=68;i<=70;i++) {
datawajah[9][i]=1; }
for (byte i=71;i<=75;i++) {
datawajah[9][i]=0; }
for (byte i=76;i<=78;i++) {
datawajah[9][i]=1; }
for (byte i=79;i<=102;i++) {
datawajah[9][i]=0; }

//Baris11
for (byte i=0;i<=20;i++) {
datawajah[10][i]=0; }
for (byte i=21;i<=24;i++) {
datawajah[10][i]=1; }
for (byte i=25;i<=38;i++) {
datawajah[10][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[10][i]=1; }
for (byte i=63;i<=67;i++) {
datawajah[10][i]=0; }
for (byte i=68;i<=69;i++) {
datawajah[10][i]=1; }
for (byte i=70;i<=75;i++) {
datawajah[10][i]=0; }
for (byte i=76;i<=78;i++) {
datawajah[10][i]=1; }
for (byte i=79;i<=102;i++) {
datawajah[10][i]=0; }


//Baris12
for (byte i=0;i<=5;i++) {
datawajah[11][i]=0; }
for (byte i=6;i<=6;i++) {
datawajah[11][i]=1; }
for (byte i=7;i<=20;i++) {
datawajah[11][i]=0; }
for (byte i=21;i<=24;i++) {
datawajah[11][i]=1; }
for (byte i=25;i<=38;i++) {
datawajah[11][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[11][i]=1; }
for (byte i=63;i<=67;i++) {
datawajah[11][i]=0; }
for (byte i=68;i<=69;i++) {
datawajah[11][i]=1; }
for (byte i=70;i<=75;i++) {
datawajah[11][i]=0; }
for (byte i=76;i<=78;i++) {
datawajah[11][i]=1; }
for (byte i=79;i<=102;i++) {
datawajah[11][i]=0; }

//Baris13
for (byte i=0;i<=5;i++) {
datawajah[12][i]=0; }
for (byte i=6;i<=7;i++) {
datawajah[12][i]=1; }
for (byte i=8;i<=20;i++) {
datawajah[12][i]=0; }
for (byte i=21;i<=22;i++) {
datawajah[12][i]=1; }
for (byte i=23;i<=38;i++) {
datawajah[12][i]=0; }
for (byte i=39;i<=63;i++) {
datawajah[12][i]=1; }
for (byte i=64;i<=102;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=6;i++) {
datawajah[13][i]=0; }
for (byte i=7;i<=8;i++) {
datawajah[13][i]=1; }
for (byte i=9;i<=20;i++) {
datawajah[13][i]=0; }
for (byte i=21;i<=21;i++) {
datawajah[13][i]=1; }
for (byte i=22;i<=39;i++) {
datawajah[13][i]=0; }
for (byte i=40;i<=63;i++) {
datawajah[13][i]=1; }
for (byte i=64;i<=102;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=39;i++) {
datawajah[14][i]=0; }
for (byte i=40;i<=63;i++) {
datawajah[14][i]=1; }
for (byte i=64;i<=102;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=38;i++) {
datawajah[15][i]=0; }
for (byte i=39;i<=64;i++) {
datawajah[15][i]=1; }
for (byte i=65;i<=102;i++) {
datawajah[15][i]=0; }

//Baris17
for (byte i=0;i<=0;i++) {
datawajah[16][i]=1; }
for (byte i=1;i<=6;i++) {
datawajah[16][i]=0; }
for (byte i=7;i<=10;i++) {
datawajah[16][i]=1; }
for (byte i=11;i<=38;i++) {
datawajah[16][i]=0; }
for (byte i=39;i<=64;i++) {
datawajah[16][i]=1; }
for (byte i=65;i<=102;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=1;i++) {
datawajah[17][i]=1; }
for (byte i=2;i<=3;i++) {
datawajah[17][i]=0; }
for (byte i=4;i<=13;i++) {
datawajah[17][i]=1; }
for (byte i=14;i<=36;i++) {
datawajah[17][i]=0; }
for (byte i=37;i<=64;i++) {
datawajah[17][i]=1; }
for (byte i=65;i<=102;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=0;i++) {
datawajah[18][i]=1; }
for (byte i=1;i<=3;i++) {
datawajah[18][i]=0; }
for (byte i=4;i<=17;i++) {
datawajah[18][i]=1; }
for (byte i=18;i<=35;i++) {
datawajah[18][i]=0; }
for (byte i=36;i<=65;i++) {
datawajah[18][i]=1; }
for (byte i=66;i<=73;i++) {
datawajah[18][i]=0; }
for (byte i=74;i<=76;i++) {
datawajah[18][i]=1; }
for (byte i=77;i<=102;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=16;i++) {
datawajah[19][i]=1; }
for (byte i=17;i<=20;i++) {
datawajah[19][i]=0; }
for (byte i=21;i<=21;i++) {
datawajah[19][i]=1; }
for (byte i=22;i<=32;i++) {
datawajah[19][i]=0; }
for (byte i=33;i<=65;i++) {
datawajah[19][i]=1; }
for (byte i=66;i<=73;i++) {
datawajah[19][i]=0; }
for (byte i=74;i<=78;i++) {
datawajah[19][i]=1; }
for (byte i=79;i<=79;i++) {
datawajah[19][i]=0; }
for (byte i=80;i<=80;i++) {
datawajah[19][i]=1; }
for (byte i=81;i<=102;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=27;i++) {
datawajah[20][i]=1; }
for (byte i=28;i<=32;i++) {
datawajah[20][i]=0; }
for (byte i=33;i<=65;i++) {
datawajah[20][i]=1; }
for (byte i=66;i<=73;i++) {
datawajah[20][i]=0; }
for (byte i=74;i<=82;i++) {
datawajah[20][i]=1; }
for (byte i=83;i<=102;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=28;i++) {
datawajah[21][i]=1; }
for (byte i=29;i<=31;i++) {
datawajah[21][i]=0; }
for (byte i=32;i<=67;i++) {
datawajah[21][i]=1; }
for (byte i=68;i<=74;i++) {
datawajah[21][i]=0; }
for (byte i=75;i<=83;i++) {
datawajah[21][i]=1; }
for (byte i=84;i<=102;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=27;i++) {
datawajah[22][i]=1; }
for (byte i=28;i<=30;i++) {
datawajah[22][i]=0; }
for (byte i=31;i<=67;i++) {
datawajah[22][i]=1; }
for (byte i=68;i<=74;i++) {
datawajah[22][i]=0; }
for (byte i=75;i<=84;i++) {
datawajah[22][i]=1; }
for (byte i=85;i<=102;i++) {
datawajah[22][i]=0; }

}

dataset:: wajahkiri8 ()
{
  baris = 23;
  kolom = 103;
//Baris1
for (byte i=0;i<=24;i++) {
datawajah[0][i]=1; }
for (byte i=25;i<=37;i++) {
datawajah[0][i]=0; }
for (byte i=38;i<=56;i++) {
datawajah[0][i]=1; }
for (byte i=57;i<=74;i++) {
datawajah[0][i]=0; }
for (byte i=75;i<=96;i++) {
datawajah[0][i]=1; }
for (byte i=97;i<=97;i++) {
datawajah[0][i]=0; }
for (byte i=98;i<=98;i++) {
datawajah[0][i]=1; }
for (byte i=99;i<=101;i++) {
datawajah[0][i]=0; }
for (byte i=102;i<=102;i++) {
datawajah[0][i]=1; }


//Baris2
for (byte i=0;i<=11;i++) {
datawajah[1][i]=1; }
for (byte i=12;i<=23;i++) {
datawajah[1][i]=0; }
for (byte i=24;i<=25;i++) {
datawajah[1][i]=1; }
for (byte i=26;i<=37;i++) {
datawajah[1][i]=0; }
for (byte i=38;i<=56;i++) {
datawajah[1][i]=1; }
for (byte i=57;i<=72;i++) {
datawajah[1][i]=0; }
for (byte i=73;i<=84;i++) {
datawajah[1][i]=1; }
for (byte i=85;i<=85;i++) {
datawajah[1][i]=0; }
for (byte i=86;i<=94;i++) {
datawajah[1][i]=1; }
for (byte i=95;i<=101;i++) {
datawajah[1][i]=0; }
for (byte i=102;i<=102;i++) {
datawajah[1][i]=1; }


//Baris3
for (byte i=0;i<=5;i++) {
datawajah[2][i]=1; }
for (byte i=6;i<=37;i++) {
datawajah[2][i]=0; }
for (byte i=38;i<=56;i++) {
datawajah[2][i]=1; }
for (byte i=57;i<=71;i++) {
datawajah[2][i]=0; }
for (byte i=72;i<=78;i++) {
datawajah[2][i]=1; }
for (byte i=79;i<=102;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=1;i++) {
datawajah[3][i]=1; }
for (byte i=2;i<=8;i++) {
datawajah[3][i]=0; }
for (byte i=9;i<=9;i++) {
datawajah[3][i]=1; }
for (byte i=10;i<=11;i++) {
datawajah[3][i]=0; }
for (byte i=12;i<=14;i++) {
datawajah[3][i]=1; }
for (byte i=15;i<=37;i++) {
datawajah[3][i]=0; }
for (byte i=38;i<=58;i++) {
datawajah[3][i]=1; }
for (byte i=59;i<=70;i++) {
datawajah[3][i]=0; }
for (byte i=71;i<=76;i++) {
datawajah[3][i]=1; }
for (byte i=77;i<=102;i++) {
datawajah[3][i]=0; }


//Baris5
for (byte i=0;i<=8;i++) {
datawajah[4][i]=0; }
for (byte i=9;i<=14;i++) {
datawajah[4][i]=1; }
for (byte i=15;i<=37;i++) {
datawajah[4][i]=0; }
for (byte i=38;i<=59;i++) {
datawajah[4][i]=1; }
for (byte i=60;i<=70;i++) {
datawajah[4][i]=0; }
for (byte i=71;i<=73;i++) {
datawajah[4][i]=1; }
for (byte i=74;i<=102;i++) {
datawajah[4][i]=0; }


//Baris6
for (byte i=0;i<=6;i++) {
datawajah[5][i]=0; }
for (byte i=7;i<=9;i++) {
datawajah[5][i]=1; }
for (byte i=10;i<=37;i++) {
datawajah[5][i]=0; }
for (byte i=38;i<=60;i++) {
datawajah[5][i]=1; }
for (byte i=61;i<=102;i++) {
datawajah[5][i]=0; }


//Baris7
for (byte i=0;i<=37;i++) {
datawajah[6][i]=0; }
for (byte i=38;i<=60;i++) {
datawajah[6][i]=1; }
for (byte i=61;i<=69;i++) {
datawajah[6][i]=0; }
for (byte i=70;i<=70;i++) {
datawajah[6][i]=1; }
for (byte i=71;i<=102;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=37;i++) {
datawajah[7][i]=0; }
for (byte i=38;i<=60;i++) {
datawajah[7][i]=1; }
for (byte i=61;i<=67;i++) {
datawajah[7][i]=0; }
for (byte i=68;i<=70;i++) {
datawajah[7][i]=1; }
for (byte i=71;i<=102;i++) {
datawajah[7][i]=0; }

//Baris9
for (byte i=0;i<=37;i++) {
datawajah[8][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[8][i]=1; }
for (byte i=62;i<=66;i++) {
datawajah[8][i]=0; }
for (byte i=67;i<=70;i++) {
datawajah[8][i]=1; }
for (byte i=71;i<=75;i++) {
datawajah[8][i]=0; }
for (byte i=76;i<=77;i++) {
datawajah[8][i]=1; }
for (byte i=78;i<=102;i++) {
datawajah[8][i]=0; }

//Baris10
for (byte i=0;i<=20;i++) {
datawajah[9][i]=0; }
for (byte i=21;i<=22;i++) {
datawajah[9][i]=1; }
for (byte i=23;i<=37;i++) {
datawajah[9][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[9][i]=1; }
for (byte i=62;i<=66;i++) {
datawajah[9][i]=0; }
for (byte i=67;i<=69;i++) {
datawajah[9][i]=1; }
for (byte i=70;i<=74;i++) {
datawajah[9][i]=0; }
for (byte i=75;i<=78;i++) {
datawajah[9][i]=1; }
for (byte i=79;i<=102;i++) {
datawajah[9][i]=0; }


//Baris11
for (byte i=0;i<=20;i++) {
datawajah[10][i]=0; }
for (byte i=21;i<=23;i++) {
datawajah[10][i]=1; }
for (byte i=24;i<=37;i++) {
datawajah[10][i]=0; }
for (byte i=38;i<=62;i++) {
datawajah[10][i]=1; }
for (byte i=63;i<=67;i++) {
datawajah[10][i]=0; }
for (byte i=68;i<=68;i++) {
datawajah[10][i]=1; }
for (byte i=69;i<=75;i++) {
datawajah[10][i]=0; }
for (byte i=76;i<=78;i++) {
datawajah[10][i]=1; }
for (byte i=79;i<=102;i++) {
datawajah[10][i]=0; }


//Baris12
for (byte i=0;i<=4;i++) {
datawajah[11][i]=0; }
for (byte i=5;i<=7;i++) {
datawajah[11][i]=1; }
for (byte i=8;i<=20;i++) {
datawajah[11][i]=0; }
for (byte i=21;i<=22;i++) {
datawajah[11][i]=1; }
for (byte i=23;i<=37;i++) {
datawajah[11][i]=0; }
for (byte i=38;i<=62;i++) {
datawajah[11][i]=1; }
for (byte i=63;i<=67;i++) {
datawajah[11][i]=0; }
for (byte i=68;i<=68;i++) {
datawajah[11][i]=1; }
for (byte i=69;i<=76;i++) {
datawajah[11][i]=0; }
for (byte i=77;i<=77;i++) {
datawajah[11][i]=1; }
for (byte i=78;i<=102;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=5;i++) {
datawajah[12][i]=0; }
for (byte i=6;i<=7;i++) {
datawajah[12][i]=1; }
for (byte i=8;i<=38;i++) {
datawajah[12][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[12][i]=1; }
for (byte i=63;i<=102;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=38;i++) {
datawajah[13][i]=0; }
for (byte i=39;i<=62;i++) {
datawajah[13][i]=1; }
for (byte i=63;i<=102;i++) {
datawajah[13][i]=0; }


//Baris15
for (byte i=0;i<=37;i++) {
datawajah[14][i]=0; }
for (byte i=38;i<=63;i++) {
datawajah[14][i]=1; }
for (byte i=64;i<=102;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=37;i++) {
datawajah[15][i]=0; }
for (byte i=38;i<=63;i++) {
datawajah[15][i]=1; }
for (byte i=64;i<=102;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=0;i<=4;i++) {
datawajah[16][i]=0; }
for (byte i=5;i<=11;i++) {
datawajah[16][i]=1; }
for (byte i=12;i<=37;i++) {
datawajah[16][i]=0; }
for (byte i=38;i<=64;i++) {
datawajah[16][i]=1; }
for (byte i=65;i<=102;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=1;i++) {
datawajah[17][i]=0; }
for (byte i=2;i<=13;i++) {
datawajah[17][i]=1; }
for (byte i=14;i<=36;i++) {
datawajah[17][i]=0; }
for (byte i=37;i<=64;i++) {
datawajah[17][i]=1; }
for (byte i=65;i<=102;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=0;i++) {
datawajah[18][i]=1; }
for (byte i=1;i<=1;i++) {
datawajah[18][i]=0; }
for (byte i=2;i<=14;i++) {
datawajah[18][i]=1; }
for (byte i=15;i<=17;i++) {
datawajah[18][i]=0; }
for (byte i=18;i<=19;i++) {
datawajah[18][i]=1; }
for (byte i=20;i<=33;i++) {
datawajah[18][i]=0; }
for (byte i=34;i<=64;i++) {
datawajah[18][i]=1; }
for (byte i=65;i<=74;i++) {
datawajah[18][i]=0; }
for (byte i=75;i<=76;i++) {
datawajah[18][i]=1; }
for (byte i=77;i<=102;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=17;i++) {
datawajah[19][i]=1; }
for (byte i=18;i<=18;i++) {
datawajah[19][i]=0; }
for (byte i=19;i<=25;i++) {
datawajah[19][i]=1; }
for (byte i=26;i<=31;i++) {
datawajah[19][i]=0; }
for (byte i=32;i<=65;i++) {
datawajah[19][i]=1; }
for (byte i=66;i<=73;i++) {
datawajah[19][i]=0; }
for (byte i=74;i<=80;i++) {
datawajah[19][i]=1; }
for (byte i=81;i<=102;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=28;i++) {
datawajah[20][i]=1; }
for (byte i=29;i<=31;i++) {
datawajah[20][i]=0; }
for (byte i=32;i<=65;i++) {
datawajah[20][i]=1; }
for (byte i=66;i<=73;i++) {
datawajah[20][i]=0; }
for (byte i=74;i<=81;i++) {
datawajah[20][i]=1; }
for (byte i=82;i<=102;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=28;i++) {
datawajah[21][i]=1; }
for (byte i=29;i<=30;i++) {
datawajah[21][i]=0; }
for (byte i=31;i<=65;i++) {
datawajah[21][i]=1; }
for (byte i=66;i<=74;i++) {
datawajah[21][i]=0; }
for (byte i=75;i<=82;i++) {
datawajah[21][i]=1; }
for (byte i=83;i<=86;i++) {
datawajah[21][i]=0; }
for (byte i=87;i<=87;i++) {
datawajah[21][i]=1; }
for (byte i=88;i<=102;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=27;i++) {
datawajah[22][i]=1; }
for (byte i=28;i<=30;i++) {
datawajah[22][i]=0; }
for (byte i=31;i<=66;i++) {
datawajah[22][i]=1; }
for (byte i=67;i<=74;i++) {
datawajah[22][i]=0; }
for (byte i=75;i<=87;i++) {
datawajah[22][i]=1; }
for (byte i=88;i<=102;i++) {
datawajah[22][i]=0; }


}

dataset:: wajahkiri9 ()
{
  baris = 23;
  kolom = 101;
//Baris1
for (byte i=0;i<=23;i++) {
datawajah[0][i]=1; }
for (byte i=24;i<=34;i++) {
datawajah[0][i]=0; }
for (byte i=35;i<=55;i++) {
datawajah[0][i]=1; }
for (byte i=56;i<=73;i++) {
datawajah[0][i]=0; }
for (byte i=74;i<=97;i++) {
datawajah[0][i]=1; }
for (byte i=98;i<=100;i++) {
datawajah[0][i]=0; }


//Baris2
for (byte i=0;i<=23;i++) {
datawajah[1][i]=1; }
for (byte i=24;i<=36;i++) {
datawajah[1][i]=0; }
for (byte i=37;i<=55;i++) {
datawajah[1][i]=1; }
for (byte i=56;i<=72;i++) {
datawajah[1][i]=0; }
for (byte i=73;i<=94;i++) {
datawajah[1][i]=1; }
for (byte i=95;i<=99;i++) {
datawajah[1][i]=0; }
for (byte i=100;i<=100;i++) {
datawajah[1][i]=1; }


//Baris3
for (byte i=0;i<=9;i++) {
datawajah[2][i]=1; }
for (byte i=10;i<=21;i++) {
datawajah[2][i]=0; }
for (byte i=22;i<=22;i++) {
datawajah[2][i]=1; }
for (byte i=23;i<=23;i++) {
datawajah[2][i]=0; }
for (byte i=24;i<=24;i++) {
datawajah[2][i]=1; }
for (byte i=25;i<=36;i++) {
datawajah[2][i]=0; }
for (byte i=37;i<=56;i++) {
datawajah[2][i]=1; }
for (byte i=57;i<=71;i++) {
datawajah[2][i]=0; }
for (byte i=72;i<=80;i++) {
datawajah[2][i]=1; }
for (byte i=81;i<=100;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=3;i++) {
datawajah[3][i]=1; }
for (byte i=4;i<=36;i++) {
datawajah[3][i]=0; }
for (byte i=37;i<=56;i++) {
datawajah[3][i]=1; }
for (byte i=57;i<=71;i++) {
datawajah[3][i]=0; }
for (byte i=72;i<=77;i++) {
datawajah[3][i]=1; }
for (byte i=78;i<=100;i++) {
datawajah[3][i]=0; }


//Baris5
for (byte i=0;i<=0;i++) {
datawajah[4][i]=1; }
for (byte i=1;i<=7;i++) {
datawajah[4][i]=0; }
for (byte i=8;i<=8;i++) {
datawajah[4][i]=1; }
for (byte i=9;i<=10;i++) {
datawajah[4][i]=0; }
for (byte i=11;i<=12;i++) {
datawajah[4][i]=1; }
for (byte i=13;i<=36;i++) {
datawajah[4][i]=0; }
for (byte i=37;i<=57;i++) {
datawajah[4][i]=1; }
for (byte i=58;i<=69;i++) {
datawajah[4][i]=0; }
for (byte i=70;i<=73;i++) {
datawajah[4][i]=1; }
for (byte i=74;i<=100;i++) {
datawajah[4][i]=0; }


//Baris6
for (byte i=0;i<=8;i++) {
datawajah[5][i]=0; }
for (byte i=9;i<=13;i++) {
datawajah[5][i]=1; }
for (byte i=14;i<=36;i++) {
datawajah[5][i]=0; }
for (byte i=37;i<=58;i++) {
datawajah[5][i]=1; }
for (byte i=59;i<=69;i++) {
datawajah[5][i]=0; }
for (byte i=70;i<=72;i++) {
datawajah[5][i]=1; }
for (byte i=73;i<=100;i++) {
datawajah[5][i]=0; }

//Baris7
for (byte i=0;i<=5;i++) {
datawajah[6][i]=0; }
for (byte i=6;i<=7;i++) {
datawajah[6][i]=1; }
for (byte i=8;i<=10;i++) {
datawajah[6][i]=0; }
for (byte i=11;i<=11;i++) {
datawajah[6][i]=1; }
for (byte i=12;i<=36;i++) {
datawajah[6][i]=0; }
for (byte i=37;i<=59;i++) {
datawajah[6][i]=1; }
for (byte i=60;i<=100;i++) {
datawajah[6][i]=0; }


//Baris8
for (byte i=0;i<=36;i++) {
datawajah[7][i]=0; }
for (byte i=37;i<=59;i++) {
datawajah[7][i]=1; }
for (byte i=60;i<=67;i++) {
datawajah[7][i]=0; }
for (byte i=68;i<=69;i++) {
datawajah[7][i]=1; }
for (byte i=70;i<=100;i++) {
datawajah[7][i]=0; }


//Baris9
for (byte i=0;i<=10;i++) {
datawajah[8][i]=0; }
for (byte i=11;i<=11;i++) {
datawajah[8][i]=1; }
for (byte i=12;i<=36;i++) {
datawajah[8][i]=0; }
for (byte i=37;i<=59;i++) {
datawajah[8][i]=1; }
for (byte i=60;i<=66;i++) {
datawajah[8][i]=0; }
for (byte i=67;i<=69;i++) {
datawajah[8][i]=1; }
for (byte i=70;i<=74;i++) {
datawajah[8][i]=0; }
for (byte i=75;i<=76;i++) {
datawajah[8][i]=1; }
for (byte i=77;i<=100;i++) {
datawajah[8][i]=0; }


//Baris10
for (byte i=0;i<=10;i++) {
datawajah[9][i]=0; }
for (byte i=11;i<=11;i++) {
datawajah[9][i]=1; }
for (byte i=12;i<=36;i++) {
datawajah[9][i]=0; }
for (byte i=37;i<=60;i++) {
datawajah[9][i]=1; }
for (byte i=61;i<=65;i++) {
datawajah[9][i]=0; }
for (byte i=66;i<=68;i++) {
datawajah[9][i]=1; }
for (byte i=69;i<=74;i++) {
datawajah[9][i]=0; }
for (byte i=75;i<=76;i++) {
datawajah[9][i]=1; }
for (byte i=77;i<=100;i++) {
datawajah[9][i]=0; }


//Baris11
for (byte i=0;i<=36;i++) {
datawajah[10][i]=0; }
for (byte i=37;i<=60;i++) {
datawajah[10][i]=1; }
for (byte i=61;i<=65;i++) {
datawajah[10][i]=0; }
for (byte i=66;i<=67;i++) {
datawajah[10][i]=1; }
for (byte i=68;i<=74;i++) {
datawajah[10][i]=0; }
for (byte i=75;i<=77;i++) {
datawajah[10][i]=1; }
for (byte i=78;i<=100;i++) {
datawajah[10][i]=0; }


//Baris12
for (byte i=0;i<=18;i++) {
datawajah[11][i]=0; }
for (byte i=19;i<=21;i++) {
datawajah[11][i]=1; }
for (byte i=22;i<=36;i++) {
datawajah[11][i]=0; }
for (byte i=37;i<=60;i++) {
datawajah[11][i]=1; }
for (byte i=61;i<=65;i++) {
datawajah[11][i]=0; }
for (byte i=66;i<=67;i++) {
datawajah[11][i]=1; }
for (byte i=68;i<=74;i++) {
datawajah[11][i]=0; }
for (byte i=75;i<=77;i++) {
datawajah[11][i]=1; }
for (byte i=78;i<=100;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=3;i++) {
datawajah[12][i]=0; }
for (byte i=4;i<=5;i++) {
datawajah[12][i]=1; }
for (byte i=6;i<=18;i++) {
datawajah[12][i]=0; }
for (byte i=19;i<=20;i++) {
datawajah[12][i]=1; }
for (byte i=21;i<=37;i++) {
datawajah[12][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[12][i]=1; }
for (byte i=62;i<=100;i++) {
datawajah[12][i]=0; }


//Baris14
for (byte i=0;i<=3;i++) {
datawajah[13][i]=0; }
for (byte i=4;i<=6;i++) {
datawajah[13][i]=1; }
for (byte i=7;i<=18;i++) {
datawajah[13][i]=0; }
for (byte i=19;i<=19;i++) {
datawajah[13][i]=1; }
for (byte i=20;i<=37;i++) {
datawajah[13][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[13][i]=1; }
for (byte i=62;i<=100;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=4;i++) {
datawajah[14][i]=0; }
for (byte i=5;i<=6;i++) {
datawajah[14][i]=1; }
for (byte i=7;i<=37;i++) {
datawajah[14][i]=0; }
for (byte i=38;i<=61;i++) {
datawajah[14][i]=1; }
for (byte i=62;i<=100;i++) {
datawajah[14][i]=0; }

//Baris16
for (byte i=0;i<=37;i++) {
datawajah[15][i]=0; }
for (byte i=38;i<=62;i++) {
datawajah[15][i]=1; }
for (byte i=63;i<=100;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=1;i<=35;i++) {
datawajah[16][i]=0; }
for (byte i=36;i<=63;i++) {
datawajah[16][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[16][i]=0; }


//Baris18
for (byte i=0;i<=4;i++) {
datawajah[17][i]=0; }
for (byte i=5;i<=10;i++) {
datawajah[17][i]=1; }
for (byte i=11;i<=35;i++) {
datawajah[17][i]=0; }
for (byte i=36;i<=63;i++) {
datawajah[17][i]=1; }
for (byte i=64;i<=100;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=0;i++) {
datawajah[18][i]=0; }
for (byte i=1;i<=12;i++) {
datawajah[18][i]=1; }
for (byte i=13;i<=13;i++) {
datawajah[18][i]=0; }
for (byte i=14;i<=15;i++) {
datawajah[18][i]=1; }
for (byte i=16;i<=33;i++) {
datawajah[18][i]=0; }
for (byte i=34;i<=63;i++) {
datawajah[18][i]=1; }
for (byte i=64;i<=71;i++) {
datawajah[18][i]=0; }
for (byte i=72;i<=75;i++) {
datawajah[18][i]=1; }
for (byte i=76;i<=100;i++) {
datawajah[18][i]=0; }


//Baris20
for (byte i=0;i<=14;i++) {
datawajah[19][i]=1; }
for (byte i=15;i<=32;i++) {
datawajah[19][i]=0; }
for (byte i=33;i<=63;i++) {
datawajah[19][i]=1; }
for (byte i=64;i<=71;i++) {
datawajah[19][i]=0; }
for (byte i=72;i<=78;i++) {
datawajah[19][i]=1; }
for (byte i=79;i<=100;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=26;i++) {
datawajah[20][i]=1; }
for (byte i=27;i<=31;i++) {
datawajah[20][i]=0; }
for (byte i=32;i<=63;i++) {
datawajah[20][i]=1; }
for (byte i=64;i<=71;i++) {
datawajah[20][i]=0; }
for (byte i=72;i<=81;i++) {
datawajah[20][i]=1; }
for (byte i=82;i<=100;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=26;i++) {
datawajah[21][i]=1; }
for (byte i=27;i<=29;i++) {
datawajah[21][i]=0; }
for (byte i=30;i<=63;i++) {
datawajah[21][i]=1; }
for (byte i=64;i<=72;i++) {
datawajah[21][i]=0; }
for (byte i=73;i<=81;i++) {
datawajah[21][i]=1; }
for (byte i=82;i<=100;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=26;i++) {
datawajah[22][i]=1; }
for (byte i=27;i<=29;i++) {
datawajah[22][i]=0; }
for (byte i=30;i<=63;i++) {
datawajah[22][i]=1; }
for (byte i=64;i<=73;i++) {
datawajah[22][i]=0; }
for (byte i=74;i<=86;i++) {
datawajah[22][i]=1; }
for (byte i=87;i<=100;i++) {
datawajah[22][i]=0; }

}

dataset:: wajahkiri10 ()
{
  baris = 23;
  kolom = 100;
//Baris1
for (byte i=0;i<=22;i++) {
datawajah[0][i]=1; }
for (byte i=23;i<=35;i++) {
datawajah[0][i]=0; }
for (byte i=36;i<=54;i++) {
datawajah[0][i]=1; }
for (byte i=55;i<=71;i++) {
datawajah[0][i]=0; }
for (byte i=72;i<=94;i++) {
datawajah[0][i]=1; }
for (byte i=95;i<=99;i++) {
datawajah[0][i]=0; }

//Baris2
for (byte i=0;i<=8;i++) {
datawajah[1][i]=1; }
for (byte i=9;i<=20;i++) {
datawajah[1][i]=0; }
for (byte i=21;i<=22;i++) {
datawajah[1][i]=1; }
for (byte i=23;i<=35;i++) {
datawajah[1][i]=0; }
for (byte i=36;i<=54;i++) {
datawajah[1][i]=1; }
for (byte i=55;i<=70;i++) {
datawajah[1][i]=0; }
for (byte i=71;i<=80;i++) {
datawajah[1][i]=1; }
for (byte i=81;i<=85;i++) {
datawajah[1][i]=0; }
for (byte i=86;i<=86;i++) {
datawajah[1][i]=1; }
for (byte i=87;i<=91;i++) {
datawajah[1][i]=0; }
for (byte i=92;i<=92;i++) {
datawajah[1][i]=1; }
for (byte i=93;i<=99;i++) {
datawajah[1][i]=0; }

//Baris3
for (byte i=0;i<=1;i++) {
datawajah[2][i]=1; }
for (byte i=2;i<=6;i++) {
datawajah[2][i]=0; }
for (byte i=7;i<=7;i++) {
datawajah[2][i]=1; }
for (byte i=8;i<=35;i++) {
datawajah[2][i]=0; }
for (byte i=36;i<=55;i++) {
datawajah[2][i]=1; }
for (byte i=56;i<=69;i++) {
datawajah[2][i]=0; }
for (byte i=70;i<=75;i++) {
datawajah[2][i]=1; }
for (byte i=76;i<=99;i++) {
datawajah[2][i]=0; }

//Baris4
for (byte i=0;i<=5;i++) {
datawajah[3][i]=0; }
for (byte i=6;i<=7;i++) {
datawajah[3][i]=1; }
for (byte i=8;i<=8;i++) {
datawajah[3][i]=0; }
for (byte i=9;i<=11;i++) {
datawajah[3][i]=1; }
for (byte i=12;i<=35;i++) {
datawajah[3][i]=0; }
for (byte i=36;i<=55;i++) {
datawajah[3][i]=1; }
for (byte i=56;i<=69;i++) {
datawajah[3][i]=0; }
for (byte i=70;i<=73;i++) {
datawajah[3][i]=1; }
for (byte i=74;i<=99;i++) {
datawajah[3][i]=0; }


//Baris5
for (byte i=0;i<=4;i++) {
datawajah[4][i]=0; }
for (byte i=5;i<=12;i++) {
datawajah[4][i]=1; }
for (byte i=13;i<=35;i++) {
datawajah[4][i]=0; }
for (byte i=36;i<=56;i++) {
datawajah[4][i]=1; }
for (byte i=57;i<=99;i++) {
datawajah[4][i]=0; }


//Baris6
for (byte i=0;i<=5;i++) {
datawajah[5][i]=0; }
for (byte i=6;i<=7;i++) {
datawajah[5][i]=1; }
for (byte i=8;i<=35;i++) {
datawajah[5][i]=0; }
for (byte i=36;i<=57;i++) {
datawajah[5][i]=1; }
for (byte i=58;i<=99;i++) {
datawajah[5][i]=0; }


//Baris7
for (byte i=0;i<=35;i++) {
datawajah[6][i]=0; }
for (byte i=36;i<=58;i++) {
datawajah[6][i]=1; }
for (byte i=59;i<=65;i++) {
datawajah[6][i]=0; }
for (byte i=66;i<=66;i++) {
datawajah[6][i]=1; }
for (byte i=67;i<=67;i++) {
datawajah[6][i]=0; }
for (byte i=68;i<=68;i++) {
datawajah[6][i]=1; }
for (byte i=69;i<=99;i++) {
datawajah[6][i]=0; }

//Baris8
for (byte i=0;i<=34;i++) {
datawajah[7][i]=0; }
for (byte i=35;i<=58;i++) {
datawajah[7][i]=1; }
for (byte i=59;i<=64;i++) {
datawajah[7][i]=0; }
for (byte i=65;i<=68;i++) {
datawajah[7][i]=1; }
for (byte i=69;i<=99;i++) {
datawajah[7][i]=0; }


//Baris9
for (byte i=0;i<=34;i++) {
datawajah[8][i]=0; }
for (byte i=35;i<=58;i++) {
datawajah[8][i]=1; }
for (byte i=59;i<=64;i++) {
datawajah[8][i]=0; }
for (byte i=65;i<=67;i++) {
datawajah[8][i]=1; }
for (byte i=68;i<=72;i++) {
datawajah[8][i]=0; }
for (byte i=73;i<=75;i++) {
datawajah[8][i]=1; }
for (byte i=76;i<=99;i++) {
datawajah[8][i]=0; }


//Baris10
for (byte i=0;i<=34;i++) {
datawajah[9][i]=0; }
for (byte i=35;i<=58;i++) {
datawajah[9][i]=1; }
for (byte i=59;i<=64;i++) {
datawajah[9][i]=0; }
for (byte i=65;i<=67;i++) {
datawajah[9][i]=1; }
for (byte i=68;i<=72;i++) {
datawajah[9][i]=0; }
for (byte i=73;i<=75;i++) {
datawajah[9][i]=1; }
for (byte i=76;i<=99;i++) {
datawajah[9][i]=0; }


//Baris11
for (byte i=0;i<=17;i++) {
datawajah[10][i]=0; }
for (byte i=18;i<=20;i++) {
datawajah[10][i]=1; }
for (byte i=21;i<=36;i++) {
datawajah[10][i]=0; }
for (byte i=37;i<=59;i++) {
datawajah[10][i]=1; }
for (byte i=60;i<=64;i++) {
datawajah[10][i]=0; }
for (byte i=65;i<=66;i++) {
datawajah[10][i]=1; }
for (byte i=67;i<=72;i++) {
datawajah[10][i]=0; }
for (byte i=73;i<=75;i++) {
datawajah[10][i]=1; }
for (byte i=76;i<=99;i++) {
datawajah[10][i]=0; }

//Baris12
for (byte i=0;i<=2;i++) {
datawajah[11][i]=0; }
for (byte i=3;i<=4;i++) {
datawajah[11][i]=1; }
for (byte i=5;i<=17;i++) {
datawajah[11][i]=0; }
for (byte i=18;i<=19;i++) {
datawajah[11][i]=1; }
for (byte i=20;i<=36;i++) {
datawajah[11][i]=0; }
for (byte i=37;i<=59;i++) {
datawajah[11][i]=1; }
for (byte i=60;i<=99;i++) {
datawajah[11][i]=0; }


//Baris13
for (byte i=0;i<=2;i++) {
datawajah[12][i]=0; }
for (byte i=3;i<=5;i++) {
datawajah[12][i]=1; }
for (byte i=6;i<=36;i++) {
datawajah[12][i]=0; }
for (byte i=37;i<=60;i++) {
datawajah[12][i]=1; }
for (byte i=61;i<=99;i++) {
datawajah[12][i]=0; }

//Baris14
for (byte i=0;i<=3;i++) {
datawajah[13][i]=0; }
for (byte i=4;i<=5;i++) {
datawajah[13][i]=1; }
for (byte i=6;i<=37;i++) {
datawajah[13][i]=0; }
for (byte i=38;i<=60;i++) {
datawajah[13][i]=1; }
for (byte i=61;i<=99;i++) {
datawajah[13][i]=0; }

//Baris15
for (byte i=0;i<=36;i++) {
datawajah[14][i]=0; }
for (byte i=37;i<=60;i++) {
datawajah[14][i]=1; }
for (byte i=61;i<=99;i++) {
datawajah[14][i]=0; }


//Baris16
for (byte i=0;i<=8;i++) {
datawajah[15][i]=0; }
for (byte i=9;i<=10;i++) {
datawajah[15][i]=1; }
for (byte i=11;i<=36;i++) {
datawajah[15][i]=0; }
for (byte i=37;i<=61;i++) {
datawajah[15][i]=1; }
for (byte i=62;i<=99;i++) {
datawajah[15][i]=0; }


//Baris17
for (byte i=0;i<=1;i++) {
datawajah[16][i]=0; }
for (byte i=2;i<=2;i++) {
datawajah[16][i]=1; }
for (byte i=3;i<=3;i++) {
datawajah[16][i]=0; }
for (byte i=4;i<=10;i++) {
datawajah[16][i]=1; }
for (byte i=11;i<=34;i++) {
datawajah[16][i]=0; }
for (byte i=35;i<=61;i++) {
datawajah[16][i]=1; }
for (byte i=62;i<=99;i++) {
datawajah[16][i]=0; }

//Baris18
for (byte i=0;i<=1;i++) {
datawajah[17][i]=0; }
for (byte i=2;i<=10;i++) {
datawajah[17][i]=1; }
for (byte i=11;i<=12;i++) {
datawajah[17][i]=0; }
for (byte i=13;i<=15;i++) {
datawajah[17][i]=1; }
for (byte i=16;i<=33;i++) {
datawajah[17][i]=0; }
for (byte i=34;i<=61;i++) {
datawajah[17][i]=1; }
for (byte i=62;i<=99;i++) {
datawajah[17][i]=0; }

//Baris19
for (byte i=0;i<=0;i++) {
datawajah[18][i]=0; }
for (byte i=1;i<=10;i++) {
datawajah[18][i]=1; }
for (byte i=11;i<=13;i++) {
datawajah[18][i]=0; }
for (byte i=14;i<=15;i++) {
datawajah[18][i]=1; }
for (byte i=16;i<=30;i++) {
datawajah[18][i]=0; }
for (byte i=31;i<=61;i++) {
datawajah[18][i]=1; }
for (byte i=62;i<=70;i++) {
datawajah[18][i]=0; }
for (byte i=71;i<=74;i++) {
datawajah[18][i]=1; }
for (byte i=75;i<=99;i++) {
datawajah[18][i]=0; }

//Baris20
for (byte i=0;i<=10;i++) {
datawajah[19][i]=1; }
for (byte i=11;i<=12;i++) {
datawajah[19][i]=0; }
for (byte i=13;i<=22;i++) {
datawajah[19][i]=1; }
for (byte i=23;i<=29;i++) {
datawajah[19][i]=0; }
for (byte i=30;i<=62;i++) {
datawajah[19][i]=1; }
for (byte i=63;i<=70;i++) {
datawajah[19][i]=0; }
for (byte i=71;i<=77;i++) {
datawajah[19][i]=1; }
for (byte i=78;i<=99;i++) {
datawajah[19][i]=0; }

//Baris21
for (byte i=0;i<=23;i++) {
datawajah[20][i]=1; }
for (byte i=24;i<=29;i++) {
datawajah[20][i]=0; }
for (byte i=30;i<=62;i++) {
datawajah[20][i]=1; }
for (byte i=63;i<=71;i++) {
datawajah[20][i]=0; }
for (byte i=72;i<=78;i++) {
datawajah[20][i]=1; }
for (byte i=79;i<=99;i++) {
datawajah[20][i]=0; }

//Baris22
for (byte i=0;i<=24;i++) {
datawajah[21][i]=1; }
for (byte i=25;i<=28;i++) {
datawajah[21][i]=0; }
for (byte i=29;i<=64;i++) {
datawajah[21][i]=1; }
for (byte i=65;i<=71;i++) {
datawajah[21][i]=0; }
for (byte i=72;i<=81;i++) {
datawajah[21][i]=1; }
for (byte i=82;i<=82;i++) {
datawajah[21][i]=0; }
for (byte i=83;i<=85;i++) {
datawajah[21][i]=1; }
for (byte i=86;i<=99;i++) {
datawajah[21][i]=0; }

//Baris23
for (byte i=0;i<=24;i++) {
datawajah[22][i]=1; }
for (byte i=25;i<=27;i++) {
datawajah[22][i]=0; }
for (byte i=28;i<=66;i++) {
datawajah[22][i]=1; }
for (byte i=67;i<=71;i++) {
datawajah[22][i]=0; }
for (byte i=72;i<=87;i++) {
datawajah[22][i]=1; }
for (byte i=88;i<=99;i++) {
datawajah[22][i]=0; }



}



